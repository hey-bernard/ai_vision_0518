"""
Flask 웹 챗봇 — OpenAI Chat Completions API (gpt-4o-mini).
"""
import os
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, session
from openai import OpenAI

ENV_PATH = Path(r"C:\env\.env")
load_dotenv(ENV_PATH)

# 세션 쿠키 서명용 (운영에서는 FLASK_SECRET_KEY를 .env에 설정 권장)
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-flask-secret-change-me")

# 세션 쿠키 크기 제한 방지: 최근 메시지만 유지
MAX_HISTORY_MESSAGES = 40


def get_client() -> OpenAI:
    return OpenAI()


@app.route("/")
def index():
    return render_template("index.html")


@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    user_message = (data.get("message") or "").strip()
    if not user_message:
        return jsonify({"error": "메시지를 입력해 주세요."}), 400

    if "history" not in session:
        session["history"] = []

    history = session["history"]
    history.append({"role": "user", "content": user_message})

    try:
        client = get_client()
        completion = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=history,
        )
        reply = completion.choices[0].message.content or ""
    except Exception as e:
        history.pop()
        return jsonify({"error": str(e)}), 500

    history.append({"role": "assistant", "content": reply})
    if len(history) > MAX_HISTORY_MESSAGES:
        history = history[-MAX_HISTORY_MESSAGES:]
    session["history"] = history

    return jsonify({"reply": reply})


@app.post("/api/chat/clear")
def clear_chat():
    session.pop("history", None)
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
