# PCB AOI Visual AI — Incident Runbook

## P1: API Unavailable
1. `GET /health` 확인
2. 최근 배포/설정 변경 이력 확인 (`service_config.json`, `deploy_config_template.json`)
3. 이전 버전 컨테이너/프로세스로 롤백
4. 장애 타임라인 기록 (outputs/maintenance/incident_log.json)

## P2: High Latency (p95 > 800ms)
1. GPU/CPU 사용률 대시보드 확인
2. `batch_size` 축소, 캐시 hit rate 확인
3. 품질 게이트로 불필요 추론 차단 여부 확인
4. 30분 내 미해결 시 ML 엔지니어 호출

## P3: Model Quality Drop (mAP -5%)
1. `outputs/detection_eval/` 최신 리포트 비교
2. 데이터 분포 drift (조명/센서) EDA
3. 피드백 로그에서 systematic bias 확인
4. 재학습/임계값 조정 계획 수립 (주간 회의)

## 연락처 (템플릿)
- 운영 온콜: ___________
- ML 온콜: ___________
- 설비: ___________
