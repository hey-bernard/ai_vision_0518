"""
DatasetInfoTool

MVTec 데이터셋의 특정 클래스 정보를 조회한다.
예: capsule, bottle, hazelnut
"""

from __future__ import annotations

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from utils.dataset import DatasetManager
from utils.logger import get_logger
from utils.runtime_state import get_runtime_state

logger = get_logger(__name__)


class DatasetInfoInput(BaseModel):
    """DatasetInfoTool 입력 스키마."""

    class_name: str = Field(
        ...,
        description=(
            "조회할 MVTec 클래스명. "
            "예: capsule, bottle, hazelnut, cable, carpet, grid, leather, "
            "metal_nut, pill, screw, tile, toothbrush, transistor, wood, zipper"
        ),
    )


class DatasetInfoToolService:
    """클래스 메타데이터 조회 서비스."""

    def __init__(self, dataset_manager: DatasetManager | None = None) -> None:
        """
        Args:
            dataset_manager: DatasetManager 인스턴스.
        """
        self.dataset = dataset_manager or DatasetManager()

    def run(self, class_name: str) -> str:
        """
        클래스 정보를 Markdown으로 반환한다.

        Args:
            class_name: 클래스명.

        Returns:
            클래스 설명 Markdown.
        """
        name = (class_name or "").strip().lower()
        logger.info("DatasetInfoTool 호출: %s", name)

        available = self.dataset.list_classes()
        if not name:
            result = (
                "클래스명이 비어 있습니다. 사용 가능 클래스:\n"
                + ", ".join(available)
            )
            get_runtime_state().add_tool_log("DatasetInfoTool", "(empty)", result)
            return result

        # 유사 이름 매칭 (부분 일치)
        if name not in available:
            candidates = [c for c in available if name in c or c in name]
            if len(candidates) == 1:
                name = candidates[0]
            elif candidates:
                result = (
                    f"'{class_name}' 와 일치하는 클래스가 없습니다.\n"
                    f"유사한 클래스: {', '.join(candidates)}"
                )
                get_runtime_state().add_tool_log(
                    "DatasetInfoTool", class_name, result
                )
                return result
            else:
                result = (
                    f"'{class_name}' 클래스를 찾을 수 없습니다.\n"
                    f"사용 가능 클래스: {', '.join(available)}"
                )
                get_runtime_state().add_tool_log(
                    "DatasetInfoTool", class_name, result
                )
                return result

        info = self.dataset.get_class_info(name)
        defects = ", ".join(info["defects"]) if info["defects"] else "정보 없음"
        result = f"""## 클래스 정보: `{info['class_name']}`

### 카테고리
{info['category']}

### 설명
{info['description']}

### 주요 불량 유형
{defects}

### 디스크 존재 여부
{'예' if info['exists_on_disk'] else '아니오'}

### 폴더 구조
```
{info.get('folder_structure') or 'N/A'}
```
""".strip()

        get_runtime_state().add_tool_log(
            tool_name="DatasetInfoTool",
            input_summary=class_name,
            output_summary=result,
        )
        return result


def create_dataset_info_tool(
    dataset_manager: DatasetManager | None = None,
) -> StructuredTool:
    """
    LangChain StructuredTool 형태의 DatasetInfoTool을 생성한다.

    Args:
        dataset_manager: 공유 DatasetManager.

    Returns:
        StructuredTool 인스턴스.
    """
    service = DatasetInfoToolService(dataset_manager=dataset_manager)

    return StructuredTool.from_function(
        func=service.run,
        name="DatasetInfoTool",
        description=(
            "MVTec 데이터셋의 특정 클래스(capsule, bottle, hazelnut 등) 정보를 조회한다. "
            "클래스 설명, 카테고리, 불량 유형, 폴더 구조를 반환한다. "
            "예: 'capsule 클래스 설명', 'bottle은 어떤 불량이 있나?'"
        ),
        args_schema=DatasetInfoInput,
    )
