"""
SearchRAGTool

Vector DB(Qdrant)에서 질문과 관련된 Document를 검색한다.
"""

from __future__ import annotations

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from rag.retriever import RAGRetriever
from utils.logger import get_logger
from utils.runtime_state import get_runtime_state

logger = get_logger(__name__)


class SearchRAGInput(BaseModel):
    """SearchRAGTool 입력 스키마."""

    query: str = Field(
        ...,
        description="Vector DB에서 검색할 질문 또는 키워드 (예: 스크래치 불량 특징)",
    )


class SearchRAGToolService:
    """
    RAG 검색 Tool 서비스 클래스.

    Agent의 Tool Calling에서 호출되며,
    검색 결과는 RuntimeState에도 저장되어 UI에 표시된다.
    """

    def __init__(self, retriever: RAGRetriever | None = None) -> None:
        """
        Args:
            retriever: RAGRetriever 인스턴스.
        """
        self.retriever = retriever or RAGRetriever()

    def run(self, query: str) -> str:
        """
        질문을 받아 관련 문서를 검색한다.

        Args:
            query: 사용자 질문.

        Returns:
            포맷된 검색 결과 문자열.
        """
        logger.info("SearchRAGTool 호출: %s", query)
        try:
            documents = self.retriever.search(query)
            result = self.retriever.format_documents(documents)
        except Exception as exc:  # noqa: BLE001
            logger.exception("SearchRAGTool 실패")
            result = f"RAG 검색 중 오류가 발생했습니다: {exc}"

        get_runtime_state().add_tool_log(
            tool_name="SearchRAGTool",
            input_summary=query,
            output_summary=result,
        )
        return result


def create_search_rag_tool(retriever: RAGRetriever | None = None) -> StructuredTool:
    """
    LangChain StructuredTool 형태의 SearchRAGTool을 생성한다.

    Args:
        retriever: 공유 RAGRetriever.

    Returns:
        StructuredTool 인스턴스.
    """
    service = SearchRAGToolService(retriever=retriever)

    return StructuredTool.from_function(
        func=service.run,
        name="SearchRAGTool",
        description=(
            "MVTec 데이터셋 관련 지식을 Vector DB에서 검색한다. "
            "불량 특징, 데이터셋 개요, 폴더 구조, README, 클래스 일반 정보 질문에 사용한다. "
            "예: '스크래치 불량 특징', 'MVTec 데이터셋이란?'"
        ),
        args_schema=SearchRAGInput,
    )
