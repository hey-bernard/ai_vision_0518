"""
HelpTool

에이전트가 제공하는 기능/Tool 사용법을 설명한다.
"""

from __future__ import annotations

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from utils.logger import get_logger
from utils.runtime_state import get_runtime_state

logger = get_logger(__name__)

HELP_TEXT = """
## MVTec Visual RAG AI Agent 사용 가이드

이 Agent는 MVTec AD 데이터셋 지식을 바탕으로
텍스트 QA와 이미지 외관 검사를 지원합니다.

### 사용 가능한 Tool

1. **SearchRAGTool**
   - Vector DB에서 MVTec 관련 문서를 검색합니다.
   - 예: `스크래치 불량 특징`, `MVTec 폴더 구조 알려줘`

2. **DatasetInfoTool**
   - 특정 클래스 정보를 조회합니다.
   - 예: `capsule 클래스 설명`, `hazelnut 불량 유형`

3. **ImageAnalysisTool**
   - 업로드 이미지를 OpenAI Vision으로 분석합니다.
   - 제품 종류 / 정상·불량 / 불량 위치 / 추정 이유를 제공합니다.
   - Image Analysis 탭에서 이미지를 업로드한 뒤 사용하세요.

4. **HelpTool**
   - 지금처럼 기능 설명을 보여줍니다.

### UI 탭 안내

- **Text QA**: 질문 → Agent Tool Calling → 답변
- **Image Analysis**: 이미지 업로드 → Vision 분석
- **RAG Search Result**: 최근 검색된 문서 확인
- **System Log**: Tool 호출 로그 확인

### 팁

- 클래스명이 명확하면 DatasetInfoTool이 적합합니다.
- 불량 특징/일반 지식 질문은 SearchRAGTool이 적합합니다.
- 이미지 관련 요청은 ImageAnalysisTool을 사용합니다.
""".strip()


class HelpInput(BaseModel):
    """HelpTool 입력 스키마."""

    topic: str = Field(
        default="general",
        description="도움말 주제 (general, tools, ui 등). 기본값 general.",
    )


class HelpToolService:
    """도움말 제공 서비스."""

    def run(self, topic: str = "general") -> str:
        """
        사용 가능한 기능 설명을 반환한다.

        Args:
            topic: 도움말 주제 (현재는 동일 가이드 반환).

        Returns:
            Markdown 도움말.
        """
        logger.info("HelpTool 호출: topic=%s", topic)
        result = HELP_TEXT + f"\n\n_(요청 topic: {topic})_"
        get_runtime_state().add_tool_log(
            tool_name="HelpTool",
            input_summary=topic,
            output_summary=result,
        )
        return result


def create_help_tool() -> StructuredTool:
    """
    LangChain StructuredTool 형태의 HelpTool을 생성한다.

    Returns:
        StructuredTool 인스턴스.
    """
    service = HelpToolService()

    return StructuredTool.from_function(
        func=service.run,
        name="HelpTool",
        description=(
            "Agent가 제공 가능한 기능과 Tool 사용법을 설명한다. "
            "사용자가 도움말, 사용법, 기능 목록을 물어볼 때 사용한다."
        ),
        args_schema=HelpInput,
    )
