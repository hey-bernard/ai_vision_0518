"""
ImageAnalysisTool

업로드된 이미지를 OpenAI Vision(GPT-4.1)으로 분석한다.
로컬 GPU는 사용하지 않는다.
"""

from __future__ import annotations

import base64
from pathlib import Path

from langchain_core.messages import HumanMessage
from langchain_core.tools import StructuredTool
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field

from config import VISION_MODEL_NAME
from utils.logger import get_logger
from utils.runtime_state import get_runtime_state

logger = get_logger(__name__)

VISION_SYSTEM_PROMPT = """당신은 MVTec AD 기반 산업 외관 검사(Visual Inspection) 전문가입니다.
업로드된 제품 이미지를 보고 아래 항목을 Markdown으로 정리하세요.

## 분석 결과

### 제품 종류
(추정 클래스명과 근거)

### 정상 여부
(정상 / 불량 / 판단 보류)

### 불량 위치
(불량이면 위치 설명, 정상이면 '해당 없음')

### 설명
(추정 이유와 관찰된 시각적 단서)

### 권장 사항
(추가 확인 포인트 또는 검사 팁)

주의:
- 확신이 낮으면 명확히 표시하세요.
- 과장하지 말고 관찰 근거를 중심으로 설명하세요.
- 한국어로 작성하세요.
"""


class ImageAnalysisInput(BaseModel):
    """ImageAnalysisTool 입력 스키마."""

    image_path: str = Field(
        default="",
        description=(
            "분석할 이미지 파일 경로. "
            "비어 있으면 현재 세션에 업로드된 이미지를 사용한다."
        ),
    )
    focus: str = Field(
        default="전반적인 외관 검사",
        description="특별히 집중할 분석 포인트 (선택)",
    )


class ImageAnalysisToolService:
    """
    OpenAI Vision 기반 이미지 분석 서비스.

    ChatOpenAI + multimodal HumanMessage 로 추론한다.
    """

    def __init__(self, model_name: str = VISION_MODEL_NAME) -> None:
        """
        Args:
            model_name: Vision 지원 OpenAI 모델명.
        """
        self.model_name = model_name
        self._llm: ChatOpenAI | None = None

    @property
    def llm(self) -> ChatOpenAI:
        """Vision용 ChatOpenAI (lazy)."""
        if self._llm is None:
            self._llm = ChatOpenAI(
                model=self.model_name,
                temperature=0,
            )
        return self._llm

    @staticmethod
    def _encode_image_to_data_url(image_path: Path) -> str:
        """
        이미지 파일을 base64 data URL로 인코딩한다.

        Args:
            image_path: 이미지 경로.

        Returns:
            data:image/...;base64,... 문자열.
        """
        suffix = image_path.suffix.lower().lstrip(".")
        mime_map = {
            "jpg": "jpeg",
            "jpeg": "jpeg",
            "png": "png",
            "webp": "webp",
            "gif": "gif",
        }
        mime = mime_map.get(suffix, "png")
        raw = image_path.read_bytes()
        b64 = base64.b64encode(raw).decode("utf-8")
        return f"data:image/{mime};base64,{b64}"

    def run(self, image_path: str = "", focus: str = "전반적인 외관 검사") -> str:
        """
        이미지를 Vision 모델로 분석한다.

        Args:
            image_path: 이미지 경로. 비어 있으면 RuntimeState 경로 사용.
            focus: 분석 초점.

        Returns:
            Markdown 분석 결과.
        """
        state = get_runtime_state()
        path_str = (image_path or "").strip() or (state.current_image_path or "")
        logger.info("ImageAnalysisTool 호출: path=%s, focus=%s", path_str, focus)

        if not path_str:
            result = (
                "분석할 이미지가 없습니다. "
                "Image Analysis 탭에서 이미지를 업로드한 뒤 다시 시도하세요."
            )
            state.add_tool_log("ImageAnalysisTool", "no image", result)
            return result

        path = Path(path_str)
        if not path.exists():
            result = f"이미지 파일을 찾을 수 없습니다: {path}"
            state.add_tool_log("ImageAnalysisTool", path_str, result)
            return result

        try:
            data_url = self._encode_image_to_data_url(path)
            user_text = (
                f"{VISION_SYSTEM_PROMPT}\n\n"
                f"추가 요청(focus): {focus}\n"
                f"파일명: {path.name}"
            )
            message = HumanMessage(
                content=[
                    {"type": "text", "text": user_text},
                    {
                        "type": "image_url",
                        "image_url": {"url": data_url},
                    },
                ]
            )
            response = self.llm.invoke([message])
            result = getattr(response, "content", None) or str(response)
        except Exception as exc:  # noqa: BLE001
            logger.exception("ImageAnalysisTool 실패")
            result = f"이미지 분석 중 오류가 발생했습니다: {exc}"

        state.add_tool_log(
            tool_name="ImageAnalysisTool",
            input_summary=f"{path.name} | focus={focus}",
            output_summary=result,
        )
        return result


def create_image_analysis_tool() -> StructuredTool:
    """
    LangChain StructuredTool 형태의 ImageAnalysisTool을 생성한다.

    Returns:
        StructuredTool 인스턴스.
    """
    service = ImageAnalysisToolService()

    return StructuredTool.from_function(
        func=service.run,
        name="ImageAnalysisTool",
        description=(
            "업로드된 제품 이미지를 OpenAI Vision으로 분석한다. "
            "제품 종류, 정상/불량 여부, 불량 위치, 추정 이유를 Markdown으로 반환한다. "
            "사용자가 이미지를 업로드했거나 이미지 분석을 요청하면 반드시 이 Tool을 사용한다."
        ),
        args_schema=ImageAnalysisInput,
    )
