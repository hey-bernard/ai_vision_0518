# MVTec_Agent

MVTec AD 데이터셋 기반 **Visual RAG AI Agent** 입니다.  
Streamlit UI + LangChain `create_agent()` Tool Calling + Qdrant RAG + OpenAI GPT-4.1 / Vision 으로 텍스트 QA와 이미지 외관 검사를 수행합니다.

> 로컬 GPU는 사용하지 않습니다. 모든 추론은 OpenAI API로 수행합니다.

---

## 프로젝트 소개

- **Text QA**: 질문 → Agent가 Tool 자동 선택 → RAG/클래스 정보 기반 답변
- **Image Analysis**: 이미지 업로드 → OpenAI Vision 분석 (정상/불량, 위치, 이유)
- **RAG**: 최초 실행 시 MVTec 설명/README/폴더구조/클래스 정보를 Embedding 후 Qdrant 저장, 이후 재사용
- **Tools**
  - `SearchRAGTool` — Vector DB 검색
  - `ImageAnalysisTool` — Vision 이미지 분석
  - `DatasetInfoTool` — 클래스 정보 조회 (capsule, bottle, hazelnut 등)
  - `HelpTool` — 기능 안내

---

## 사전 준비

1. **Python 3.11.9** 권장
2. OpenAI API Key를 `C:\env\.env` 에 저장

```env
OPENAI_API_KEY=sk-xxxxxxxx
```

3. 프로젝트 루트에 `MVTec_581MB.zip` 이 있어야 합니다.  
   실행 시 자동으로 `data/mvtec/` 로 압축 해제됩니다.

---

## 설치 방법

```bash
cd MVTec_Agent
pip install -r requirements.txt
```

---

## 실행 방법

```bash
streamlit run app.py
```

브라우저에서 Streamlit 앱이 열립니다.

---

## 프로젝트 구조

```text
MVTec_Agent/
├── app.py                 # 메인 실행 파일 (Streamlit)
├── config.py              # 경로/모델/클래스 메타 설정
├── requirements.txt
├── .env.example
├── README.md
├── MVTec_581MB.zip        # 제공 데이터셋
├── data/
│   └── mvtec/             # ZIP 자동 압축 해제 위치
├── vector_db/             # Qdrant 로컬 저장소
├── rag/
│   ├── document_builder.py
│   ├── vector_store.py
│   └── retriever.py
├── tools/
│   ├── search_rag.py
│   ├── image_analysis.py
│   ├── dataset_info.py
│   └── help_tool.py
├── models/
│   ├── llm.py
│   └── agent.py           # create_agent() 기반 Agent
├── utils/
│   ├── env_loader.py      # C:\env\.env 로드
│   ├── dataset.py         # ZIP 해제 / 클래스 조회
│   ├── logger.py
│   └── runtime_state.py
└── pages/
    ├── _text_qa.py
    ├── _image_analysis.py
    ├── _rag_result.py
    └── _system_log.py
```

---

## 사용 예시

### Text QA

| 질문 | 예상 Tool |
|------|-----------|
| `capsule 클래스 설명` | DatasetInfoTool |
| `스크래치 불량 특징` | SearchRAGTool |
| `도움말` | HelpTool |

### Image Analysis

1. **Image Analysis** 탭에서 PNG/JPG 업로드
2. **이미지 분석 실행** 클릭
3. Agent가 `ImageAnalysisTool` 호출 → Markdown 분석 결과 출력

응답 형식 예시:

```markdown
## 분석 결과

### 제품 종류
...

### 정상 여부
...

### 불량 위치
...

### 설명
...

### 권장 사항
...
```

---

## 화면 설명

### 사이드바

- 프로젝트 설명
- 데이터셋 정보 (클래스 수, 경로, 압축 해제 여부)
- Vector DB 생성 여부 / 재구축 버튼

### 메인 탭

1. **Text QA** — 질문 입력 및 Agent 답변
2. **Image Analysis** — 이미지 업로드 및 Vision 분석
3. **RAG Search Result** — 최근 검색 문서
4. **System Log** — Tool 호출 로그

---

## 기술 스택

| 구분 | 기술 |
|------|------|
| UI | Streamlit |
| Agent | LangChain 1.x `create_agent()` |
| LLM | OpenAI GPT-4.1 (`ChatOpenAI`) |
| Embedding | `OpenAIEmbeddings` |
| Vector DB | Qdrant (로컬 path 모드) |
| RAG | VectorStore Retriever |

---

## 주의 사항

- API Key를 소스코드에 넣지 마세요. 반드시 `C:\env\.env` 를 사용하세요.
- 로컬 GPU / 로컬 LLM은 사용하지 않습니다.
- 최초 실행 시 Embedding 및 Vector DB 구축으로 시간이 소요될 수 있습니다.
- Qdrant path 모드는 동시에 하나의 프로세스만 접근하는 것이 안전합니다.
