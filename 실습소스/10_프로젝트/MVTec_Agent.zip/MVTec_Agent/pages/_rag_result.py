"""
RAG Search Result 탭.

최근 SearchRAGTool / Retriever 검색 문서를 표시한다.
"""

from __future__ import annotations

import streamlit as st

from utils.runtime_state import get_runtime_state


def render_rag_result_tab() -> None:
    """최근 RAG 검색 결과 UI를 렌더링한다."""
    st.subheader("RAG Search Result")
    st.caption("SearchRAGTool이 검색한 최근 문서가 여기에 표시됩니다.")

    results = get_runtime_state().last_search_results
    if not results:
        st.info("아직 검색된 문서가 없습니다. Text QA에서 RAG 질문을 해보세요.")
        return

    st.success(f"검색 문서 {len(results)}건")
    for idx, item in enumerate(results, start=1):
        meta = item.get("metadata") or {}
        source = meta.get("source", "unknown")
        doc_type = meta.get("doc_type", "unknown")
        with st.expander(f"[{idx}] {source} ({doc_type})", expanded=(idx == 1)):
            st.markdown(item.get("content", ""))
            st.json(meta)
