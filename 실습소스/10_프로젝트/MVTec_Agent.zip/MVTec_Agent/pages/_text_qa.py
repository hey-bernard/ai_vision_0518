"""
Text QA 탭.

질문 입력 → Agent(create_agent) Tool Calling → 답변 출력.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import streamlit as st

if TYPE_CHECKING:
    from models.agent import MVTecAgent


def render_text_qa_tab(agent: "MVTecAgent") -> None:
    """
    Text QA 탭 UI를 렌더링한다.

    Args:
        agent: MVTecAgent 인스턴스.
    """
    st.subheader("Text QA")
    st.caption("질문을 입력하면 Agent가 적절한 Tool을 자동 선택합니다.")

    with st.expander("질문 예시", expanded=False):
        st.markdown(
            """
- `capsule 클래스 설명` → DatasetInfoTool
- `스크래치 불량 특징` → SearchRAGTool
- `MVTec 데이터셋 폴더 구조 알려줘` → SearchRAGTool
- `도움말` → HelpTool
            """
        )

    question = st.text_area(
        "질문",
        placeholder="예: capsule 클래스 설명 / 스크래치 불량 특징",
        height=100,
        key="text_qa_question",
    )

    col1, col2 = st.columns([1, 4])
    with col1:
        ask = st.button("질문하기", type="primary", use_container_width=True)
    with col2:
        clear = st.button("입력 초기화", use_container_width=True)

    if clear:
        st.session_state.pop("text_qa_answer", None)
        st.session_state.pop("text_qa_tool_calls", None)
        st.rerun()

    if ask:
        if not question.strip():
            st.warning("질문을 입력해 주세요.")
            return
        with st.spinner("Agent가 Tool Calling으로 답변을 생성 중..."):
            result = agent.invoke(question.strip())
        st.session_state["text_qa_answer"] = result.get("answer", "")
        st.session_state["text_qa_tool_calls"] = result.get("tool_calls", [])

    answer = st.session_state.get("text_qa_answer")
    if answer:
        st.markdown("### 답변")
        st.markdown(answer)

        tool_calls = st.session_state.get("text_qa_tool_calls") or []
        if tool_calls:
            with st.expander("이번 응답에서 호출된 Tool", expanded=False):
                for call in tool_calls:
                    st.markdown(f"- **{call.get('name')}** args=`{call.get('args')}`")
