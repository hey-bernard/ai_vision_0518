"""
Image Analysis 탭.

이미지 업로드 → Agent가 ImageAnalysisTool(Vision) 호출 → 불량 분석 출력.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING
from uuid import uuid4

import streamlit as st
from PIL import Image

from config import UPLOAD_DIR

if TYPE_CHECKING:
    from models.agent import MVTecAgent


def _save_uploaded_file(uploaded_file: object) -> Path:
    """
    업로드 파일을 data/uploads 에 저장한다.

    Args:
        uploaded_file: Streamlit UploadedFile 유사 객체
            (name, getvalue() 속성/메서드 필요).

    Returns:
        저장된 파일 Path.
    """
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    name = getattr(uploaded_file, "name", "upload.png")
    suffix = Path(str(name)).suffix or ".png"
    out_path = UPLOAD_DIR / f"upload_{uuid4().hex}{suffix}"
    out_path.write_bytes(uploaded_file.getvalue())  # type: ignore[attr-defined]
    return out_path


def render_image_analysis_tab(agent: "MVTecAgent") -> None:
    """
    Image Analysis 탭 UI를 렌더링한다.

    Args:
        agent: MVTecAgent 인스턴스.
    """
    st.subheader("Image Analysis")
    st.caption("이미지를 업로드하면 Agent가 OpenAI Vision Tool을 호출합니다. (로컬 GPU 미사용)")

    uploaded = st.file_uploader(
        "제품 이미지 업로드",
        type=["png", "jpg", "jpeg", "webp"],
        key="image_uploader",
    )

    extra_question = st.text_input(
        "추가 질문 (선택)",
        placeholder="예: 스크래치가 있는지 중점적으로 봐줘",
        key="image_extra_question",
    )

    if uploaded is not None:
        try:
            image = Image.open(uploaded)
            st.image(image, caption=uploaded.name, use_container_width=True)
        except Exception as exc:  # noqa: BLE001
            st.error(f"이미지를 열 수 없습니다: {exc}")
            return

    analyze = st.button("이미지 분석 실행", type="primary", disabled=uploaded is None)

    if analyze and uploaded is not None:
        with st.spinner("Vision 분석 중 (ImageAnalysisTool)..."):
            try:
                saved = _save_uploaded_file(uploaded)
                result = agent.analyze_image(
                    image_path=str(saved),
                    question=extra_question.strip() or None,
                )
                st.session_state["image_analysis_answer"] = result.get("answer", "")
                st.session_state["image_analysis_tool_calls"] = result.get(
                    "tool_calls", []
                )
            except Exception as exc:  # noqa: BLE001
                st.error(f"이미지 분석 실패: {exc}")
                return

    answer = st.session_state.get("image_analysis_answer")
    if answer:
        st.markdown("### 분석 결과")
        st.markdown(answer)

        tool_calls = st.session_state.get("image_analysis_tool_calls") or []
        if tool_calls:
            with st.expander("호출된 Tool", expanded=False):
                for call in tool_calls:
                    st.markdown(f"- **{call.get('name')}** args=`{call.get('args')}`")
