"""
UI 탭 렌더러 패키지.

파일명에 언더스코어(_) 접두사를 두어 Streamlit multipage 자동 등록을 피한다.
"""
