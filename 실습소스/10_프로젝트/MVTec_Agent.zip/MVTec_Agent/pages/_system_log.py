"""
System Log 탭.

Tool 호출 로그를 출력한다.
"""

from __future__ import annotations

import streamlit as st

from utils.runtime_state import get_runtime_state


def render_system_log_tab() -> None:
    """Tool 호출 로그 UI를 렌더링한다."""
    st.subheader("System Log")
    st.caption("Agent Tool Calling 이력을 확인합니다.")

    state = get_runtime_state()
    logs = list(state.tool_logs)

    col1, col2 = st.columns([1, 4])
    with col1:
        if st.button("로그 초기화", use_container_width=True):
            state.clear_logs()
            st.rerun()
    with col2:
        st.write(f"총 {len(logs)}건")

    if not logs:
        st.info("아직 Tool 호출 로그가 없습니다.")
        return

    # 최신 로그가 위에 오도록 역순 표시
    for entry in reversed(logs):
        with st.expander(
            f"{entry.timestamp} | {entry.tool_name}",
            expanded=False,
        ):
            st.markdown("**Input**")
            st.code(entry.input_summary or "(empty)")
            st.markdown("**Output**")
            st.markdown(entry.output_summary or "(empty)")
