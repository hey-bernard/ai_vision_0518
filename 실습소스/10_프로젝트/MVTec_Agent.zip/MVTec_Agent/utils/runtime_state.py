"""
런타임 공유 상태.

Agent Tool 호출 로그, 최근 RAG 검색 결과, 업로드 이미지 경로 등을
UI(Streamlit)와 Tool이 공유할 수 있도록 싱글톤으로 관리한다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from threading import Lock
from typing import Any


@dataclass
class ToolLogEntry:
    """단일 Tool 호출 로그 항목."""

    tool_name: str
    input_summary: str
    output_summary: str
    timestamp: str = field(
        default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )


@dataclass
class RuntimeState:
    """
    애플리케이션 런타임 상태 컨테이너.

    Attributes:
        tool_logs: Tool 호출 이력.
        last_search_results: 최근 RAG 검색 문서 목록.
        current_image_path: ImageAnalysisTool이 사용할 이미지 경로.
    """

    tool_logs: list[ToolLogEntry] = field(default_factory=list)
    last_search_results: list[dict[str, Any]] = field(default_factory=list)
    current_image_path: str | None = None
    _lock: Lock = field(default_factory=Lock, repr=False)

    def add_tool_log(
        self,
        tool_name: str,
        input_summary: str,
        output_summary: str,
        max_output_len: int = 500,
    ) -> None:
        """
        Tool 호출 로그를 추가한다.

        Args:
            tool_name: 호출된 Tool 이름.
            input_summary: 입력 요약.
            output_summary: 출력 요약.
            max_output_len: 출력 요약 최대 길이.
        """
        trimmed = output_summary
        if len(trimmed) > max_output_len:
            trimmed = trimmed[:max_output_len] + "..."

        with self._lock:
            self.tool_logs.append(
                ToolLogEntry(
                    tool_name=tool_name,
                    input_summary=input_summary,
                    output_summary=trimmed,
                )
            )

    def set_search_results(self, results: list[dict[str, Any]]) -> None:
        """최근 RAG 검색 결과를 갱신한다."""
        with self._lock:
            self.last_search_results = results

    def set_current_image(self, image_path: str | None) -> None:
        """Vision 분석용 현재 이미지 경로를 설정한다."""
        with self._lock:
            self.current_image_path = image_path

    def clear_logs(self) -> None:
        """Tool 로그와 검색 결과를 초기화한다."""
        with self._lock:
            self.tool_logs.clear()
            self.last_search_results.clear()


# 프로세스 전역 싱글톤
_RUNTIME_STATE = RuntimeState()


def get_runtime_state() -> RuntimeState:
    """전역 RuntimeState 인스턴스를 반환한다."""
    return _RUNTIME_STATE
