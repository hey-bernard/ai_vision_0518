"""
로깅 유틸리티.

콘솔과 파일에 동시에 로그를 남기며,
Tool 호출 / RAG 구축 / 예외 상황을 추적한다.
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from typing import Optional

from config import LOG_DIR, LOG_FILE_PATH, ensure_directories

_LOGGING_INITIALIZED: bool = False


def setup_logging(level: int = logging.INFO) -> None:
    """
    애플리케이션 전역 로깅을 초기화한다.

    Args:
        level: 로그 레벨 (기본 INFO).
    """
    global _LOGGING_INITIALIZED
    if _LOGGING_INITIALIZED:
        return

    ensure_directories()
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # 콘솔 핸들러
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)

    # 파일 핸들러 (로테이션)
    file_handler = RotatingFileHandler(
        filename=str(LOG_FILE_PATH),
        maxBytes=2 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)

    # 중복 핸들러 방지
    if not root_logger.handlers:
        root_logger.addHandler(console_handler)
        root_logger.addHandler(file_handler)
    else:
        root_logger.addHandler(console_handler)
        root_logger.addHandler(file_handler)

    _LOGGING_INITIALIZED = True
    logging.getLogger(__name__).info("로깅 초기화 완료: %s", LOG_FILE_PATH)


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    모듈별 로거를 반환한다.

    Args:
        name: 로거 이름. None이면 루트 로거.

    Returns:
        logging.Logger 인스턴스.
    """
    if not _LOGGING_INITIALIZED:
        setup_logging()
    return logging.getLogger(name)
