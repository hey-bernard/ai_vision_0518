"""
MVTec 데이터셋 관리 모듈.

ZIP 자동 압축 해제, 클래스/폴더 구조 조회를 담당한다.
"""

from __future__ import annotations

import shutil
import zipfile
from pathlib import Path
from typing import Any

from config import (
    MVTEC_CLASS_INFO,
    MVTEC_DATA_DIR,
    ZIP_FILE_PATH,
    ensure_directories,
)
from utils.logger import get_logger

logger = get_logger(__name__)


class DatasetManager:
    """
    MVTec AD 데이터셋 준비 및 메타데이터 조회 클래스.

    실행 시 ZIP이 존재하고 data/mvtec 가 비어 있으면
    자동으로 압축을 해제한다.
    """

    def __init__(
        self,
        zip_path: Path | None = None,
        extract_dir: Path | None = None,
    ) -> None:
        """
        Args:
            zip_path: MVTec ZIP 파일 경로.
            extract_dir: 압축 해제 대상 디렉터리 (data/mvtec).
        """
        self.zip_path = zip_path or ZIP_FILE_PATH
        self.extract_dir = extract_dir or MVTEC_DATA_DIR
        ensure_directories()

    def is_extracted(self) -> bool:
        """
        데이터셋이 이미 압축 해제되었는지 확인한다.

        Returns:
            클래스 폴더가 하나 이상 있으면 True.
        """
        if not self.extract_dir.exists():
            return False
        class_dirs = [
            p
            for p in self.extract_dir.iterdir()
            if p.is_dir() and not p.name.startswith(".")
        ]
        return len(class_dirs) > 0

    def ensure_extracted(self) -> Path:
        """
        필요 시 ZIP을 data/mvtec 로 압축 해제한다.

        Returns:
            압축 해제된 데이터셋 루트 경로.

        Raises:
            FileNotFoundError: ZIP 파일이 없고 데이터도 없는 경우.
            zipfile.BadZipFile: 손상된 ZIP인 경우.
        """
        if self.is_extracted():
            logger.info("MVTec 데이터셋이 이미 존재합니다: %s", self.extract_dir)
            return self.extract_dir

        if not self.zip_path.exists():
            raise FileNotFoundError(
                f"MVTec ZIP 파일을 찾을 수 없습니다: {self.zip_path}"
            )

        logger.info("MVTec ZIP 압축 해제 시작: %s -> %s", self.zip_path, self.extract_dir)
        self.extract_dir.mkdir(parents=True, exist_ok=True)

        try:
            with zipfile.ZipFile(self.zip_path, "r") as zf:
                zf.extractall(self.extract_dir)
        except zipfile.BadZipFile as exc:
            # 실패 시 부분 해제 잔여물 정리
            if self.extract_dir.exists():
                shutil.rmtree(self.extract_dir, ignore_errors=True)
            raise zipfile.BadZipFile(f"손상된 ZIP 파일입니다: {self.zip_path}") from exc

        logger.info("MVTec ZIP 압축 해제 완료")
        return self.extract_dir

    def list_classes(self) -> list[str]:
        """
        데이터셋에 존재하는 클래스 폴더 목록을 반환한다.

        Returns:
            정렬된 클래스명 리스트.
        """
        if not self.extract_dir.exists():
            return sorted(MVTEC_CLASS_INFO.keys())

        classes = [
            p.name
            for p in self.extract_dir.iterdir()
            if p.is_dir() and not p.name.startswith(".")
        ]
        return sorted(classes)

    def get_class_info(self, class_name: str) -> dict[str, Any]:
        """
        특정 클래스의 설명/불량 유형을 반환한다.

        Args:
            class_name: 클래스명 (예: capsule, bottle).

        Returns:
            클래스 메타데이터 딕셔너리.
        """
        key = class_name.strip().lower()
        base = MVTEC_CLASS_INFO.get(key, {})
        folder = self.extract_dir / key

        defect_types: list[str] = []
        test_dir = folder / "test"
        if test_dir.exists():
            defect_types = sorted(
                [
                    p.name
                    for p in test_dir.iterdir()
                    if p.is_dir() and p.name != "good"
                ]
            )

        return {
            "class_name": key,
            "category": base.get("category", "Unknown"),
            "description": base.get(
                "description",
                f"{key} 클래스에 대한 기본 설명이 없습니다.",
            ),
            "defects": defect_types or list(base.get("defects", [])),
            "exists_on_disk": folder.exists(),
            "folder_structure": self._describe_folder(folder) if folder.exists() else "",
        }

    def get_folder_structure_summary(self) -> str:
        """
        데이터셋 전체 폴더 구조 요약을 문자열로 반환한다.

        Returns:
            사람이 읽기 쉬운 폴더 구조 설명.
        """
        lines = [
            "MVTec AD 폴더 구조 요약",
            f"루트: {self.extract_dir}",
            "",
            "일반적인 클래스 폴더 구조:",
            "  <class>/",
            "    train/good/          # 정상 학습 이미지",
            "    test/<defect|good>/  # 테스트 이미지 (정상/불량)",
            "    ground_truth/<defect>/  # 불량 마스크 (있는 경우)",
            "    license.txt / readme.txt",
            "",
            "클래스 목록:",
        ]
        for name in self.list_classes():
            info = self.get_class_info(name)
            defects = ", ".join(info["defects"]) if info["defects"] else "N/A"
            lines.append(f"  - {name} ({info['category']}): defects=[{defects}]")
        return "\n".join(lines)

    def read_text_file(self, relative_path: str) -> str:
        """
        데이터셋 내 텍스트 파일을 읽는다.

        Args:
            relative_path: data/mvtec 기준 상대 경로.

        Returns:
            파일 내용. 없으면 빈 문자열.
        """
        path = self.extract_dir / relative_path
        if not path.exists() or not path.is_file():
            return ""
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning("텍스트 파일 읽기 실패: %s (%s)", path, exc)
            return ""

    def _describe_folder(self, folder: Path) -> str:
        """단일 클래스 폴더의 하위 구조를 간단히 기술한다."""
        parts: list[str] = [f"{folder.name}/"]
        for child in sorted(folder.iterdir()):
            if child.is_dir():
                sub = sorted([p.name for p in child.iterdir() if p.is_dir()])
                parts.append(f"  {child.name}/ -> {sub}")
            else:
                parts.append(f"  {child.name}")
        return "\n".join(parts)

    def get_dataset_overview(self) -> dict[str, Any]:
        """사이드바/요약용 데이터셋 개요를 반환한다."""
        classes = self.list_classes()
        return {
            "name": "MVTec AD",
            "num_classes": len(classes),
            "classes": classes,
            "extracted": self.is_extracted(),
            "path": str(self.extract_dir),
            "zip_path": str(self.zip_path),
            "zip_exists": self.zip_path.exists(),
        }
