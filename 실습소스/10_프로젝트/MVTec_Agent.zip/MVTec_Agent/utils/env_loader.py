"""
환경 변수 로더.

OpenAI API Key는 C:\\env\\.env 에서만 읽으며,
코드 내부에 키를 하드코딩하지 않는다.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

from config import ENV_FILE_PATH
from utils.logger import get_logger

logger = get_logger(__name__)


class EnvLoadError(RuntimeError):
    """환경 변수 로드 실패 시 발생."""


def load_api_key(env_path: Path | None = None) -> str:
    """
    dotenv를 사용해 OpenAI API Key를 로드한다.

    Args:
        env_path: .env 파일 경로. 기본값은 config.ENV_FILE_PATH.

    Returns:
        OPENAI_API_KEY 문자열.

    Raises:
        EnvLoadError: 파일이 없거나 키가 비어 있는 경우.
    """
    target = env_path or ENV_FILE_PATH

    if not target.exists():
        raise EnvLoadError(
            f"환경 변수 파일을 찾을 수 없습니다: {target}\n"
            "C:\\env\\.env 파일에 OPENAI_API_KEY=... 를 설정해 주세요."
        )

    # override=False: 이미 설정된 OS 환경 변수를 덮어쓰지 않음
    loaded = load_dotenv(dotenv_path=target, override=False)
    if not loaded:
        logger.warning("dotenv 로드 결과가 False 입니다. path=%s", target)

    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise EnvLoadError(
            "OPENAI_API_KEY 가 비어 있습니다. "
            f"{target} 파일에 OPENAI_API_KEY 값을 설정해 주세요."
        )

    # LangChain / OpenAI 클라이언트가 참조할 수 있도록 프로세스 환경에 보장
    os.environ["OPENAI_API_KEY"] = api_key
    logger.info("OpenAI API Key 로드 완료 (path=%s)", target)
    return api_key
