"""
MVTec_Agent 전역 설정 모듈.

경로, 모델명, Vector DB 설정 등 프로젝트 공통 상수를 관리한다.
로컬 GPU는 사용하지 않으며, 모든 추론은 OpenAI API를 통해 수행한다.
"""

from __future__ import annotations

from pathlib import Path

# ---------------------------------------------------------------------------
# 프로젝트 경로
# ---------------------------------------------------------------------------
# 이 파일(config.py)이 위치한 디렉터리를 프로젝트 루트로 사용한다.
PROJECT_ROOT: Path = Path(__file__).resolve().parent

# MVTec 원본 ZIP 및 압축 해제 경로
ZIP_FILE_PATH: Path = PROJECT_ROOT / "MVTec_581MB.zip"
DATA_DIR: Path = PROJECT_ROOT / "data"
MVTEC_DATA_DIR: Path = DATA_DIR / "mvtec"

# Qdrant 로컬 영속 저장 경로 (서버 없이 path 모드 사용)
VECTOR_DB_DIR: Path = PROJECT_ROOT / "vector_db"
QDRANT_PATH: Path = VECTOR_DB_DIR / "qdrant_local"

# 업로드 이미지 임시 저장 경로
UPLOAD_DIR: Path = PROJECT_ROOT / "data" / "uploads"

# 로그 파일 경로
LOG_DIR: Path = PROJECT_ROOT / "logs"
LOG_FILE_PATH: Path = LOG_DIR / "mvtec_agent.log"

# ---------------------------------------------------------------------------
# 환경 변수 / API Key
# ---------------------------------------------------------------------------
# 요구사항: C:\env\.env 에서 OPENAI_API_KEY 를 자동으로 읽는다.
ENV_FILE_PATH: Path = Path(r"C:\env\.env")

# ---------------------------------------------------------------------------
# LLM / Embedding (OpenAI API 전용, 로컬 GPU 미사용)
# ---------------------------------------------------------------------------
LLM_MODEL_NAME: str = "gpt-4.1"
VISION_MODEL_NAME: str = "gpt-4.1"
EMBEDDING_MODEL_NAME: str = "text-embedding-3-small"
EMBEDDING_DIMENSION: int = 1536
LLM_TEMPERATURE: float = 0.0

# ---------------------------------------------------------------------------
# Vector DB / RAG
# ---------------------------------------------------------------------------
QDRANT_COLLECTION_NAME: str = "mvtec_rag"
RETRIEVER_TOP_K: int = 4

# Vector DB 생성 완료 여부를 표시하는 마커 파일
VECTOR_DB_READY_MARKER: Path = VECTOR_DB_DIR / ".ready"

# ---------------------------------------------------------------------------
# MVTec 클래스 메타데이터 (불량 유형 포함)
# ---------------------------------------------------------------------------
# 데이터셋 폴더를 스캔해도 되지만, RAG Document / DatasetInfoTool 설명의
# 사람이 읽기 쉬운 설명을 제공하기 위해 클래스별 요약을 유지한다.
MVTEC_CLASS_INFO: dict[str, dict[str, object]] = {
    "bottle": {
        "category": "Object",
        "description": "유리병 제품. 외관 파손 및 오염을 탐지한다.",
        "defects": ["broken_large", "broken_small", "contamination"],
    },
    "cable": {
        "category": "Object",
        "description": "케이블 제품. 전선 절단, 절연 손상, 누락 등을 탐지한다.",
        "defects": [
            "bent_wire",
            "cable_swap",
            "combined",
            "cut_inner_insulation",
            "cut_outer_insulation",
            "missing_cable",
            "missing_wire",
            "poke_insulation",
        ],
    },
    "capsule": {
        "category": "Object",
        "description": "캡슐 의약품. 균열, 스크래치, 인쇄 불량, 찌그러짐 등을 탐지한다.",
        "defects": ["crack", "faulty_imprint", "poke", "scratch", "squeeze"],
    },
    "carpet": {
        "category": "Texture",
        "description": "카펫 텍스처. 구멍, 절단, 색상 이상, 이물 등을 탐지한다.",
        "defects": ["color", "cut", "hole", "metal_contamination", "thread"],
    },
    "grid": {
        "category": "Texture",
        "description": "격자(그리드) 텍스처. 휨, 파손, 접착제, 이물 등을 탐지한다.",
        "defects": ["bent", "broken", "glue", "metal_contamination", "thread"],
    },
    "hazelnut": {
        "category": "Object",
        "description": "헤이즐넛. 균열, 절단, 구멍, 인쇄 흔적 등을 탐지한다.",
        "defects": ["crack", "cut", "hole", "print"],
    },
    "leather": {
        "category": "Texture",
        "description": "가죽 텍스처. 색상 이상, 절단, 접힘, 접착제, 구멍 등을 탐지한다.",
        "defects": ["color", "cut", "fold", "glue", "poke"],
    },
    "metal_nut": {
        "category": "Object",
        "description": "금속 너트. 휨, 색상 이상, 뒤집힘, 스크래치를 탐지한다.",
        "defects": ["bent", "color", "flip", "scratch"],
    },
    "pill": {
        "category": "Object",
        "description": "알약. 색상, 오염, 균열, 인쇄 불량, 스크래치 등을 탐지한다.",
        "defects": [
            "color",
            "combined",
            "contamination",
            "crack",
            "faulty_imprint",
            "pill_type",
            "scratch",
        ],
    },
    "screw": {
        "category": "Object",
        "description": "나사. 머리/목 스크래치, 나사산 손상 등을 탐지한다.",
        "defects": [
            "manipulated_front",
            "scratch_head",
            "scratch_neck",
            "thread_side",
            "thread_top",
        ],
    },
    "tile": {
        "category": "Texture",
        "description": "타일 텍스처. 균열, 접착 테이프, 오일, 거친 표면 등을 탐지한다.",
        "defects": ["crack", "glue_strip", "gray_stroke", "oil", "rough"],
    },
    "toothbrush": {
        "category": "Object",
        "description": "칫솔. 불량(defective) 여부를 탐지한다.",
        "defects": ["defective"],
    },
    "transistor": {
        "category": "Object",
        "description": "트랜지스터. 리드 휨/절단, 케이스 손상, 위치 이상을 탐지한다.",
        "defects": ["bent_lead", "cut_lead", "damaged_case", "misplaced"],
    },
    "wood": {
        "category": "Texture",
        "description": "목재 텍스처. 색상, 구멍, 액체, 스크래치 등을 탐지한다.",
        "defects": ["color", "combined", "hole", "liquid", "scratch"],
    },
    "zipper": {
        "category": "Object",
        "description": "지퍼. 이빨 파손/갈라짐, 원단 이상, 거친 표면 등을 탐지한다.",
        "defects": [
            "broken_teeth",
            "combined",
            "fabric_border",
            "fabric_interior",
            "rough",
            "split_teeth",
            "squeezed_teeth",
        ],
    },
}


def ensure_directories() -> None:
    """프로젝트 실행에 필요한 디렉터리를 생성한다."""
    for path in (
        DATA_DIR,
        MVTEC_DATA_DIR,
        VECTOR_DB_DIR,
        UPLOAD_DIR,
        LOG_DIR,
    ):
        path.mkdir(parents=True, exist_ok=True)
