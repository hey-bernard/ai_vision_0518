"""
MVTec Visual RAG Agent.

최신 LangChain 1.x 의 create_agent() 를 사용하며,
Tool Calling으로 SearchRAG / ImageAnalysis / DatasetInfo / Help 를 자동 선택한다.
"""

from __future__ import annotations

from typing import Any

from langchain.agents import create_agent
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_openai import ChatOpenAI

from models.llm import LLMFactory
from rag.retriever import RAGRetriever
from tools.dataset_info import create_dataset_info_tool
from tools.help_tool import create_help_tool
from tools.image_analysis import create_image_analysis_tool
from tools.search_rag import create_search_rag_tool
from utils.dataset import DatasetManager
from utils.logger import get_logger
from utils.runtime_state import get_runtime_state

logger = get_logger(__name__)

SYSTEM_PROMPT = """당신은 MVTec AD 데이터셋 전문 Visual RAG AI Agent 입니다.

역할:
- 사용자의 질문에 맞는 Tool을 반드시 Tool Calling으로 선택해 사용합니다.
- 추측만으로 장황하게 답하지 말고, Tool 결과를 근거로 답변합니다.
- 최종 답변은 한국어 Markdown으로 작성합니다.

Tool 선택 가이드:
1) 특정 클래스(capsule, bottle, hazelnut 등) 설명/불량 목록 질문
   → DatasetInfoTool
2) 불량 특징, 데이터셋 개요, 폴더 구조, README, 일반 지식 검색
   → SearchRAGTool
3) 이미지 분석 / 불량 여부 판단 요청 (이미지가 업로드된 경우)
   → ImageAnalysisTool
4) 사용법 / 기능 안내
   → HelpTool

이미지 분석 시 ImageAnalysisTool을 호출한 뒤,
결과를 사용자에게 이해하기 쉽게 재정리해도 됩니다.
필요하면 여러 Tool을 순차적으로 호출할 수 있습니다.
"""


class MVTecAgent:
    """
    create_agent() 기반 Tool-Calling Agent 래퍼 클래스.

    Attributes:
        llm: ChatOpenAI 모델.
        retriever: 공유 RAGRetriever.
        graph: create_agent가 반환한 CompiledStateGraph.
    """

    def __init__(
        self,
        llm: ChatOpenAI | None = None,
        retriever: RAGRetriever | None = None,
        dataset_manager: DatasetManager | None = None,
    ) -> None:
        """
        Args:
            llm: Agent용 ChatOpenAI. None이면 팩토리로 생성.
            retriever: RAG 검색기.
            dataset_manager: 데이터셋 매니저.
        """
        self.llm = llm or LLMFactory.create_chat_model()
        self.retriever = retriever or RAGRetriever()
        self.dataset_manager = dataset_manager or DatasetManager()

        tools = [
            create_search_rag_tool(retriever=self.retriever),
            create_image_analysis_tool(),
            create_dataset_info_tool(dataset_manager=self.dataset_manager),
            create_help_tool(),
        ]

        # LangChain 1.x 표준: create_agent()
        self.graph = create_agent(
            model=self.llm,
            tools=tools,
            system_prompt=SYSTEM_PROMPT,
        )
        logger.info("MVTecAgent 초기화 완료 (tools=%d)", len(tools))

    def invoke(self, user_message: str) -> dict[str, Any]:
        """
        사용자 메시지를 Agent에 전달하고 결과를 파싱한다.

        Args:
            user_message: 사용자 입력 텍스트.

        Returns:
            answer, messages, tool_calls 등을 담은 dict.
        """
        text = (user_message or "").strip()
        if not text:
            return {
                "answer": "질문이 비어 있습니다. 내용을 입력해 주세요.",
                "messages": [],
                "tool_calls": [],
            }

        logger.info("Agent invoke: %s", text[:120])
        try:
            result = self.graph.invoke(
                {"messages": [HumanMessage(content=text)]}
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("Agent 실행 실패")
            return {
                "answer": f"Agent 실행 중 오류가 발생했습니다: {exc}",
                "messages": [],
                "tool_calls": [],
                "error": str(exc),
            }

        messages = result.get("messages", [])
        answer = self._extract_final_answer(messages)
        tool_calls = self._extract_tool_calls(messages)

        # System Log 탭 보강: Agent 메시지 상의 tool call도 기록
        for item in tool_calls:
            get_runtime_state().add_tool_log(
                tool_name=f"[agent]{item.get('name', 'unknown')}",
                input_summary=str(item.get("args", {})),
                output_summary=str(item.get("result", ""))[:500],
            )

        return {
            "answer": answer,
            "messages": messages,
            "tool_calls": tool_calls,
        }

    def analyze_image(self, image_path: str, question: str | None = None) -> dict[str, Any]:
        """
        이미지 경로를 상태에 설정한 뒤 Agent가 ImageAnalysisTool을 쓰도록 유도한다.

        Args:
            image_path: 업로드된 이미지 경로.
            question: 추가 질문 (선택).

        Returns:
            invoke()와 동일한 결과 dict.
        """
        get_runtime_state().set_current_image(image_path)
        prompt = question or (
            "업로드된 이미지를 ImageAnalysisTool로 분석해 주세요. "
            "제품 종류, 정상/불량 여부, 불량 위치, 추정 이유, 권장 사항을 Markdown으로 정리하세요."
        )
        # 경로를 메시지에 포함해 Tool이 image_path 인자를 채우기 쉽게 함
        full_prompt = (
            f"{prompt}\n\n"
            f"image_path: {image_path}\n"
            "반드시 ImageAnalysisTool을 호출하세요."
        )
        return self.invoke(full_prompt)

    @staticmethod
    def _extract_final_answer(messages: list[BaseMessage]) -> str:
        """메시지 목록에서 최종 AI 답변을 추출한다."""
        for message in reversed(messages):
            if isinstance(message, AIMessage):
                # tool_calls만 있는 중간 AIMessage는 건너뜀
                content = message.content
                if isinstance(content, str) and content.strip():
                    return content.strip()
                if isinstance(content, list):
                    texts = [
                        block.get("text", "")
                        for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    ]
                    joined = "\n".join(t for t in texts if t).strip()
                    if joined:
                        return joined
        return "응답을 생성하지 못했습니다."

    @staticmethod
    def _extract_tool_calls(messages: list[BaseMessage]) -> list[dict[str, Any]]:
        """
        AIMessage.tool_calls 와 ToolMessage 결과를 매칭해 요약한다.

        Args:
            messages: Agent 실행 메시지 목록.

        Returns:
            tool call 요약 리스트.
        """
        results_by_id: dict[str, str] = {}
        for message in messages:
            if isinstance(message, ToolMessage):
                tool_call_id = getattr(message, "tool_call_id", "") or ""
                results_by_id[tool_call_id] = str(message.content)

        calls: list[dict[str, Any]] = []
        for message in messages:
            if not isinstance(message, AIMessage):
                continue
            for call in getattr(message, "tool_calls", None) or []:
                call_id = call.get("id", "")
                calls.append(
                    {
                        "id": call_id,
                        "name": call.get("name"),
                        "args": call.get("args"),
                        "result": results_by_id.get(call_id, ""),
                    }
                )
        return calls
