"""
LLM / Embedding 팩토리.

모든 모델은 OpenAI API를 사용하며 로컬 GPU를 사용하지 않는다.
"""

from __future__ import annotations

from langchain_openai import ChatOpenAI, OpenAIEmbeddings

from config import (
    EMBEDDING_MODEL_NAME,
    LLM_MODEL_NAME,
    LLM_TEMPERATURE,
    VISION_MODEL_NAME,
)
from utils.logger import get_logger

logger = get_logger(__name__)


class LLMFactory:
    """
    ChatOpenAI / OpenAIEmbeddings 인스턴스 생성 팩토리.

    요구사항:
    - ChatOpenAI 사용
    - 모델: GPT-4.1
    - Embedding: OpenAIEmbeddings
    - 로컬 GPU 미사용
    """

    @staticmethod
    def create_chat_model(
        model_name: str = LLM_MODEL_NAME,
        temperature: float = LLM_TEMPERATURE,
    ) -> ChatOpenAI:
        """
        Agent용 ChatOpenAI 모델을 생성한다.

        Args:
            model_name: OpenAI 채팅 모델명.
            temperature: 샘플링 온도.

        Returns:
            ChatOpenAI 인스턴스.
        """
        logger.info("ChatOpenAI 생성: model=%s, temperature=%s", model_name, temperature)
        return ChatOpenAI(model=model_name, temperature=temperature)

    @staticmethod
    def create_vision_model(model_name: str = VISION_MODEL_NAME) -> ChatOpenAI:
        """
        Vision 분석용 ChatOpenAI 모델을 생성한다.

        Args:
            model_name: Vision 지원 모델명.

        Returns:
            ChatOpenAI 인스턴스.
        """
        logger.info("Vision ChatOpenAI 생성: model=%s", model_name)
        return ChatOpenAI(model=model_name, temperature=0)

    @staticmethod
    def create_embeddings(model_name: str = EMBEDDING_MODEL_NAME) -> OpenAIEmbeddings:
        """
        OpenAIEmbeddings를 생성한다.

        Args:
            model_name: Embedding 모델명.

        Returns:
            OpenAIEmbeddings 인스턴스.
        """
        logger.info("OpenAIEmbeddings 생성: model=%s", model_name)
        return OpenAIEmbeddings(model=model_name)
