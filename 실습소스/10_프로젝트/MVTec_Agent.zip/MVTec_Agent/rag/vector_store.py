"""
Qdrant Vector Store 관리 모듈.

최초 실행 시 Document Embedding 후 로컬 Qdrant에 저장하고,
이후에는 기존 컬렉션을 재사용한다.
로컬 GPU는 사용하지 않으며 OpenAIEmbeddings 만 사용한다.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_qdrant import QdrantVectorStore
from qdrant_client import QdrantClient
from qdrant_client.http.models import Distance, VectorParams

from config import (
    EMBEDDING_DIMENSION,
    EMBEDDING_MODEL_NAME,
    QDRANT_COLLECTION_NAME,
    QDRANT_PATH,
    VECTOR_DB_DIR,
    VECTOR_DB_READY_MARKER,
    ensure_directories,
)
from rag.document_builder import DocumentBuilder
from utils.logger import get_logger

logger = get_logger(__name__)


class VectorStoreManager:
    """
    Qdrant 기반 Vector DB 생성/로드 매니저.

    Attributes:
        collection_name: Qdrant 컬렉션 이름.
        qdrant_path: 로컬 영속 저장 경로.
    """

    def __init__(
        self,
        collection_name: str = QDRANT_COLLECTION_NAME,
        qdrant_path: Path | None = None,
        embedding_model: str = EMBEDDING_MODEL_NAME,
    ) -> None:
        """
        Args:
            collection_name: 컬렉션 이름.
            qdrant_path: Qdrant path 모드 저장 위치.
            embedding_model: OpenAI Embedding 모델명.
        """
        ensure_directories()
        self.collection_name = collection_name
        self.qdrant_path = Path(qdrant_path or QDRANT_PATH)
        self.embedding_model = embedding_model
        self._client: Optional[QdrantClient] = None
        self._embeddings: Optional[OpenAIEmbeddings] = None
        self._vector_store: Optional[QdrantVectorStore] = None

    @property
    def embeddings(self) -> OpenAIEmbeddings:
        """OpenAIEmbeddings 인스턴스 (lazy init)."""
        if self._embeddings is None:
            # 로컬 GPU/로컬 임베딩 모델 사용 금지 — OpenAI API만 사용
            self._embeddings = OpenAIEmbeddings(model=self.embedding_model)
        return self._embeddings

    def is_ready(self) -> bool:
        """
        Vector DB가 이미 구축되어 재사용 가능한지 확인한다.

        Returns:
            마커 파일이 있고 컬렉션이 존재하면 True.
        """
        if not VECTOR_DB_READY_MARKER.exists():
            return False
        try:
            client = self._get_client()
            collections = {c.name for c in client.get_collections().collections}
            return self.collection_name in collections
        except Exception as exc:  # noqa: BLE001
            logger.warning("Vector DB 상태 확인 실패: %s", exc)
            return False

    def _get_client(self) -> QdrantClient:
        """로컬 path 모드 QdrantClient를 반환한다."""
        if self._client is None:
            self.qdrant_path.mkdir(parents=True, exist_ok=True)
            # path 모드: 별도 Qdrant 서버 프로세스 불필요
            self._client = QdrantClient(path=str(self.qdrant_path))
            logger.info("QdrantClient 연결 (path=%s)", self.qdrant_path)
        return self._client

    def _collection_exists(self, client: QdrantClient) -> bool:
        """컬렉션 존재 여부."""
        names = {c.name for c in client.get_collections().collections}
        return self.collection_name in names

    def build_or_load(self, force_rebuild: bool = False) -> QdrantVectorStore:
        """
        Vector DB를 구축하거나 기존 DB를 로드한다.

        Args:
            force_rebuild: True이면 기존 컬렉션을 삭제하고 재생성.

        Returns:
            QdrantVectorStore 인스턴스.
        """
        if self._vector_store is not None and not force_rebuild:
            return self._vector_store

        client = self._get_client()

        if force_rebuild and self._collection_exists(client):
            logger.info("기존 컬렉션 삭제: %s", self.collection_name)
            client.delete_collection(self.collection_name)
            if VECTOR_DB_READY_MARKER.exists():
                VECTOR_DB_READY_MARKER.unlink()

        if self.is_ready() and not force_rebuild:
            logger.info("기존 Vector DB 재사용: %s", self.collection_name)
            self._vector_store = QdrantVectorStore(
                client=client,
                collection_name=self.collection_name,
                embedding=self.embeddings,
            )
            return self._vector_store

        # 최초 구축
        logger.info("Vector DB 최초 구축 시작")
        documents = DocumentBuilder().build_documents()
        self._vector_store = self._create_from_documents(client, documents)
        VECTOR_DB_DIR.mkdir(parents=True, exist_ok=True)
        VECTOR_DB_READY_MARKER.write_text(
            f"ready\ncollection={self.collection_name}\ndocs={len(documents)}\n",
            encoding="utf-8",
        )
        logger.info("Vector DB 구축 완료 (docs=%d)", len(documents))
        return self._vector_store

    def _create_from_documents(
        self,
        client: QdrantClient,
        documents: list[Document],
    ) -> QdrantVectorStore:
        """
        Document 목록을 Embedding 후 Qdrant에 저장한다.

        Args:
            client: QdrantClient.
            documents: 저장할 Document 목록.

        Returns:
            생성된 QdrantVectorStore.
        """
        if self._collection_exists(client):
            client.delete_collection(self.collection_name)

        client.create_collection(
            collection_name=self.collection_name,
            vectors_config=VectorParams(
                size=EMBEDDING_DIMENSION,
                distance=Distance.COSINE,
            ),
        )

        vector_store = QdrantVectorStore(
            client=client,
            collection_name=self.collection_name,
            embedding=self.embeddings,
        )
        # 배치 추가 (문서 수가 많지 않으므로 한 번에 처리)
        vector_store.add_documents(documents)
        return vector_store

    def get_vector_store(self) -> QdrantVectorStore:
        """구축/로드된 VectorStore를 반환한다."""
        return self.build_or_load()

    def close(self) -> None:
        """Qdrant 클라이언트를 종료한다."""
        if self._client is not None:
            try:
                self._client.close()
            except Exception as exc:  # noqa: BLE001
                logger.warning("QdrantClient close 중 경고: %s", exc)
            self._client = None
            self._vector_store = None
