"""
LangChain VectorStore Retriever 래퍼.

SearchRAGTool 및 Text QA 탭에서 사용한다.
"""

from __future__ import annotations

from typing import Any

from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever

from config import RETRIEVER_TOP_K
from rag.vector_store import VectorStoreManager
from utils.logger import get_logger
from utils.runtime_state import get_runtime_state

logger = get_logger(__name__)


class RAGRetriever:
    """
    Qdrant VectorStore 기반 Retriever 헬퍼 클래스.

    LangChain의 as_retriever() 를 사용해 VectorStore Retriever를 생성한다.
    """

    def __init__(
        self,
        vector_store_manager: VectorStoreManager | None = None,
        top_k: int = RETRIEVER_TOP_K,
    ) -> None:
        """
        Args:
            vector_store_manager: VectorStore 매니저.
            top_k: 검색 결과 상위 k개.
        """
        self.vector_store_manager = vector_store_manager or VectorStoreManager()
        self.top_k = top_k
        self._retriever: BaseRetriever | None = None

    def get_retriever(self) -> BaseRetriever:
        """
        LangChain VectorStore Retriever를 반환한다.

        Returns:
            BaseRetriever 인스턴스.
        """
        if self._retriever is None:
            store = self.vector_store_manager.get_vector_store()
            self._retriever = store.as_retriever(
                search_kwargs={"k": self.top_k}
            )
            logger.info("Retriever 생성 완료 (top_k=%d)", self.top_k)
        return self._retriever

    def search(self, query: str, top_k: int | None = None) -> list[Document]:
        """
        질문에 대한 관련 Document를 검색한다.

        Args:
            query: 사용자 질문.
            top_k: 선택적 상위 k (지정 시 임시 검색).

        Returns:
            Document 리스트.
        """
        query = (query or "").strip()
        if not query:
            return []

        k = top_k or self.top_k
        store = self.vector_store_manager.get_vector_store()
        try:
            documents = store.similarity_search(query, k=k)
        except Exception as exc:  # noqa: BLE001
            logger.exception("RAG 검색 실패: %s", exc)
            raise

        # UI의 RAG Search Result 탭에서 표시할 수 있도록 상태 저장
        serialized = [self.document_to_dict(doc) for doc in documents]
        get_runtime_state().set_search_results(serialized)
        logger.info("RAG 검색 완료: query='%s', hits=%d", query[:80], len(documents))
        return documents

    @staticmethod
    def document_to_dict(doc: Document) -> dict[str, Any]:
        """Document를 UI 표시용 dict로 변환한다."""
        return {
            "content": doc.page_content,
            "metadata": dict(doc.metadata or {}),
        }

    @staticmethod
    def format_documents(documents: list[Document]) -> str:
        """
        Tool 출력용으로 Document 목록을 문자열로 포맷한다.

        Args:
            documents: 검색된 Document 리스트.

        Returns:
            Markdown 형식 문자열.
        """
        if not documents:
            return "관련 문서를 찾지 못했습니다."

        parts: list[str] = ["## RAG 검색 결과\n"]
        for idx, doc in enumerate(documents, start=1):
            source = doc.metadata.get("source", "unknown")
            doc_type = doc.metadata.get("doc_type", "unknown")
            parts.append(f"### [{idx}] source={source} | type={doc_type}")
            parts.append(doc.page_content.strip())
            parts.append("")
        return "\n".join(parts)
