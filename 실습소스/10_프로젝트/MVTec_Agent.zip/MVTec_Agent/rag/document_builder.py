"""
RAG용 Document 생성기.

MVTec 데이터셋 설명, README, 폴더 구조, 클래스 정보를
LangChain Document 로 변환한다.
"""

from __future__ import annotations

from typing import Any

from langchain_core.documents import Document

from config import MVTEC_CLASS_INFO
from utils.dataset import DatasetManager
from utils.logger import get_logger

logger = get_logger(__name__)


class DocumentBuilder:
    """
    Vector DB에 저장할 Document 목록을 구축하는 클래스.

    최초 실행 시:
      1) MVTec 데이터셋 개요
      2) README / license
      3) 폴더 구조
      4) 각 클래스 정보
    를 Document로 생성한다.
    """

    def __init__(self, dataset_manager: DatasetManager | None = None) -> None:
        """
        Args:
            dataset_manager: 데이터셋 접근용 매니저.
        """
        self.dataset = dataset_manager or DatasetManager()

    def build_documents(self) -> list[Document]:
        """
        RAG용 Document 전체 목록을 생성한다.

        Returns:
            LangChain Document 리스트.
        """
        documents: list[Document] = []
        documents.append(self._build_overview_document())
        documents.extend(self._build_readme_documents())
        documents.append(self._build_structure_document())
        documents.extend(self._build_class_documents())
        documents.extend(self._build_defect_knowledge_documents())

        logger.info("RAG Document 생성 완료: %d개", len(documents))
        return documents

    def _build_overview_document(self) -> Document:
        """MVTec AD 데이터셋 전체 설명 Document."""
        overview = self.dataset.get_dataset_overview()
        classes = ", ".join(overview["classes"])
        content = f"""
# MVTec Anomaly Detection (MVTec AD) Dataset Overview

MVTec AD는 산업용 외관 검사(Visual Inspection) 및
비지도 이상 탐지(Unsupervised Anomaly Detection) 연구를 위한
벤치마크 데이터셋이다.

## 핵심 특징
- 실제 산업 제품/텍스처 이미지로 구성
- 클래스마다 train(정상만) / test(정상+불량) 구조
- 일부 클래스는 ground_truth 불량 마스크 제공
- Object 타입과 Texture 타입으로 구분

## 본 프로젝트에 포함된 클래스 수
{overview["num_classes"]}개

## 클래스 목록
{classes}

## 활용 목적
- 불량 유형에 대한 텍스트 QA
- 업로드 이미지 Vision 분석과 RAG 지식 결합
- 클래스별 불량 특징 설명

## 라이선스
Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)
학술/비상업 용도로 사용한다.
""".strip()
        return Document(
            page_content=content,
            metadata={
                "source": "dataset_overview",
                "doc_type": "overview",
                "language": "ko",
            },
        )

    def _build_readme_documents(self) -> list[Document]:
        """README / license 텍스트 Document."""
        docs: list[Document] = []
        for relative in ("readme.txt", "license.txt"):
            text = self.dataset.read_text_file(relative)
            if not text.strip():
                continue
            docs.append(
                Document(
                    page_content=f"# MVTec {relative}\n\n{text.strip()}",
                    metadata={
                        "source": relative,
                        "doc_type": "readme" if "readme" in relative else "license",
                    },
                )
            )
        if not docs:
            # ZIP에서 읽지 못한 경우 최소 README 대체본
            docs.append(
                Document(
                    page_content=(
                        "# MVTec AD README (fallback)\n\n"
                        "MVTec AD는 CVPR 2019에서 소개된 산업용 이상 탐지 데이터셋이다. "
                        "인용: Bergmann et al., A Comprehensive Real-World Dataset for "
                        "Unsupervised Anomaly Detection, CVPR 2019."
                    ),
                    metadata={"source": "readme_fallback", "doc_type": "readme"},
                )
            )
        return docs

    def _build_structure_document(self) -> Document:
        """폴더 구조 Document."""
        content = self.dataset.get_folder_structure_summary()
        return Document(
            page_content=content,
            metadata={
                "source": "folder_structure",
                "doc_type": "structure",
            },
        )

    def _build_class_documents(self) -> list[Document]:
        """각 클래스별 상세 정보 Document."""
        docs: list[Document] = []
        for class_name in self.dataset.list_classes() or list(MVTEC_CLASS_INFO.keys()):
            info = self.dataset.get_class_info(class_name)
            defects = ", ".join(info["defects"]) if info["defects"] else "정보 없음"
            content = f"""
# MVTec Class: {info['class_name']}

## 카테고리
{info['category']}

## 설명
{info['description']}

## 주요 불량 유형 (defect types)
{defects}

## 폴더 구조
{info.get('folder_structure') or '(디스크에 클래스 폴더가 아직 없습니다)'}

## QA 힌트
- "{info['class_name']} 클래스 설명" → 이 클래스의 제품/불량 요약
- "{info['class_name']} 스크래치" 등 불량명 질문 → 관련 defect 설명 참고
""".strip()
            docs.append(
                Document(
                    page_content=content,
                    metadata={
                        "source": f"class:{info['class_name']}",
                        "doc_type": "class_info",
                        "class_name": info["class_name"],
                        "category": str(info["category"]),
                    },
                )
            )
        return docs

    def _build_defect_knowledge_documents(self) -> list[Document]:
        """
        불량 유형에 대한 일반 지식 Document.

        예: scratch, crack 등 공통 불량 특징을 RAG가 답변할 수 있게 한다.
        """
        knowledge: list[tuple[str, str]] = [
            (
                "scratch",
                "스크래치(scratch)는 표면이 긁혀 선형 또는 곡선 형태의 흔적이 남는 불량이다. "
                "capsule, pill, wood, metal_nut, screw 등에서 자주 관찰된다. "
                "조명 반사 변화가 선명하고, 정상 텍스처의 연속성이 끊긴다.",
            ),
            (
                "crack",
                "균열(crack)은 표면 또는 본체가 갈라진 불량이다. "
                "capsule, hazelnut, pill, tile에서 흔하다. "
                "어두운 선/틈으로 보이며 제품 윤곽과 다른 불연속 경계를 만든다.",
            ),
            (
                "contamination",
                "오염(contamination)은 이물질, 얼룩, 잔여물이 표면에 부착된 불량이다. "
                "bottle, pill 등에서 관찰되며 색상/질감이 주변과 달라 보인다.",
            ),
            (
                "hole",
                "구멍(hole)은 표면이 뚫리거나 결손된 불량이다. "
                "carpet, hazelnut, leather, wood 등에서 나타난다.",
            ),
            (
                "cut",
                "절단(cut)은 칼자국처럼 날카로운 절개 흔적이다. "
                "carpet, hazelnut, leather 등 텍스처/객체에서 관찰된다.",
            ),
            (
                "color",
                "색상 이상(color)은 정상 색 분포에서 벗어난 얼룩/변색이다. "
                "carpet, leather, metal_nut, pill, wood에서 자주 등장한다.",
            ),
            (
                "broken",
                "파손(broken)은 형태가 깨지거나 조각이 분리된 상태다. "
                "bottle의 broken_large/broken_small, grid의 broken, zipper의 broken_teeth 등이 해당한다.",
            ),
            (
                "faulty_imprint",
                "인쇄 불량(faulty_imprint)은 각인/인쇄가 흐리거나 누락·왜곡된 경우다. "
                "capsule, pill에서 관찰된다.",
            ),
        ]

        docs: list[Document] = []
        for defect_name, description in knowledge:
            content = f"""
# Defect Knowledge: {defect_name}

## 설명
{description}

## 검색 키워드
{defect_name}, 불량, 이상, anomaly, defect feature
""".strip()
            docs.append(
                Document(
                    page_content=content,
                    metadata={
                        "source": f"defect:{defect_name}",
                        "doc_type": "defect_knowledge",
                        "defect_name": defect_name,
                    },
                )
            )
        return docs

    def build_as_dicts(self) -> list[dict[str, Any]]:
        """디버깅용으로 Document를 dict 리스트로 변환한다."""
        return [
            {"content": d.page_content, "metadata": d.metadata}
            for d in self.build_documents()
        ]
