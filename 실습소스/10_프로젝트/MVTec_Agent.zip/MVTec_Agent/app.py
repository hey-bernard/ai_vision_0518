"""
MVTec_Agent 메인 실행 파일.

실행:
    streamlit run app.py

흐름:
1) C:\\env\\.env 에서 OPENAI_API_KEY 로드
2) MVTec ZIP 자동 압축 해제 (필요 시)
3) Vector DB(Qdrant) 최초 구축 또는 재사용
4) create_agent() 기반 Visual RAG Agent UI 제공

주의:
- Jupyter Notebook 미사용
- 로컬 GPU 미사용 (모든 추론은 OpenAI API)
- API Key를 코드에 하드코딩하지 않음
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

# ---------------------------------------------------------------------------
# 프로젝트 루트를 sys.path에 추가 (모듈 import 안정화)
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import (  # noqa: E402
    ENV_FILE_PATH,
    LLM_MODEL_NAME,
    MVTEC_DATA_DIR,
    VECTOR_DB_READY_MARKER,
    ensure_directories,
)
from models.agent import MVTecAgent  # noqa: E402
from pages._image_analysis import render_image_analysis_tab  # noqa: E402
from pages._rag_result import render_rag_result_tab  # noqa: E402
from pages._system_log import render_system_log_tab  # noqa: E402
from pages._text_qa import render_text_qa_tab  # noqa: E402
from rag.retriever import RAGRetriever  # noqa: E402
from rag.vector_store import VectorStoreManager  # noqa: E402
from utils.dataset import DatasetManager  # noqa: E402
from utils.env_loader import EnvLoadError, load_api_key  # noqa: E402
from utils.logger import get_logger, setup_logging  # noqa: E402

setup_logging()
logger = get_logger(__name__)


def _init_session_services() -> tuple[MVTecAgent, DatasetManager, VectorStoreManager]:
    """
    Streamlit 세션에 Agent / Dataset / VectorStore를 초기화한다.

    Returns:
        (agent, dataset_manager, vector_store_manager)
    """
    if "services_ready" in st.session_state:
        return (
            st.session_state["agent"],
            st.session_state["dataset_manager"],
            st.session_state["vector_store_manager"],
        )

    ensure_directories()

    # 1) API Key
    load_api_key()

    # 2) Dataset 압축 해제
    dataset_manager = DatasetManager()
    dataset_manager.ensure_extracted()

    # 3) Vector DB 구축 또는 재사용
    vector_store_manager = VectorStoreManager()
    vector_store_manager.build_or_load(force_rebuild=False)

    # 4) Agent (create_agent + tools)
    retriever = RAGRetriever(vector_store_manager=vector_store_manager)
    agent = MVTecAgent(
        retriever=retriever,
        dataset_manager=dataset_manager,
    )

    st.session_state["dataset_manager"] = dataset_manager
    st.session_state["vector_store_manager"] = vector_store_manager
    st.session_state["agent"] = agent
    st.session_state["services_ready"] = True
    logger.info("세션 서비스 초기화 완료")
    return agent, dataset_manager, vector_store_manager


def _render_sidebar(
    dataset_manager: DatasetManager,
    vector_store_manager: VectorStoreManager,
) -> None:
    """
    사이드바: 프로젝트 설명 / 데이터셋 정보 / Vector DB 상태.

    Args:
        dataset_manager: DatasetManager.
        vector_store_manager: VectorStoreManager.
    """
    with st.sidebar:
        st.header("MVTec_Agent")
        st.markdown(
            """
**Visual RAG AI Agent**

MVTec AD 데이터셋 지식을 RAG로 검색하고,
업로드 이미지를 OpenAI Vision으로 분석하는
Streamlit + LangChain Agent 입니다.
            """
        )

        st.divider()
        st.subheader("데이터셋 정보")
        overview = dataset_manager.get_dataset_overview()
        st.write(f"- 이름: **{overview['name']}**")
        st.write(f"- 클래스 수: **{overview['num_classes']}**")
        st.write(f"- 압축 해제: **{'완료' if overview['extracted'] else '미완료'}**")
        st.write(f"- 경로: `{overview['path']}`")
        with st.expander("클래스 목록"):
            st.write(", ".join(overview["classes"]))

        st.divider()
        st.subheader("Vector DB")
        ready = vector_store_manager.is_ready() or VECTOR_DB_READY_MARKER.exists()
        if ready:
            st.success("Vector DB 생성됨 (재사용 가능)")
        else:
            st.warning("Vector DB 미생성")

        st.caption(f"LLM: `{LLM_MODEL_NAME}` (OpenAI API)")
        st.caption(f"ENV: `{ENV_FILE_PATH}`")
        st.caption("로컬 GPU: 사용 안 함")

        st.divider()
        if st.button("Vector DB 재구축", help="Document를 다시 Embedding 합니다."):
            with st.spinner("Vector DB 재구축 중..."):
                try:
                    vector_store_manager.build_or_load(force_rebuild=True)
                    # retriever/agent 캐시 갱신
                    retriever = RAGRetriever(vector_store_manager=vector_store_manager)
                    st.session_state["agent"] = MVTecAgent(
                        retriever=retriever,
                        dataset_manager=dataset_manager,
                    )
                    st.success("재구축 완료")
                except Exception as exc:  # noqa: BLE001
                    st.error(f"재구축 실패: {exc}")


def main() -> None:
    """Streamlit 애플리케이션 엔트리포인트."""
    st.set_page_config(
        page_title="Visual RAG AI Agent",
        page_icon="🔍",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    st.title("Visual RAG AI Agent")
    st.markdown(
        "MVTec AD 기반 **Text QA + Image Analysis** Agent  "
        f"| 데이터 경로: `{MVTEC_DATA_DIR}`"
    )

    try:
        with st.spinner("초기화 중 (환경변수 / 데이터셋 / Vector DB / Agent)..."):
            agent, dataset_manager, vector_store_manager = _init_session_services()
    except EnvLoadError as exc:
        st.error(str(exc))
        st.info(
            "해결 방법:\n"
            "1) `C:\\env\\.env` 파일을 생성\n"
            "2) `OPENAI_API_KEY=sk-...` 형식으로 저장\n"
            "3) 앱을 다시 실행"
        )
        st.stop()
    except FileNotFoundError as exc:
        st.error(str(exc))
        st.stop()
    except Exception as exc:  # noqa: BLE001
        logger.exception("앱 초기화 실패")
        st.error(f"초기화 실패: {exc}")
        st.stop()

    _render_sidebar(dataset_manager, vector_store_manager)

    tab_qa, tab_image, tab_rag, tab_log = st.tabs(
        ["Text QA", "Image Analysis", "RAG Search Result", "System Log"]
    )

    with tab_qa:
        render_text_qa_tab(agent)
    with tab_image:
        render_image_analysis_tab(agent)
    with tab_rag:
        render_rag_result_tab()
    with tab_log:
        render_system_log_tab()


if __name__ == "__main__":
    main()
