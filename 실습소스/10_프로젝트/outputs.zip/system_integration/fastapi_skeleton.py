
# app_main.py (배포용 스케치)
from fastapi import FastAPI
# from modules import VisionModule, SensorModule, FusionService, VisualAIWebService

app = FastAPI(title="PCB AOI Visual AI")
# service = VisualAIWebService(...)

@app.get("/health")
def health():
    return service.health()

@app.post("/analyze")
def analyze(payload: dict):
    # payload: {lot_id, image(list), sensor(list[dict])}
    ...

@app.post("/feedback")
def feedback(payload: dict):
    # payload: {lot_id, predicted_level, actual_level, note}
    ...
