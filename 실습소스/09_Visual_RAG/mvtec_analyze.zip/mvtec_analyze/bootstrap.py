"""mvtec_analyze 프로젝트 루트 및 conveyor_analyze(SigLIP2) 경로 등록."""

import sys
from pathlib import Path

# 이 파일이 있는 디렉터리 = mvtec_analyze 패키지 루트
ROOT = Path(__file__).resolve().parent
# SigLIP2Encoder 등 공유 모델 코드는 conveyor_analyze에 있으므로 형제 경로 참조
CONVEYOR_ROOT = ROOT.parent / "conveyor_analyze"

# mvtec_analyze 최우선 — api.main 이 conveyor api 와 이름 충돌하지 않도록
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
# conveyor_rag import 전용 — append 로 api 패키지 우선순위 유지
if str(CONVEYOR_ROOT) not in sys.path:
    sys.path.append(str(CONVEYOR_ROOT))
