"""FastAPI 요청/응답 스키마."""

from pydantic import BaseModel, Field


class InspectionQuery(BaseModel):
    """POST /inspections/query — JSON body로 필터 전달 (GET 쿼리스트링과 동일 필드)."""
    product: str | None = None
    label: str | None = Field(None, description="정상 또는 불량")
    defect_type: str | None = None
    source: str | None = None
    date_from: str | None = None
    date_to: str | None = None
    limit: int = Field(50, ge=1, le=500)
    offset: int = Field(0, ge=0)


class SQLQueryRequest(BaseModel):
    """POST /sql — 노트북 SQL 실습용. params는 ? placeholder 바인딩 값."""
    sql: str = Field(..., description="SELECT 쿼리만 허용")
    params: list = Field(default_factory=list)


class SearchRequest(BaseModel):
    """POST /search — 텍스트 쿼리를 SigLIP2 임베딩 후 ChromaDB 검색."""
    query: str
    product: str | None = None
    top_k: int = Field(5, ge=1, le=20)


class UploadInspectRequest(BaseModel):
    """multipart /upload 보조 스키마 (실제 업로드는 Form+File 사용)."""
    product: str = "bottle"
    save_to_db: bool = True
    # True면 SigLIP2 1차 판정 후 Qwen3-VL 상세 분석 추가 (VRAM·시간 추가 소요)
    use_qwen: bool = False


class AnalyzeRequest(BaseModel):
    """POST /analyze — SigLIP2 + Qwen3-VL Visual RAG 분석 (DB 저장 이력 대상)."""
    record_id: int | None = Field(None, description="DB 검사 이력 ID")
    product: str | None = None
    query: str = Field(
        "이 산업 부품 검사 이미지의 표면 결함을 분석하세요.",
        description="Qwen3-VL 분석 질의",
    )
    # SigLIP2·Qwen 각각 on/off 가능 — 둘 다 True면 Visual RAG 전체 파이프라인
    use_siglip: bool = Field(True, description="SigLIP2 1차 판정 포함")
    use_qwen: bool = Field(True, description="Qwen3-VL 상세 분석 포함")
    update_db: bool = Field(True, description="analysis_text DB 갱신")
