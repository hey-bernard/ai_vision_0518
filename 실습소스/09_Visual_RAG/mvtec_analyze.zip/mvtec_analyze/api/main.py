"""FastAPI REST API — MVTec AD 산업 결함 검사."""

import bootstrap  # noqa: F401 — sys.path 등록 (반드시 최상단)

import shutil
import uuid
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from api.schemas import AnalyzeRequest, InspectionQuery, SQLQueryRequest, SearchRequest
from conveyor_rag.analyzer import QwenAnalyzer
from conveyor_rag.encoder import SigLIP2Encoder
from mvtec_rag.config import API_PORT, PRODUCTS, TOP_K_DEFAULT, UPLOAD_DIR
from mvtec_rag.dataset import index_dataset
from mvtec_rag.db import InspectionDB
from mvtec_rag.detector import MVTecDefectDetector
from mvtec_rag.store import MVTecStore
from mvtec_rag.vl_analyzer import MVTecVLAnalyzer


@lru_cache(maxsize=1)
def get_encoder() -> SigLIP2Encoder:
    # SigLIP2는 VRAM 사용 — 프로세스당 1회만 로드 (싱글톤)
    return SigLIP2Encoder()


@lru_cache(maxsize=1)
def get_store() -> MVTecStore:
    return MVTecStore()


@lru_cache(maxsize=1)
def get_detector() -> MVTecDefectDetector:
    # encoder + store 공유 — 업로드 판정 시 동일 인스턴스 재사용
    return MVTecDefectDetector(get_encoder(), get_store())


@lru_cache(maxsize=1)
def get_vl_analyzer() -> MVTecVLAnalyzer:
    # Qwen3-VL + MVTec 프롬프트 빌더 — /upload·/analyze 에서 use_qwen=True 시 사용
    return MVTecVLAnalyzer(QwenAnalyzer())


def _release_encoder_gpu() -> None:
    """Qwen3-VL 로드 전 SigLIP2 GPU 메모리 해제."""
    encoder = get_encoder()
    encoder.unload()
    get_encoder.cache_clear()
    # detector가 unload된 encoder 참조를 들고 있으면 다음 SigLIP2 요청 500 발생
    get_detector.cache_clear()


def _merge_analysis_text(siglip_text: str, qwen_text: str | None) -> str:
    # DB analysis_text·API 응답에 SigLIP2 + Qwen 결과를 구분해 저장
    if qwen_text:
        return f"{siglip_text}\n\n--- Qwen3-VL ---\n{qwen_text}"
    return siglip_text


# API 프로세스 전역 DB — uvicorn worker 1개 기준 (멀티 worker 시 worker별 DB 연결)
db = InspectionDB()

app = FastAPI(
    title="MVTec AD Visual Inspection API",
    description="SigLIP2 + Qwen3-VL + SQLite + ChromaDB 산업 결함 검사 REST API",
    version="1.0.0",
)

# Streamlit·노트북 requests — 브라우저 CORS 허용
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    stats = db.stats()
    return {
        "service": "MVTec AD Visual Inspection API",
        "endpoints": [
            "/inspections", "/inspections/{id}", "/stats", "/products",
            "/search", "/upload", "/analyze", "/index", "/sql", "/image/{id}",
        ],
        "db_count": db.count(),
        "chroma_count": get_store().count(),
        "defect_rate": stats["defect_rate"],
    }


@app.get("/products")
def list_products():
    return {"products": PRODUCTS}


@app.post("/index")
def run_index(clear: bool = Query(False)):
    """MVTec test 데이터셋 → SQLite + ChromaDB 인덱싱."""
    result = index_dataset(
        db=db,
        store=get_store(),
        encoder=get_encoder(),
        build_chroma=True,
        clear_existing=clear,
    )
    return result


@app.get("/inspections")
def get_inspections(
    product: str | None = None,
    label: str | None = None,
    defect_type: str | None = None,
    source: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
):
    """검사 이력 조회 — 품목·정상/불량·날짜 필터."""
    rows = db.query(
        product=product, label=label, defect_type=defect_type,
        source=source, date_from=date_from, date_to=date_to,
        limit=limit, offset=offset,
    )
    return {"count": len(rows), "total": db.count(), "inspections": rows}


@app.post("/inspections/query")
def query_inspections(req: InspectionQuery):
    # GET과 동일 로직 — POST body로 복잡한 필터 전달 시 사용
    rows = db.query(**req.model_dump())
    return {"count": len(rows), "inspections": rows}


@app.get("/inspections/{record_id}")
def get_inspection(record_id: int):
    row = db.get_by_id(record_id)
    if row is None:
        raise HTTPException(404, f"검사 이력 없음: id={record_id}")
    return row


@app.get("/image/{record_id}")
def get_inspection_image(record_id: int):
    # 검사 ID → image_path → FileResponse (브라우저에서 직접 이미지 표시)
    row = db.get_by_id(record_id)
    if row is None:
        raise HTTPException(404, f"이미지 없음: id={record_id}")
    path = Path(row["image_path"])
    if not path.exists():
        raise HTTPException(404, f"파일 없음: {path}")
    return FileResponse(path)


@app.get("/stats")
def get_stats(
    product: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
):
    """불량률·이상 발생 건수 통계."""
    return db.stats(product=product, date_from=date_from, date_to=date_to)


@app.post("/sql")
def run_sql(req: SQLQueryRequest):
    """노트북 실습용 SQL SELECT 실행."""
    try:
        rows = db.execute_sql(req.sql, tuple(req.params))
        return {"count": len(rows), "rows": rows}
    except Exception as e:
        raise HTTPException(400, str(e)) from e


@app.post("/search")
def search_images(req: SearchRequest):
    """텍스트 → SigLIP2 → ChromaDB 유사 이미지 검색."""
    store = get_store()
    if store.count() == 0:
        raise HTTPException(503, "ChromaDB 비어 있음 — /index 먼저 실행하세요.")
    encoder = get_encoder()
    query_emb = encoder.encode_texts([req.query])[0].tolist()
    hits = store.search(query_emb, top_k=req.top_k, product=req.product)
    return {"query": req.query, "top_k": req.top_k, "results": hits}


@app.get("/search")
def search_images_get(
    query: str = Query(...),
    product: str | None = None,
    top_k: int = Query(TOP_K_DEFAULT, ge=1, le=20),
):
    # curl·브라우저 GET 테스트용 — POST /search 와 동일
    return search_images(SearchRequest(query=query, product=product, top_k=top_k))


@app.post("/upload")
async def upload_and_inspect(
    file: UploadFile = File(...),
    product: str = Form("bottle"),
    save_to_db: bool = Form(True),
    use_qwen: bool = Form(False),
):
    """이미지 업로드 → SigLIP2 불량 판정 → (선택) Qwen3-VL 상세 분석 → DB 저장."""
    try:
        return await _upload_and_inspect_impl(file, product, save_to_db, use_qwen)
    except Exception as e:
        # Streamlit·노트북에서 원인 파악 가능하도록 detail 메시지 포함
        raise HTTPException(500, f"upload 실패: {type(e).__name__}: {e}") from e


async def _upload_and_inspect_impl(
    file: UploadFile,
    product: str,
    save_to_db: bool,
    use_qwen: bool,
):
    """업로드 처리 본체 — Visual RAG: SigLIP2(필수) → Qwen(선택)."""
    if product not in PRODUCTS:
        raise HTTPException(400, f"품목은 {PRODUCTS} 중 하나여야 합니다.")

    suffix = Path(file.filename or "upload.png").suffix or ".png"
    save_name = f"{uuid.uuid4().hex}{suffix}"  # 파일명 충돌 방지
    save_path = UPLOAD_DIR / save_name

    with save_path.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    # 1단계: SigLIP2 1차 판정 (항상 실행)
    detector = get_detector()
    result = detector.detect(save_path, product=product)

    qwen_analysis = None
    if use_qwen:
        # 12GB VRAM: SigLIP2·Qwen 동시 상주 불가 → GPU 해제 후 Qwen 로드
        _release_encoder_gpu()
        qwen_analysis = get_vl_analyzer().analyze(
            save_path,
            product=product,
            siglip_judgment=result,
        )

    full_analysis = _merge_analysis_text(result["analysis_text"], qwen_analysis)

    record = None
    if save_to_db:
        record = db.insert(
            product=product,
            defect_type=result["defect_type"],
            label=result["label"],
            image_path=str(save_path.resolve()),
            source="upload",
            confidence=result["confidence"],
            analysis_text=full_analysis,
            created_at=datetime.now(timezone.utc).isoformat(),
        )

    return {
        "filename": save_name,
        "saved_path": str(save_path),
        "judgment": result,
        "qwen_analysis": qwen_analysis,
        "analysis_text": full_analysis,
        "record": record,
    }


@app.post("/analyze")
def analyze_inspection(req: AnalyzeRequest):
    """Visual RAG: SigLIP2 1차 판정 + Qwen3-VL 상세 분석 (DB 저장 이력 대상)."""
    if req.record_id is None:
        raise HTTPException(400, "record_id 가 필요합니다.")

    row = db.get_by_id(req.record_id)
    if row is None:
        raise HTTPException(404, f"검사 이력 없음: id={req.record_id}")

    image_path = Path(row["image_path"])
    if not image_path.exists():
        raise HTTPException(404, f"이미지 파일 없음: {image_path}")

    product = req.product or row["product"]
    siglip_result = None

    if req.use_siglip:
        # 기존 SigLIP2 1차 판정 — 빠른 label/defect_type/confidence 산출
        siglip_result = get_detector().detect(image_path, product=product)

    qwen_analysis = None
    if req.use_qwen:
        _release_encoder_gpu()
        # 사용자 query + (선택) SigLIP2 결과를 프롬프트에 포함
        qwen_analysis = get_vl_analyzer().analyze(
            image_path,
            product=product,
            query=req.query,
            siglip_judgment=siglip_result,
        )

    # SigLIP2만 실행한 경우 기존 DB analysis_text 유지
    siglip_text = siglip_result["analysis_text"] if siglip_result else row.get("analysis_text", "")
    full_analysis = _merge_analysis_text(siglip_text, qwen_analysis)

    updated = None
    if req.update_db and (siglip_result or qwen_analysis):
        updated = db.update_analysis(
            req.record_id,
            analysis_text=full_analysis,
            label=siglip_result["label"] if siglip_result else None,
            defect_type=siglip_result["defect_type"] if siglip_result else None,
            confidence=siglip_result["confidence"] if siglip_result else None,
        )

    return {
        "record_id": req.record_id,
        "product": product,
        "siglip_judgment": siglip_result,
        "qwen_analysis": qwen_analysis,
        "analysis_text": full_analysis,
        "updated_record": updated,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.main:app", host="127.0.0.1", port=API_PORT, reload=True)
