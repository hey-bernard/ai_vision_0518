"""MVTec AD FastAPI 패키지 (conveyor_analyze/api 와 이름 분리)."""
