"""MVTec AD FastAPI 서버 실행."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONVEYOR = ROOT.parent / "conveyor_analyze"

# uvicorn reload 자식 프로세스에서도 mvtec api.main 이 로드되도록 경로 고정
sys.path.insert(0, str(ROOT))
if str(CONVEYOR) not in sys.path:
    sys.path.append(str(CONVEYOR))

import bootstrap  # noqa: F401 — conveyor_rag 등 추가 경로
import uvicorn

from mvtec_rag.config import API_PORT

if __name__ == "__main__":
    # reload=True — 개발 중 api/*.py 수정 시 자동 재시작
    uvicorn.run(
        "api.main:app",
        host="127.0.0.1",
        port=API_PORT,
        reload=True,
        reload_dirs=[str(ROOT)],
    )
