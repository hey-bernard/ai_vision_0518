"""MVTec test 데이터셋 → SQLite + ChromaDB 인덱싱 CLI."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import bootstrap  # noqa: F401

from mvtec_rag.dataset import index_dataset

if __name__ == "__main__":
    # python run_index.py --clear → 기존 DB·Chroma 삭제 후 재인덱싱
    clear = "--clear" in sys.argv
    result = index_dataset(clear_existing=clear, build_chroma=True)
    print(result)
