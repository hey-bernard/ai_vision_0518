"""MVTec AD 산업 결함 검사 Streamlit 웹 UI."""

import sys
from datetime import date, datetime, timedelta
from pathlib import Path

# dashboard/ 에서 mvtec_analyze 루트 import 가능하도록
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pandas as pd
import requests
import streamlit as st
from PIL import Image

from mvtec_rag.config import API_BASE_URL_DEFAULT, DATA_DIR, PRODUCTS

API_BASE = API_BASE_URL_DEFAULT

st.set_page_config(page_title="MVTec AD 검사", page_icon="🔬", layout="wide")
st.title("🔬 MVTec AD 산업 결함 검사 서비스")
st.caption("SigLIP2 1차 판정 · Qwen3-VL 상세 분석 · SQLite DB · 통계 대시보드")

# 다른 포트·원격 API 사용 시 사이드바에서 URL 변경
api_url = st.sidebar.text_input("API URL", value=API_BASE)


def api_get(path: str, params: dict | None = None):
    r = requests.get(f"{api_url}{path}", params=params, timeout=120)
    r.raise_for_status()
    return r.json()


def api_post(path: str, payload: dict | None = None, files=None, data=None, timeout=300):
    r = requests.post(f"{api_url}{path}", json=payload, files=files, data=data, timeout=timeout)
    if not r.ok:
        detail = r.text[:500]
        raise requests.HTTPError(f"{r.status_code} {detail}", response=r)
    return r.json()


try:
    health = api_get("/")
    st.sidebar.success(f"API 연결됨 (DB {health['db_count']}건)")
except Exception:
    st.sidebar.error("API 미연결")
    st.sidebar.code("cd mvtec_analyze\npython scripts/run_api.py", language="bash")

tab_upload, tab_query, tab_analyze, tab_stats, tab_search = st.tabs(
    ["📤 업로드·판정", "📋 조회", "🤖 Qwen 분석", "📊 통계", "🔍 유사 검색"]
)

with tab_upload:
    st.subheader("이미지 업로드 → AI 불량 판정 → DB 저장")
    col1, col2 = st.columns([1, 1])
    with col1:
        product = st.selectbox("품목", PRODUCTS, index=0)
        uploaded = st.file_uploader("검사 이미지", type=["png", "jpg", "jpeg"])
        save_db = st.checkbox("DB에 저장", value=True)
        # Qwen3-VL: SigLIP2 1차 판정 후 VLM 상세 설명 추가 (GPU 순차 로드, 수 분 소요)
        use_qwen = st.checkbox("Qwen3-VL 상세 분석 포함", value=False)
        if st.button("AI 판정 실행", type="primary") and uploaded:
            spinner_msg = "SigLIP2 + Qwen3-VL 분석 중 (수 분)..." if use_qwen else "SigLIP2 불량 판정 중..."
            with st.spinner(spinner_msg):
                files = {"file": (uploaded.name, uploaded.getvalue(), uploaded.type)}
                data = {
                    "product": product,
                    "save_to_db": str(save_db).lower(),
                    "use_qwen": str(use_qwen).lower(),  # Form 필드 — API에서 bool 파싱
                }
                timeout = 900 if use_qwen else 300  # Qwen 실행 시 HTTP 타임아웃 연장
                result = api_post("/upload", files=files, data=data, timeout=timeout)
                st.session_state["last_upload"] = result
    with col2:
        if "last_upload" in st.session_state:
            r = st.session_state["last_upload"]
            j = r["judgment"]
            label_color = "🔴" if j["label"] == "불량" else "🟢"
            st.metric(f"{label_color} 판정", j["label"])
            st.metric("신뢰도", f"{j['confidence']:.1%}")
            st.metric("결함 유형", j["defect_type"])
            st.info(j["analysis_text"])  # SigLIP2 유사도·판정 요약
            if r.get("qwen_analysis"):
                st.markdown("#### Qwen3-VL 상세 분석")
                st.success(r["qwen_analysis"])
            if r.get("record"):
                st.success(f"DB 저장 완료 — ID #{r['record']['id']}")
            img = Image.open(r["saved_path"])
            st.image(img, caption=r["filename"], use_container_width=True)

with tab_query:
    st.subheader("품목별 · 정상/불량 · 날짜별 조회")
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        q_product = st.selectbox("품목 필터", ["전체"] + PRODUCTS)
    with c2:
        q_label = st.selectbox("판정 필터", ["전체", "정상", "불량"])
    with c3:
        q_date_from = st.date_input("시작일", value=date.today() - timedelta(days=60))
    with c4:
        q_date_to = st.date_input("종료일", value=date.today())

    params = {"limit": 100}
    if q_product != "전체":
        params["product"] = q_product
    if q_label != "전체":
        params["label"] = q_label
    # ISO8601 — DB created_at 문자열과 lexicographic 비교
    params["date_from"] = datetime.combine(q_date_from, datetime.min.time()).isoformat()
    params["date_to"] = datetime.combine(q_date_to, datetime.max.time()).isoformat()

    if st.button("조회"):
        data = api_get("/inspections", params)
        df = pd.DataFrame(data["inspections"])
        if df.empty:
            st.warning("조회 결과 없음")
        else:
            st.dataframe(df[["id", "product", "label", "defect_type", "confidence", "source", "created_at"]],
                         use_container_width=True)
            sel_id = st.number_input("이미지 확인 ID", min_value=int(df["id"].min()), max_value=int(df["id"].max()),
                                     value=int(df["id"].iloc[0]))
            rec = api_get(f"/inspections/{int(sel_id)}")
            path = Path(rec["image_path"])
            if path.exists():
                st.image(str(path), caption=f"#{rec['id']} {rec['product']} — {rec['label']}", use_container_width=True)
            st.write(rec.get("analysis_text", ""))

with tab_analyze:
    st.subheader("Qwen3-VL Visual RAG 분석 (SigLIP2 + Qwen)")
    st.caption("DB에 저장된 검사 이력 ID로 SigLIP2 1차 판정 + Qwen3-VL 상세 분석을 실행합니다.")
    a_id = st.number_input("검사 ID", min_value=1, value=1, step=1)
    a_query = st.text_area(
        "분석 질의",
        value="이 산업 부품 검사 이미지의 표면 결함을 분석하세요.",
    )
    c1, c2 = st.columns(2)
    with c1:
        use_siglip = st.checkbox("SigLIP2 1차 판정", value=True, key="analyze_siglip")
    with c2:
        use_qwen_a = st.checkbox("Qwen3-VL 분석", value=True, key="analyze_qwen")
    if st.button("Visual RAG 분석 실행", type="primary"):
        with st.spinner("Qwen3-VL 분석 중 (수 분 소요)..."):
            payload = {
                "record_id": int(a_id),
                "query": a_query,  # MVTecVLAnalyzer 프롬프트에 주입
                "use_siglip": use_siglip,
                "use_qwen": use_qwen_a,
                "update_db": True,  # analysis_text에 SigLIP2 + Qwen 통합 저장
            }
            result = api_post("/analyze", payload, timeout=900)
            st.session_state["last_analyze"] = result
    if "last_analyze" in st.session_state:
        r = st.session_state["last_analyze"]
        if r.get("siglip_judgment"):
            sj = r["siglip_judgment"]
            st.markdown(f"**SigLIP2:** {sj['label']} ({sj['defect_type']}, {sj['confidence']:.1%})")
        if r.get("qwen_analysis"):
            st.markdown("**Qwen3-VL:**")
            st.info(r["qwen_analysis"])
        st.markdown("**통합 analysis_text:**")
        st.write(r.get("analysis_text", ""))  # DB에 저장된 전체 분석 텍스트

with tab_stats:
    st.subheader("불량률 통계")
    s_product = st.selectbox("통계 품목", ["전체"] + PRODUCTS, key="stats_product")
    sp = {}
    if s_product != "전체":
        sp["product"] = s_product
    stats = api_get("/stats", sp)
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("전체", stats["total"])
    m2.metric("정상", stats["normal_count"])
    m3.metric("불량(이상)", stats["defect_count"])
    m4.metric("불량률", f"{stats['defect_rate']}%")

    if stats["by_product"]:
        df_bp = pd.DataFrame(stats["by_product"])
        st.bar_chart(df_bp.set_index("product")[["defect_count", "total"]])
        st.dataframe(df_bp, use_container_width=True)

with tab_search:
    st.subheader("텍스트 유사 이미지 검색")
    sq = st.text_input("검색어", value="bottle with crack defect")
    sp2 = st.selectbox("품목", ["전체"] + PRODUCTS, key="search_product")
    if st.button("검색"):
        payload = {"query": sq, "top_k": 6}
        if sp2 != "전체":
            payload["product"] = sp2
        data = api_post("/search", payload)
        cols = st.columns(3)
        for i, hit in enumerate(data["results"]):
            meta = hit["metadata"]
            with cols[i % 3]:
                p = Path(meta["image_path"])
                if p.exists():
                    st.image(str(p), use_container_width=True)
                st.caption(f"{meta['product']} / {meta['defect_type']} — sim {hit['similarity']:.3f}")

st.sidebar.markdown("---")
st.sidebar.markdown(f"**데이터:** `{DATA_DIR}`")
if st.sidebar.button("데이터셋 인덱싱"):
    with st.spinner("인덱싱 중..."):
        res = api_post("/index")
        st.sidebar.success(f"DB {res['db_count']}건 / Chroma {res['chroma_count']}건")
