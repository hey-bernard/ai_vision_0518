"""MVTec AD 산업 결함 검사 — SQLite + SigLIP2 + Qwen3-VL + ChromaDB.

패키지 구성:
  - db.py         : SQLite 검사 이력 CRUD·SQL·통계
  - dataset.py    : test 이미지 → DB/Chroma 인덱싱
  - eda.py        : train/test EDA·시각화
  - store.py      : ChromaDB 벡터 검색
  - detector.py   : SigLIP2 업로드 불량 1차 판정
  - vl_analyzer.py: Qwen3-VL 상세 결함 분석
"""
