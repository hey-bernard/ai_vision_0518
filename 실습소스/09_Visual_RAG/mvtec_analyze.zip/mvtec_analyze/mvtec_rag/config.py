"""MVTec AD 프로젝트 전역 경로·상수."""

from pathlib import Path

# mvtec_rag/ 의 상위 = mvtec_analyze/
ROOT = Path(__file__).resolve().parent.parent
# 09_Visual_RAG 프로젝트 루트 (노트북 실행 위치)
PROJECT_ROOT = ROOT.parent

# 데이터는 노트북(프로젝트 루트)에서 만든 data/mvtec 우선, 없으면 패키지 내부 fallback
_PROJECT_DATA = PROJECT_ROOT / "data" / "mvtec"
_LOCAL_DATA = ROOT / "data" / "mvtec"
DATA_DIR = _PROJECT_DATA if _PROJECT_DATA.exists() else _LOCAL_DATA

# 원본 ZIP — 압축 해제 전 노트북에서 참조
MVTEC_ZIP = PROJECT_ROOT / "MVTec_581MB.zip"
# SQLite 검사 이력 DB (06 노트북 핵심 산출물)
DB_PATH = DATA_DIR / "inspections.db"
# SigLIP2 이미지 벡터 영구 저장 (ChromaDB PersistentClient)
CHROMA_DIR = DATA_DIR / "chroma_db"
# 웹/API 업로드 이미지 저장 디렉터리
UPLOAD_DIR = DATA_DIR / "uploads"
# (선택) JSON 분석 이력 — conveyor 패턴과 동일 경로 규칙
HISTORY_JSON = DATA_DIR / "analysis_history.json"

# ChromaDB 컬렉션명 — conveyor_siglip2 와 분리
COLLECTION_NAME = "mvtec_siglip2"
# Streamlit·노트북 HTTP 호출 기본 URL (conveyor 8000/8001 과 포트 분리)
API_BASE_URL_DEFAULT = "http://127.0.0.1:8002"
API_PORT = 8002
TOP_K_DEFAULT = 5

# MVTec AD 공식 15개 object category — 폴더명과 1:1 대응
PRODUCTS = [
    "bottle", "cable", "capsule", "carpet", "grid", "hazelnut", "leather",
    "metal_nut", "pill", "screw", "tile", "toothbrush", "transistor", "wood", "zipper",
]

# 최초 import 시 필요한 디렉터리 자동 생성 (압축 해제 전에도 uploads 등은 미리 준비)
for d in (DATA_DIR, CHROMA_DIR, UPLOAD_DIR):
    d.mkdir(parents=True, exist_ok=True)
