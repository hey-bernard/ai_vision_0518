"""MVTec AD test 이미지 스캔 → SQLite·ChromaDB 인덱싱."""

from datetime import datetime, timedelta, timezone
from pathlib import Path

from PIL import Image
from tqdm import tqdm

from conveyor_rag.encoder import SigLIP2Encoder
from mvtec_rag.config import DATA_DIR, PRODUCTS
from mvtec_rag.db import InspectionDB
from mvtec_rag.store import MVTecStore


def _label_from_defect_type(defect_type: str) -> str:
    # MVTec 폴더 구조: test/good/ → 정상, test/{결함명}/ → 불량
    return "정상" if defect_type == "good" else "불량"


def scan_test_images(data_dir: Path = DATA_DIR) -> list[dict]:
    """MVTec test/ 폴더에서 이미지 메타 수집."""
    records = []
    for product in PRODUCTS:
        # 경로 예: data/mvtec/bottle/test/
        test_dir = data_dir / product / "test"
        if not test_dir.exists():
            continue
        # test 아래 하위 폴더 = defect_type (good, broken_large, …)
        for sub in sorted(test_dir.iterdir()):
            if not sub.is_dir():
                continue
            defect_type = sub.name
            for img_path in sorted(sub.glob("*.png")):
                records.append({
                    "product": product,
                    "defect_type": defect_type,
                    "label": _label_from_defect_type(defect_type),
                    "image_path": str(img_path.resolve()),  # 절대 경로 — DB·Chroma 메타에 저장
                })
    return records


def index_dataset(
    db: InspectionDB | None = None,
    store: MVTecStore | None = None,
    encoder: SigLIP2Encoder | None = None,
    build_chroma: bool = True,
    clear_existing: bool = False,
) -> dict:
    """test 이미지를 DB·ChromaDB에 일괄 등록."""
    db = db or InspectionDB()
    records = scan_test_images()

    if clear_existing:
        db.clear()
        if store:
            store.reset()

    if not records:
        return {"indexed": 0, "message": "MVTec test 이미지 없음 — MVTec_581MB.zip 압축 해제 확인"}

    # created_at을 과거 30일간 분산 — 날짜별 조회·통계 실습용 (실제 촬영 시각 아님)
    base_time = datetime.now(timezone.utc) - timedelta(days=30)
    inserted = 0

    for i, rec in enumerate(records):
        ts = (base_time + timedelta(hours=i * 3)).isoformat()
        # 동일 image_path 중복 INSERT 방지 — 재실행 시 idempotent
        existing = db.query(
            product=rec["product"],
            defect_type=rec["defect_type"],
            limit=9999,
        )
        paths = {r["image_path"] for r in existing}
        if rec["image_path"] in paths:
            continue
        db.insert(
            product=rec["product"],
            defect_type=rec["defect_type"],
            label=rec["label"],
            image_path=rec["image_path"],
            source="dataset",
            confidence=1.0 if rec["label"] == "정상" else 0.95,
            analysis_text=f"MVTec AD ground truth — {rec['defect_type']}",
            created_at=ts,
        )
        inserted += 1

    chroma_count = 0
    if build_chroma:
        store = store or MVTecStore()
        encoder = encoder or SigLIP2Encoder()
        all_recs = scan_test_images()
        batch_size = 16  # GPU VRAM에 맞게 조절 (OOM 시 8 또는 4)
        for start in tqdm(range(0, len(all_recs), batch_size), desc="ChromaDB 인덱싱"):
            batch = all_recs[start : start + batch_size]
            images = [Image.open(r["image_path"]).convert("RGB") for r in batch]
            embeddings = encoder.encode_images(images)
            store.add_batch(batch, embeddings)

        chroma_count = store.count()

    return {
        "indexed": inserted,
        "total_scanned": len(records),
        "db_count": db.count(),
        "chroma_count": chroma_count,
    }
