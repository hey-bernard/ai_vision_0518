"""MVTec AD Qwen3-VL 상세 결함 분석 — SigLIP2 1차 판정 결과를 보조 입력으로 활용.

Visual RAG 2단계 구조:
  1) SigLIP2 (detector.py) — 빠른 정상/불량 1차 분류
  2) Qwen3-VL (이 모듈) — 이미지 직접 보고 한국어 상세 설명 생성

conveyor_rag.analyzer.QwenAnalyzer 를 재사용하며, MVTec 품목·SigLIP2 결과를
프롬프트에 주입해 VLM이 맥락을 이해하도록 한다.
"""

from pathlib import Path

from conveyor_rag.analyzer import QwenAnalyzer


class MVTecVLAnalyzer:
    """업로드·검사 이미지에 Qwen3-VL 한국어 상세 분석을 수행."""

    # Qwen에 전달할 기본 한국어 질의 — Streamlit·API에서 query 미지정 시 사용
    DEFAULT_QUERY = (
        "이 산업 부품 검사 이미지에서 표면 결함(균열, 이물, 변색, 찌그러짐, 스크래치 등)을 "
        "분석하고 정상/불량 판단 근거를 설명하세요."
    )

    def __init__(self, analyzer: QwenAnalyzer | None = None):
        # lazy load — run_vl() 첫 호출 시 Qwen3-VL-2B 가 GPU에 로드됨
        self.analyzer = analyzer or QwenAnalyzer()

    def _build_prompt(
        self,
        product: str,
        query: str,
        siglip_judgment: dict | None = None,
        similar_hits: list | None = None,
    ) -> str:
        """SigLIP2·ChromaDB 검색 결과를 텍스트 컨텍스트로 합쳐 VLM 프롬프트 구성."""
        parts = [f"품목(category): {product}", query]

        # SigLIP2 1차 판정을 참고 정보로 제공 — VLM이 zero-shot만 하지 않도록
        if siglip_judgment:
            parts.append(
                f"\n[SigLIP2 1차 판정 참고]\n"
                f"- 판정: {siglip_judgment.get('label', 'N/A')}\n"
                f"- 결함 유형: {siglip_judgment.get('defect_type', 'N/A')}\n"
                f"- 신뢰도: {siglip_judgment.get('confidence', 0):.1%}\n"
                f"- 유사도 점수: {siglip_judgment.get('analysis_text', '')}"
            )

        # detector.detect() 반환 similar_hits — ChromaDB Top-3 유사 이미지 메타
        if similar_hits:
            lines = []
            for hit in similar_hits[:3]:
                meta = hit.get("metadata", {})
                lines.append(
                    f"  · {meta.get('product')}/{meta.get('defect_type')} "
                    f"(sim={hit.get('similarity', 0):.3f})"
                )
            parts.append("\n[ChromaDB 유사 이미지]\n" + "\n".join(lines))

        parts.append(
            "\n위 참고 정보와 이미지를 직접 확인하여, "
            "결함 유무·위치·형태·심각도·가능 원인·권장 조치를 4~6문장 한국어로 설명하세요."
        )
        return "\n".join(parts)

    def analyze(
        self,
        image_path: str | Path,
        product: str,
        query: str | None = None,
        siglip_judgment: dict | None = None,
        max_new_tokens: int = 200,
    ) -> str:
        """단일 이미지 Qwen3-VL 분석 — 한국어 설명 문자열 반환."""
        prompt = self._build_prompt(
            product=product,
            query=query or self.DEFAULT_QUERY,
            siglip_judgment=siglip_judgment,
            similar_hits=(siglip_judgment or {}).get("similar_hits"),
        )
        # run_vl: PIL Image 1장 + 프롬프트 → greedy 디코딩 (결정적 출력)
        return self.analyzer.run_vl([str(image_path)], prompt, max_new_tokens=max_new_tokens)
