"""MVTec 이미지 SigLIP2 벡터 ChromaDB 저장·검색."""

import hashlib

import chromadb

from mvtec_rag.config import CHROMA_DIR, COLLECTION_NAME


class MVTecStore:
    """MVTec test 이미지 벡터 저장소."""

    def __init__(self, collection_name: str = COLLECTION_NAME):
        # 디스크 영구 저장 — 서버 재시작 후에도 벡터 유지
        self.client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection_name = collection_name
        self._collection = None  # lazy init — import만 할 때 Chroma 접근 지연

    @property
    def collection(self):
        if self._collection is None:
            self._collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"},  # SigLIP2 L2 정규화 임베딩 → cosine = 내적
            )
        return self._collection

    @staticmethod
    def _doc_id(rec: dict) -> str:
        # product + defect_type + path 조합으로 고유 id — 재인덱싱 시 upsert로 덮어쓰기
        key = f"{rec['product']}_{rec['defect_type']}_{rec['image_path']}"
        return hashlib.md5(key.encode()).hexdigest()[:16]

    def add_batch(self, records: list[dict], embeddings) -> None:
        ids, metas, embs = [], [], []
        for rec, emb in zip(records, embeddings):
            doc_id = self._doc_id(rec)
            ids.append(doc_id)
            # 검색 결과·API 응답에 product/label/image_path 포함 — UI에서 이미지 표시용
            metas.append({
                "product": rec["product"],
                "defect_type": rec["defect_type"],
                "label": rec["label"],
                "image_path": rec["image_path"],
            })
            embs.append(emb.tolist())

        # upsert: 동일 id면 갱신 — index_dataset 재실행 시 중복 방지
        self.collection.upsert(ids=ids, embeddings=embs, metadatas=metas)

    def search(self, query_embedding: list[float], top_k: int = 5, product: str | None = None) -> list[dict]:
        if self.collection.count() == 0:
            return []
        # product 지정 시 해당 품목 벡터만 검색 (업로드 판정·Streamlit 유사 검색)
        where = {"product": product} if product else None
        n = min(top_k, self.collection.count())
        result = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n,
            where=where,
            include=["metadatas", "distances"],
        )
        hits = []
        for i in range(len(result["ids"][0])):
            hits.append({
                "id": result["ids"][0][i],
                # cosine distance → similarity (1에 가까울수록 유사)
                "similarity": 1.0 - result["distances"][0][i],
                "metadata": result["metadatas"][0][i],
            })
        return hits

    def count(self) -> int:
        return self.collection.count()

    def reset(self) -> None:
        # 컬렉션 삭제 후 lazy property가 다음 접근 시 새로 생성
        try:
            self.client.delete_collection(self.collection_name)
        except Exception:
            pass
        self._collection = None
