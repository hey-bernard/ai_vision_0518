"""SigLIP2 기반 MVTec 불량 AI 판정."""

from pathlib import Path

import numpy as np
from PIL import Image

from conveyor_rag.encoder import SigLIP2Encoder
from mvtec_rag.config import DATA_DIR, PRODUCTS
from mvtec_rag.store import MVTecStore


class MVTecDefectDetector:
    """업로드 이미지 불량 판정 — 텍스트 프롬프트 + 유사 이미지 참조."""

    # 품목 무관 범용 영어 프롬프트 — SigLIP2 텍스트-이미지 유사도 비교용
    NORMAL_PROMPT = "flawless industrial product surface without any defect"
    DEFECT_PROMPT = "industrial product with visible surface defect or anomaly"

    def __init__(self, encoder: SigLIP2Encoder | None = None, store: MVTecStore | None = None):
        self.encoder = encoder or SigLIP2Encoder()
        self.store = store or MVTecStore()
        # 품목별 good/defect 참조 임베딩 평균 — detect() 반복 호출 시 재계산 방지
        self._ref_cache: dict[str, dict] = {}

    def _product_prompts(self, product: str) -> tuple[str, str]:
        # 품목명을 포함한 프롬프트 — bottle/screw 등 카테고리 특화 판정
        return (
            f"normal {product} industrial component without defect",
            f"defective {product} with surface anomaly or damage",
        )

    def _get_reference_scores(self, image_emb: np.ndarray, product: str) -> tuple[float, float]:
        """품목별 good/defect 참조 이미지와의 평균 유사도."""
        if product not in self._ref_cache:
            good_embs, defect_embs = [], []
            test_dir = DATA_DIR / product / "test"
            if test_dir.exists():
                good_dir = test_dir / "good"
                if good_dir.exists():
                    # 정상 참조: good 폴더에서 최대 3장 — 평균 임베딩 = 프로토타입
                    for p in list(good_dir.glob("*.png"))[:3]:
                        img = Image.open(p).convert("RGB")
                        good_embs.append(self.encoder.encode_images([img])[0])
                for sub in test_dir.iterdir():
                    if sub.is_dir() and sub.name != "good":
                        # 불량 참조: 각 결함 유형에서 최대 2장씩
                        for p in list(sub.glob("*.png"))[:2]:
                            img = Image.open(p).convert("RGB")
                            defect_embs.append(self.encoder.encode_images([img])[0])
            self._ref_cache[product] = {
                "good": np.mean(good_embs, axis=0) if good_embs else None,
                "defect": np.mean(defect_embs, axis=0) if defect_embs else None,
            }

        cache = self._ref_cache[product]
        # L2 정규화된 임베딩 → 코사인 유사도 = 내적
        good_score = float(np.dot(image_emb, cache["good"])) if cache["good"] is not None else 0.0
        defect_score = float(np.dot(image_emb, cache["defect"])) if cache["defect"] is not None else 0.0
        return good_score, defect_score

    def detect(self, image_path: str | Path, product: str = "bottle") -> dict:
        """단일 이미지 AI 불량 판정."""
        path = Path(image_path)
        if product not in PRODUCTS:
            product = "bottle"  # 잘못된 품목명 fallback

        image = Image.open(path).convert("RGB")
        image_emb = self.encoder.encode_images([image])[0]

        # 텍스트 프롬프트 4개 임베딩 — 품목 특화(0,1) + 범용(2,3) 중 max 선택
        normal_p, defect_p = self._product_prompts(product)
        text_embs = self.encoder.encode_texts([normal_p, defect_p, self.NORMAL_PROMPT, self.DEFECT_PROMPT])
        text_normal = float(np.max([np.dot(image_emb, text_embs[i]) for i in (0, 2)]))
        text_defect = float(np.max([np.dot(image_emb, text_embs[i]) for i in (1, 3)]))

        ref_good, ref_defect = self._get_reference_scores(image_emb, product)
        ref_score = ref_defect - ref_good   # 양수면 불량 쪽에 더 가깝다
        text_score = text_defect - text_normal

        # 텍스트 60% + 참조 이미지 40% 가중 결합 — zero-shot + few-shot 하이브리드
        combined = 0.6 * text_score + 0.4 * ref_score
        is_defect = combined > 0
        # |combined| 크기에 비례해 0.51~0.99 구간으로 신뢰도 매핑
        confidence = float(min(0.99, max(0.51, 0.5 + abs(combined) * 2)))

        # ChromaDB에서 유사 test 이미지 Top-3 — 결함 유형(defect_type) 추론 보조
        similar = self.store.search(image_emb.tolist(), top_k=3, product=product)
        predicted_type = "good"
        if similar:
            predicted_type = similar[0]["metadata"]["defect_type"]
            if similar[0]["metadata"]["label"] == "불량" and is_defect:
                predicted_type = similar[0]["metadata"]["defect_type"]

        label = "불량" if is_defect else "정상"
        if not is_defect:
            predicted_type = "good"

        # DB analysis_text·Streamlit info 박스에 표시할 설명 문자열
        analysis = (
            f"AI 판정: {label} (신뢰도 {confidence:.1%})\n"
            f"품목: {product} | 예측 유형: {predicted_type}\n"
            f"텍스트 유사도(불량-정상): {text_score:.3f} | 참조 유사도: {ref_score:.3f}"
        )
        if similar:
            top = similar[0]["metadata"]
            analysis += f"\n유사 이미지: {top['product']}/{top['defect_type']} (sim={similar[0]['similarity']:.3f})"

        return {
            "product": product,
            "label": label,
            "defect_type": predicted_type,
            "confidence": confidence,
            "analysis_text": analysis,
            "similar_hits": similar,
        }
