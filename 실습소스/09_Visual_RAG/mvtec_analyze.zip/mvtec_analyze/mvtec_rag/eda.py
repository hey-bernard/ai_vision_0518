"""MVTec AD 탐색적 데이터 분석(EDA) 및 시각화."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image

from mvtec_rag.config import DATA_DIR, PRODUCTS


def _label_from_defect_type(defect_type: str) -> str:
    # dataset.py 와 동일 규칙 — good 폴더만 정상
    return "정상" if defect_type == "good" else "불량"


def scan_dataset(
    data_dir: Path = DATA_DIR,
    splits: list[str] | None = None,
) -> list[dict]:
    """15개 품목 train/test 이미지 메타 수집."""
    split_list = splits or ["train", "test"]
    records: list[dict] = []
    for product in PRODUCTS:
        prod_dir = data_dir / product
        if not prod_dir.is_dir():
            continue
        for split in split_list:
            # train: 정상 학습용만 / test: 정상+불량 평가용
            split_dir = prod_dir / split
            if not split_dir.exists():
                continue
            for sub in sorted(split_dir.iterdir()):
                if not sub.is_dir():
                    continue
                defect_type = sub.name
                for img_path in sorted(sub.glob("*.png")):
                    records.append({
                        "product": product,
                        "split": split,
                        "defect_type": defect_type,
                        "label": _label_from_defect_type(defect_type),
                        "image_path": str(img_path.resolve()),
                        "filename": img_path.name,
                    })
    return records


def count_ground_truth_masks(data_dir: Path = DATA_DIR) -> pd.DataFrame:
    """품목·결함유형별 ground_truth 마스크 PNG 건수."""
    rows = []
    for product in PRODUCTS:
        # ground_truth/{defect_type}/*_mask.png — test 불량 영역 픽셀 라벨
        gt_dir = data_dir / product / "ground_truth"
        if not gt_dir.exists():
            continue
        for sub in sorted(gt_dir.iterdir()):
            if sub.is_dir():
                rows.append({
                    "product": product,
                    "defect_type": sub.name,
                    "mask_count": len(list(sub.glob("*.png"))),
                })
    return pd.DataFrame(rows)


def enrich_image_stats(df: pd.DataFrame) -> pd.DataFrame:
    """이미지 해상도·파일 크기 컬럼 추가."""
    widths, heights, sizes_kb = [], [], []
    for _, row in df.iterrows():
        path = Path(row["image_path"])
        size_kb = path.stat().st_size / 1024
        with Image.open(path) as img:
            w, h = img.size
        widths.append(w)
        heights.append(h)
        sizes_kb.append(round(size_kb, 1))
    out = df.copy()
    out["width"] = widths
    out["height"] = heights
    out["size_kb"] = sizes_kb
    return out


def build_summary(df: pd.DataFrame) -> dict:
    """전체·품목·split·label 집계 요약."""
    by_product = (
        df.groupby(["product", "label"])
        .size()
        .unstack(fill_value=0)
        .rename(columns={"정상": "normal", "불량": "defect"})
    )
    # 특정 품목에 정상 또는 불량만 있는 경우 컬럼 누락 방지
    if "normal" not in by_product.columns:
        by_product["normal"] = 0
    if "defect" not in by_product.columns:
        by_product["defect"] = 0
    by_product["total"] = by_product["normal"] + by_product["defect"]
    by_product["defect_rate"] = (by_product["defect"] / by_product["total"] * 100).round(1)

    return {
        "total_images": len(df),
        "products": df["product"].nunique(),
        "train_count": int((df["split"] == "train").sum()),
        "test_count": int((df["split"] == "test").sum()),
        "normal_count": int((df["label"] == "정상").sum()),
        "defect_count": int((df["label"] == "불량").sum()),
        "defect_types": df["defect_type"].nunique(),
        "by_product": by_product.reset_index(),
    }


def plot_dataset_overview(df: pd.DataFrame, figsize: tuple = (14, 10)) -> plt.Figure:
    """전체 품목 — 건수·정상/불량·train/test·결함유형 시각화."""
    summary = build_summary(df)
    bp = summary["by_product"].sort_values("total", ascending=False)

    fig, axes = plt.subplots(2, 2, figsize=figsize)

    # 좌상: 품목별 총 이미지 수 (가로 bar)
    axes[0, 0].barh(bp["product"], bp["total"], color="steelblue")
    axes[0, 0].set_title("품목별 이미지 총 건수 (train + test)")
    axes[0, 0].invert_yaxis()

    # 우상: 정상 vs 불량 grouped bar
    x = np.arange(len(bp))
    w = 0.35
    axes[0, 1].bar(x - w / 2, bp["normal"], w, label="정상", color="seagreen")
    axes[0, 1].bar(x + w / 2, bp["defect"], w, label="불량", color="crimson")
    axes[0, 1].set_xticks(x)
    axes[0, 1].set_xticklabels(bp["product"], rotation=45, ha="right")
    axes[0, 1].set_title("품목별 정상 vs 불량")
    axes[0, 1].legend()

    # 좌하: train/test split 분포
    split_pivot = df.groupby(["product", "split"]).size().unstack(fill_value=0)
    split_pivot = split_pivot.reindex(bp["product"])
    split_pivot.plot(kind="bar", ax=axes[1, 0], color=["#4C72B0", "#DD8452"])
    axes[1, 0].set_title("품목별 train / test 분포")
    axes[1, 0].tick_params(axis="x", rotation=45)
    axes[1, 0].legend(title="split")

    # 우하: 품목별 불량 비율 (%)
    axes[1, 1].bar(bp["product"], bp["defect_rate"], color="indianred")
    axes[1, 1].set_title("품목별 불량 비율 (%)")
    axes[1, 1].tick_params(axis="x", rotation=45)

    fig.suptitle(
        f"MVTec AD EDA — 총 {summary['total_images']}장 / "
        f"정상 {summary['normal_count']} · 불량 {summary['defect_count']}",
        fontsize=13,
        y=1.02,
    )
    fig.tight_layout()
    return fig


def plot_image_size_distribution(df: pd.DataFrame, figsize: tuple = (12, 4)) -> plt.Figure:
    """해상도·파일 크기 분포."""
    fig, axes = plt.subplots(1, 3, figsize=figsize)
    axes[0].hist(df["width"], bins=20, color="steelblue", edgecolor="white")
    axes[0].set_title("너비(px) 분포")
    axes[1].hist(df["height"], bins=20, color="coral", edgecolor="white")
    axes[1].set_title("높이(px) 분포")
    axes[2].hist(df["size_kb"], bins=20, color="mediumpurple", edgecolor="white")
    axes[2].set_title("파일 크기(KB) 분포")
    fig.suptitle("이미지 속성 분포", y=1.05)
    fig.tight_layout()
    return fig


def plot_product_defect_types(df: pd.DataFrame, product: str, figsize: tuple = (8, 4)) -> plt.Figure:
    """단일 품목 결함유형별 건수."""
    sub = df[df["product"] == product]
    counts = sub.groupby(["defect_type", "split"]).size().unstack(fill_value=0)
    fig, ax = plt.subplots(figsize=figsize)
    counts.plot(kind="bar", ax=ax, color=["#4C72B0", "#DD8452"])
    ax.set_title(f"{product} — 결함유형별 건수 (split)")
    ax.set_xlabel("defect_type")
    ax.tick_params(axis="x", rotation=30)
    ax.legend(title="split")
    fig.tight_layout()
    return fig


def plot_product_samples(
    df: pd.DataFrame,
    product: str,
    cols: int = 4,
    figsize_per_row: float = 3.5,
) -> plt.Figure:
    """품목별 결함유형당 대표 이미지 1장씩 그리드 표시."""
    sub = df[df["product"] == product]
    # (defect_type, split) 조합마다 첫 번째 이미지 1장 — 유형별 시각적 비교
    samples = (
        sub.groupby(["defect_type", "split"], group_keys=False)
        .apply(lambda g: g.iloc[0])
        .reset_index(drop=True)
    )
    n = len(samples)
    if n == 0:
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, f"{product}: 이미지 없음", ha="center")
        ax.axis("off")
        return fig

    rows = int(np.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(cols * figsize_per_row, rows * figsize_per_row))
    axes_flat = np.array(axes).flatten() if n > 1 else [axes]

    for ax, (_, row) in zip(axes_flat, samples.iterrows()):
        img = Image.open(row["image_path"])
        ax.imshow(img)
        ax.set_title(f"{row['split']}/{row['defect_type']}\n({row['label']})", fontsize=9)
        ax.axis("off")
    # 빈 subplot 축 숨김
    for ax in axes_flat[len(samples) :]:
        ax.axis("off")

    fig.suptitle(f"{product} — 결함유형별 샘플", fontsize=12, y=1.01)
    fig.tight_layout()
    return fig


def run_full_eda(data_dir: Path = DATA_DIR, show_all_products: bool = True) -> dict:
    """전체 EDA 파이프라인 — DataFrame·요약·차트 일괄 생성."""
    records = scan_dataset(data_dir)
    df = pd.DataFrame(records)
    if df.empty:
        raise FileNotFoundError(f"MVTec 이미지 없음: {data_dir}")

    df = enrich_image_stats(df)
    summary = build_summary(df)
    gt_masks = count_ground_truth_masks(data_dir)

    figures = {
        "overview": plot_dataset_overview(df),
        "image_stats": plot_image_size_distribution(df),
    }
    if show_all_products:
        # 15개 품목 각각 결함 bar + 샘플 그리드 Figure 생성
        for product in PRODUCTS:
            if product in df["product"].values:
                figures[f"defect_{product}"] = plot_product_defect_types(df, product)
                figures[f"samples_{product}"] = plot_product_samples(df, product)

    return {
        "df": df,
        "summary": summary,
        "ground_truth_masks": gt_masks,
        "figures": figures,
    }
