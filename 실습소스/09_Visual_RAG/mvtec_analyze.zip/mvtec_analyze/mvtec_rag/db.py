"""SQLite 검사 이력 DB — SQL 조회·필터·통계."""

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mvtec_rag.config import DB_PATH

# inspections 테이블: 06 노트북에서 조회·필터·통계 실습의 중심 스키마
# product     : MVTec 품목명 (bottle, cable, …)
# defect_type : 폴더명 기준 결함 유형 (good = 정상, 그 외 = 불량 세부 유형)
# label       : 한글 판정 (정상 / 불량) — UI·API 필터에 사용
# source      : dataset(초기 인덱싱) | upload(웹 업로드)
# confidence  : AI 판정 신뢰도 (0~1), ground truth는 1.0 또는 0.95
# analysis_text : AI 분석 문장 또는 ground truth 설명
# created_at  : ISO8601 UTC — 날짜별 조회·통계에 사용
SCHEMA = """
CREATE TABLE IF NOT EXISTS inspections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product TEXT NOT NULL,
    defect_type TEXT NOT NULL,
    label TEXT NOT NULL,
    image_path TEXT NOT NULL,
    source TEXT DEFAULT 'dataset',
    confidence REAL,
    analysis_text TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_product ON inspections(product);
CREATE INDEX IF NOT EXISTS idx_label ON inspections(label);
CREATE INDEX IF NOT EXISTS idx_created_at ON inspections(created_at);
CREATE INDEX IF NOT EXISTS idx_defect_type ON inspections(defect_type);
"""


class InspectionDB:
    """MVTec 검사 결과 SQLite 저장소."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = Path(db_path)
        # DB 파일 상위(data/mvtec)가 없으면 생성
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _init_schema(self) -> None:
        # CREATE TABLE IF NOT EXISTS — 기존 DB가 있어도 안전하게 스키마 보장
        with self._connect() as conn:
            conn.executescript(SCHEMA)

    @contextmanager
    def _connect(self):
        # row_factory=Row → 컬럼명으로 dict 변환 가능 (get_by_id, query 반환용)
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()  # with 블록 정상 종료 시 자동 commit
        finally:
            conn.close()

    def insert(
        self,
        product: str,
        defect_type: str,
        label: str,
        image_path: str,
        source: str = "dataset",
        confidence: float | None = None,
        analysis_text: str = "",
        created_at: str | None = None,
    ) -> dict:
        # created_at 미지정 시 현재 UTC 시각 — 업로드 API에서 즉시 저장할 때 사용
        ts = created_at or datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO inspections
                (product, defect_type, label, image_path, source, confidence, analysis_text, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (product, defect_type, label, image_path, source, confidence, analysis_text, ts),
            )
            row_id = cur.lastrowid
        # INSERT 직후 전체 행을 다시 읽어 API·노트북에 id 포함 dict 반환
        return self.get_by_id(row_id)

    def get_by_id(self, record_id: int) -> dict | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM inspections WHERE id = ?", (record_id,)).fetchone()
        return dict(row) if row else None

    def update_analysis(
        self,
        record_id: int,
        analysis_text: str,
        label: str | None = None,
        defect_type: str | None = None,
        confidence: float | None = None,
    ) -> dict | None:
        """분석 텍스트·판정 필드 갱신 (Qwen3-VL 재분석 후)."""
        # COALESCE — None이면 기존 label/defect_type/confidence 유지
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE inspections SET
                    analysis_text = ?,
                    label = COALESCE(?, label),
                    defect_type = COALESCE(?, defect_type),
                    confidence = COALESCE(?, confidence)
                WHERE id = ?
                """,
                (analysis_text, label, defect_type, confidence, record_id),
            )
        return self.get_by_id(record_id)

    def query(
        self,
        product: str | None = None,
        label: str | None = None,
        defect_type: str | None = None,
        source: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        """파라미터 필터로 검사 이력 조회."""
        # WHERE 1=1 — 조건을 AND 로만 붙이기 위한 관용구
        sql = "SELECT * FROM inspections WHERE 1=1"
        params: list[Any] = []

        # None 이 아닌 필터만 동적 WHERE 절에 추가 (SQL injection 방지: ? placeholder)
        if product:
            sql += " AND product = ?"
            params.append(product)
        if label:
            sql += " AND label = ?"
            params.append(label)
        if defect_type:
            sql += " AND defect_type = ?"
            params.append(defect_type)
        if source:
            sql += " AND source = ?"
            params.append(source)
        if date_from:
            sql += " AND created_at >= ?"
            params.append(date_from)
        if date_to:
            sql += " AND created_at <= ?"
            params.append(date_to)

        # 최신 검사 이력 우선, 페이지네이션 지원
        sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def execute_sql(self, sql: str, params: tuple = ()) -> list[dict]:
        """노트북 실습용 원시 SQL 실행 (SELECT만 허용)."""
        stripped = sql.strip().upper()
        # DELETE/UPDATE 등 쓰기 쿼리 차단 — 실습용 read-only 보장
        if not stripped.startswith("SELECT"):
            raise ValueError("SELECT 쿼리만 허용됩니다.")
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def count(self, **filters) -> int:
        # query()와 동일 필터를 쓰되 limit 최대로 건수만 반환
        return len(self.query(limit=999999, **filters))

    def stats(self, product: str | None = None, date_from: str | None = None, date_to: str | None = None) -> dict:
        """품목·기간별 정상/불량 건수 및 불량률."""
        # 전체(또는 필터된) 집계 — SUM(CASE WHEN …) 으로 label별 건수 한 번에 계산
        sql = """
        SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN label = '불량' THEN 1 ELSE 0 END) AS defect_count,
            SUM(CASE WHEN label = '정상' THEN 1 ELSE 0 END) AS normal_count
        FROM inspections WHERE 1=1
        """
        params: list[Any] = []
        if product:
            sql += " AND product = ?"
            params.append(product)
        if date_from:
            sql += " AND created_at >= ?"
            params.append(date_from)
        if date_to:
            sql += " AND created_at <= ?"
            params.append(date_to)

        with self._connect() as conn:
            row = conn.execute(sql, params).fetchone()

        total = int(row["total"] or 0)
        defect = int(row["defect_count"] or 0)
        normal = int(row["normal_count"] or 0)
        defect_rate = round(defect / total * 100, 2) if total else 0.0

        # 품목별 breakdown — Streamlit bar chart·07 노트북 통계에 사용
        by_product_sql = """
        SELECT product,
               COUNT(*) AS total,
               SUM(CASE WHEN label = '불량' THEN 1 ELSE 0 END) AS defect_count
        FROM inspections WHERE 1=1
        """
        bp_params: list[Any] = []
        if date_from:
            by_product_sql += " AND created_at >= ?"
            bp_params.append(date_from)
        if date_to:
            by_product_sql += " AND created_at <= ?"
            bp_params.append(date_to)
        if product:
            by_product_sql += " AND product = ?"
            bp_params.append(product)
        by_product_sql += " GROUP BY product ORDER BY defect_count DESC"

        with self._connect() as conn:
            by_product = [dict(r) for r in conn.execute(by_product_sql, bp_params).fetchall()]

        # Python에서 품목별 불량률(%) 계산 후 API 응답에 포함
        for item in by_product:
            t = int(item["total"] or 0)
            d = int(item["defect_count"] or 0)
            item["defect_rate"] = round(d / t * 100, 2) if t else 0.0

        return {
            "total": total,
            "normal_count": normal,
            "defect_count": defect,
            "defect_rate": defect_rate,
            "by_product": by_product,
        }

    def clear(self) -> None:
        # /index?clear=true 또는 run_index.py --clear 시 전체 이력 삭제
        with self._connect() as conn:
            conn.execute("DELETE FROM inspections")
