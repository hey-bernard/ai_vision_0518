#!/usr/bin/env python
"""Conveyor Visual RAG 파이프라인 실행 스크립트."""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PROJECT_ROOT = ROOT.parent
sys.path.insert(0, str(ROOT))

from conveyor_rag.pipeline import run_full_pipeline


def main():
    parser = argparse.ArgumentParser(description="Conveyor Belt Visual RAG 파이프라인")
    parser.add_argument("--zip", type=Path, default=PROJECT_ROOT / "Conveyor_Belt_Sample.zip")
    parser.add_argument("--max-frames", type=int, default=20)
    parser.add_argument("--no-sample-video", action="store_true", help="ZIP 없을 때 샘플 영상 생성 비활성화")
    args = parser.parse_args()

    # ZIP → 프레임 → sensor.csv → SigLIP2 → ChromaDB 일괄 실행
    result = run_full_pipeline(
        zip_path=args.zip,
        use_sample_video_if_missing=not args.no_sample_video,
        max_frames=args.max_frames,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
    print("\n다음 단계 (conveyor_analyze 폴더에서 실행):")
    print("  python scripts/run_api.py")
    print("  streamlit run dashboard/streamlit_app.py")


if __name__ == "__main__":
    main()
