#!/usr/bin/env python
"""FastAPI 서버 실행 — 포트 충돌 시 안내."""

import socket
import subprocess
import sys
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PORT = 8000


def port_in_use(port: int) -> bool:
    """로컬 포트가 이미 사용 중인지 확인."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def api_is_ours(port: int) -> bool:
    """해당 포트에서 Conveyor Visual RAG API가 응답하는지 확인."""
    try:
        r = requests.get(f"http://127.0.0.1:{port}/", timeout=2)
        return r.status_code == 200 and "Conveyor Visual RAG API" in r.text
    except requests.RequestException:
        return False


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_PORT

    if port_in_use(port):
        if api_is_ours(port):
            print(f"✅ API 서버가 이미 실행 중입니다: http://127.0.0.1:{port}/")
            print("   Streamlit만 실행하면 됩니다:")
            print("   streamlit run dashboard/streamlit_app.py")
            return
        print(f"❌ 포트 {port}이(가) 다른 프로그램에서 사용 중입니다.")
        print(f"   다른 포트로 실행: python scripts/run_api.py 8001")
        print(f"   그 후 Streamlit 사이드바 API URL을 http://127.0.0.1:8001 로 변경")
        sys.exit(1)

    cmd = [
        sys.executable, "-m", "uvicorn", "api.main:app",
        "--reload", "--port", str(port),
    ]
    print(f"🚀 API 서버 시작: http://127.0.0.1:{port}/")
    subprocess.run(cmd, cwd=ROOT)


if __name__ == "__main__":
    main()
