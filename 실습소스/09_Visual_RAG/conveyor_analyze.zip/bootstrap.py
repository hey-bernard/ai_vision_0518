"""conveyor_analyze 프로젝트 루트를 sys.path에 등록."""

import sys
from pathlib import Path

# api.main 등이 `from conveyor_rag ...` import 할 수 있도록 패키지 루트 추가
ROOT = Path(__file__).resolve().parent

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
