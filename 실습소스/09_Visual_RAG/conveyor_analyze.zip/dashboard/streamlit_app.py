"""Streamlit Dashboard — Conveyor Visual RAG.

FastAPI 백엔드에 HTTP로 요청하는 웹 UI.
별도 터미널에서 `python scripts/run_api.py` 가 먼저 실행되어 있어야 합니다.
"""

import sys
from pathlib import Path

# dashboard/ 에서 conveyor_analyze 루트 import 가능하도록
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import json

import pandas as pd
import requests
import streamlit as st
from PIL import Image

from conveyor_rag.config import API_BASE_URL_DEFAULT, FRAMES_DIR, SENSOR_CSV

API_BASE = API_BASE_URL_DEFAULT

st.set_page_config(
    page_title="Conveyor Visual RAG",
    page_icon="🏭",
    layout="wide",
)

st.title("🏭 Conveyor Belt Visual RAG Dashboard")
st.caption("SigLIP2 + ChromaDB + Qwen3-VL + Sensor 메타데이터 연동")

# 사이드바에서 API 주소 변경 가능 (다른 포트 사용 시)
api_url = st.sidebar.text_input("API URL", value=API_BASE)


def check_api_health() -> bool:
    """루트 엔드포인트로 API 생존 확인."""
    try:
        r = requests.get(f"{api_url}/", timeout=3)
        return r.status_code == 200
    except requests.RequestException:
        return False


api_ok = check_api_health()
if api_ok:
    st.sidebar.success("API 서버 연결됨")
else:
    st.sidebar.error("API 서버 미연결")
    st.sidebar.code(
        "python scripts/run_api.py\n"
        "# 또는\n"
        "uvicorn api.main:app --reload --port 8000",
        language="bash",
    )


def api_get(path: str, params: dict | None = None):
    try:
        r = requests.get(f"{api_url}{path}", params=params, timeout=120)
        r.raise_for_status()
        return r.json()
    except requests.ConnectionError:
        raise ConnectionError(
            "API 서버에 연결할 수 없습니다. 별도 터미널에서 "
            "`uvicorn api.main:app --port 8000` 을 먼저 실행하세요."
        ) from None


def api_post(path: str, payload: dict):
    try:
        r = requests.post(f"{api_url}{path}", json=payload, timeout=300)
        r.raise_for_status()
        return r.json()
    except requests.ConnectionError:
        raise ConnectionError(
            "API 서버에 연결할 수 없습니다. 별도 터미널에서 "
            "`uvicorn api.main:app --port 8000` 을 먼저 실행하세요."
        ) from None


tab_search, tab_analyze, tab_sensor, tab_history, tab_pipeline = st.tabs(
    ["🔍 검색", "🤖 분석", "📊 센서", "📜 이력", "⚙️ 파이프라인"]
)

with tab_search:
    st.subheader("텍스트 → SigLIP2 → ChromaDB 검색")
    query = st.text_input("검색 쿼리", value="컨베이어 벨트 이상 상태")
    top_k = st.slider("Top-k", 1, 10, 4)
    if st.button("검색 실행", key="search"):
        with st.spinner("검색 중..."):
            try:
                data = api_post("/search", {"query": query, "top_k": top_k})
                st.success(f"쿼리: {data['query']}")
                cols = st.columns(min(top_k, 4))
                for i, hit in enumerate(data["results"]):
                    meta = hit["metadata"]
                    sensor = hit.get("sensor", meta)  # enrich_hits_with_sensor 결과
                    with cols[i % len(cols)]:
                        path = meta.get("local_path", "")
                        if Path(path).exists():
                            st.image(path, caption=meta.get("frame"), use_container_width=True)
                        st.metric("유사도", f"{hit['similarity']:.3f}")
                        st.write(f"**상태:** {sensor.get('status', 'N/A')}")
                        st.write(f"온도 {sensor.get('temp')}°C | RPM {sensor.get('rpm')}")
            except Exception as e:
                st.error(f"검색 실패: {e}")

with tab_analyze:
    st.subheader("Visual RAG 분석 (검색 + 센서 + Qwen3-VL)")
    analyze_query = st.text_area(
        "분석 질문",
        value="컨베이어 벨트에서 이상 징후가 보이는 프레임을 찾고 원인을 분석하세요.",
    )
    if st.button("Qwen3-VL 분석", key="analyze"):
        with st.spinner("Qwen3-VL 분석 중 (수 분 소요)..."):
            try:
                data = api_post("/analyze", {"query": analyze_query, "top_k": 4})
                st.markdown("### 검색된 프레임")
                cols = st.columns(4)
                for i, frame in enumerate(data["retrieved_frames"]):
                    path = FRAMES_DIR / frame
                    with cols[i]:
                        if path.exists():
                            st.image(str(path), caption=frame, use_container_width=True)
                st.markdown("### 센서 데이터")
                st.dataframe(pd.DataFrame(data["sensor_data"]), use_container_width=True)
                st.markdown("### Qwen3-VL 분석 결과")
                st.info(data["analysis"])
            except Exception as e:
                st.error(f"분석 실패: {e}")

with tab_sensor:
    st.subheader("가상 센서 CSV (sensor.csv)")
    if SENSOR_CSV.exists():
        df = pd.read_csv(SENSOR_CSV)
        st.dataframe(df, use_container_width=True)
        status_filter = st.selectbox("상태 필터", ["전체", "Normal", "Warning", "Fault"])
        if status_filter != "전체":
            filtered = df[df["status"] == status_filter]
            st.line_chart(filtered.set_index("frame")[["temp", "rpm", "vibration"]])
        else:
            st.line_chart(df.set_index("frame")[["temp", "rpm", "vibration"]])
    else:
        st.warning("sensor.csv 없음 — 파이프라인을 먼저 실행하세요.")

    frame_sel = st.text_input("프레임 조회", value="frame0003.jpg")
    if st.button("센서 조회", key="sensor"):
        try:
            data = api_get("/sensor", {"frame": frame_sel})
            st.json(data)
        except Exception as e:
            st.error(str(e))

with tab_history:
    st.subheader("분석 이력")
    try:
        data = api_get("/history", {"limit": 20})
        for item in data.get("history", []):
            with st.expander(f"#{item['id']} — {item.get('timestamp', '')[:19]}"):
                st.write(f"**Query:** {item.get('query')}")
                st.write(f"**Frames:** {', '.join(item.get('frames', []))}")
                st.write(item.get("analysis", ""))
    except Exception as e:
        st.warning(f"API 연결 필요: {e}")

with tab_pipeline:
    st.subheader("데이터 파이프라인")
    st.code(
        "cd conveyor_analyze\n"
        "python scripts/run_pipeline.py\n"
        "uvicorn api.main:app --reload --port 8000\n"
        "streamlit run dashboard/streamlit_app.py",
        language="bash",
    )
    st.markdown("""
    **흐름**
    1. `Conveyor_Belt_Sample.zip` → OpenCV 프레임 추출 (없으면 샘플 영상 자동 생성)
    2. `sensor.csv` 가상 생성 (frame ↔ temp/rpm/vibration/status)
    3. SigLIP2 임베딩 → ChromaDB 저장
  4. FastAPI `/search`, `/analyze` → Qwen3-VL + 센서 연계
    """)

    if FRAMES_DIR.exists():
        frames = sorted(FRAMES_DIR.glob("frame*.jpg"))
        st.write(f"프레임 {len(frames)}장")
        if frames:
            preview_cols = st.columns(4)
            for i, fp in enumerate(frames[:4]):
                with preview_cols[i]:
                    st.image(str(fp), caption=fp.name, use_container_width=True)
