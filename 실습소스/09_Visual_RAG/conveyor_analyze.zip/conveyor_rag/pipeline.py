"""비디오 → 프레임 → 센서 CSV → ChromaDB 전체 파이프라인."""

import json
import shutil
import zipfile
from pathlib import Path

import cv2
import numpy as np

from conveyor_rag.config import (
    FRAME_INTERVAL_SEC,
    FRAMES_DIR,
    NUM_FRAMES_DEFAULT,
    VIDEO_DIR,
    ZIP_PATH,
)
from conveyor_rag.encoder import SigLIP2Encoder
from conveyor_rag.sensor import generate_sensor_csv
from conveyor_rag.store import ChromaStore


def _find_video_in_dir(directory: Path) -> Path | None:
    """디렉터리(하위 포함)에서 첫 번째 비디오 파일 탐색."""
    for ext in ("*.mp4", "*.avi", "*.mov", "*.mkv"):
        found = list(directory.glob(ext))
        if found:
            return found[0]
    for sub in directory.rglob("*"):
        if sub.suffix.lower() in {".mp4", ".avi", ".mov", ".mkv"}:
            return sub
    return None


def extract_zip_dataset(zip_path: Path = ZIP_PATH) -> Path:
    """Conveyor_Belt_Sample.zip 압축 해제 후 비디오 경로 반환."""
    if not zip_path.exists():
        raise FileNotFoundError(f"데이터셋 없음: {zip_path}")

    extract_dir = VIDEO_DIR / "extracted"
    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    extract_dir.mkdir(parents=True)

    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(extract_dir)

    video = _find_video_in_dir(extract_dir)
    if video is None:
        raise FileNotFoundError(f"ZIP 내 비디오 파일 없음: {zip_path}")
    return video


def create_sample_video(
    output: Path | None = None,
    num_frames: int = NUM_FRAMES_DEFAULT,
    fps: int = 5,
    width: int = 640,
    height: int = 360,
) -> Path:
    """ZIP이 없을 때 OpenCV로 컨베이어 벨트 샘플 영상 생성."""
    output = output or (VIDEO_DIR / "conveyor_sample.mp4")
    output.parent.mkdir(parents=True, exist_ok=True)

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(output), fourcc, fps, (width, height))

    for i in range(num_frames):
        frame = np.zeros((height, width, 3), dtype=np.uint8)
        frame[:] = (40, 40, 45)

        # 벨트 영역
        belt_y1, belt_y2 = height // 3, 2 * height // 3
        cv2.rectangle(frame, (0, belt_y1), (width, belt_y2), (70, 70, 75), -1)

        # 이동하는 롤러/마크
        offset = (i * 25) % width
        for x in range(-width, width, 80):
            cx = x + offset
            cv2.circle(frame, (cx, (belt_y1 + belt_y2) // 2), 12, (120, 120, 130), -1)

        # 이상 상태 시각화 (후반 프레임)
        if i >= 2:
            cv2.putText(frame, "WARNING" if i < 3 else "FAULT", (20, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 140, 255) if i < 3 else (0, 0, 255), 2)
        cv2.putText(frame, f"Frame {i+1:04d}", (width - 180, height - 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)

        writer.write(frame)
    writer.release()
    return output


def extract_frames(
    video_path: Path,
    output_dir: Path = FRAMES_DIR,
    interval_sec: float = FRAME_INTERVAL_SEC,
    max_frames: int | None = NUM_FRAMES_DEFAULT,
) -> list[Path]:
    """OpenCV로 비디오에서 프레임 추출 → frame0001.jpg 형식 저장."""
    output_dir.mkdir(parents=True, exist_ok=True)
    # 재실행 시 이전 프레임 삭제 후 새로 추출
    for old in output_dir.glob("frame*.jpg"):
        old.unlink()

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"비디오 열기 실패: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 5.0
    step = max(int(fps * interval_sec), 1)  # interval_sec마다 1장
    saved: list[Path] = []
    frame_idx = 0
    save_idx = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_idx % step == 0:
            save_idx += 1
            out_path = output_dir / f"frame{save_idx:04d}.jpg"
            cv2.imwrite(str(out_path), frame)
            saved.append(out_path)
            if max_frames and save_idx >= max_frames:
                break
        frame_idx += 1

    cap.release()
    if not saved:
        raise RuntimeError("추출된 프레임 없음")
    return saved


def run_full_pipeline(
    zip_path: Path = ZIP_PATH,
    use_sample_video_if_missing: bool = True,
    max_frames: int = NUM_FRAMES_DEFAULT,
) -> dict:
    """전체 파이프라인: 비디오 → 프레임 → 센서 CSV → SigLIP2 → ChromaDB."""
    if zip_path.exists():
        video_path = extract_zip_dataset(zip_path)
        source = "zip"
    elif use_sample_video_if_missing:
        video_path = create_sample_video(num_frames=max_frames)
        source = "generated"
    else:
        raise FileNotFoundError(
            f"{zip_path} 없음. 프로젝트 루트({zip_path.parent})에 Conveyor_Belt_Sample.zip을 배치하세요."
        )

    frames = extract_frames(video_path, max_frames=max_frames)
    sensor_path = generate_sensor_csv(frames)

    encoder = SigLIP2Encoder()
    store = ChromaStore()
    count = store.build_from_frames(encoder, FRAMES_DIR)

    return {
        "source": source,
        "video": str(video_path),
        "frames": len(frames),
        "sensor_csv": str(sensor_path),
        "chroma_vectors": count,
        "frames_dir": str(FRAMES_DIR),
    }


if __name__ == "__main__":
    result = run_full_pipeline()
    print(json.dumps(result, indent=2, ensure_ascii=False))
