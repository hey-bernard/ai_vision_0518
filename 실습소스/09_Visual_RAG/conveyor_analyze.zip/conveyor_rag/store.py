"""ChromaDB 이미지 벡터 저장소 — 프레임 임베딩 + 센서 메타데이터."""

from pathlib import Path

import chromadb
from PIL import Image
from tqdm import tqdm

from conveyor_rag.config import CHROMA_DIR, COLLECTION_NAME, FRAMES_DIR, SIGLIP2_BATCH_SIZE
from conveyor_rag.encoder import SigLIP2Encoder
from conveyor_rag.metadata_link import build_chroma_metadata_for_frame
from conveyor_rag.sensor import load_sensor_df


class ChromaStore:
    """프레임 SigLIP2 임베딩과 센서 메타를 ChromaDB에 저장·검색."""

    def __init__(self, collection_name: str = COLLECTION_NAME):
        # PersistentClient: 디스크에 저장되어 재실행 후에도 유지
        self.client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection_name = collection_name
        self._collection = None

    @property
    def collection(self):
        """컬렉션 lazy 로드 — cosine 거리(HNSW)로 유사도 검색."""
        if self._collection is None:
            self._collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"},
            )
        return self._collection

    def reset_collection(self):
        """재인덱싱 시 기존 컬렉션 삭제 후 새로 생성."""
        try:
            self.client.delete_collection(self.collection_name)
        except Exception:
            pass
        self._collection = self.client.create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"},
        )

    def build_from_frames(self, encoder: SigLIP2Encoder, frames_dir: Path = FRAMES_DIR):
        """frames/*.jpg → SigLIP2 임베딩 + sensor 메타 → ChromaDB 일괄 저장."""
        frames = sorted(frames_dir.glob("frame*.jpg"))
        if not frames:
            raise FileNotFoundError(f"프레임 없음: {frames_dir}")

        sensor_df = load_sensor_df()
        self.reset_collection()

        # GPU 메모리·속도를 위해 배치 단위 인덱싱
        for i in tqdm(range(0, len(frames), SIGLIP2_BATCH_SIZE), desc="ChromaDB 인덱싱"):
            batch_paths = frames[i : i + SIGLIP2_BATCH_SIZE]
            images = [Image.open(p).convert("RGB") for p in batch_paths]
            embeddings = encoder.encode_images(images)

            ids, metadatas = [], []
            for path in batch_paths:
                # frame 키로 sensor.csv 행과 연계된 메타 생성
                meta = build_chroma_metadata_for_frame(path, sensor_df)
                ids.append(path.stem)  # frame0001 (확장자 제외)
                metadatas.append(meta)

            self.collection.add(
                ids=ids,
                embeddings=embeddings.tolist(),
                metadatas=metadatas,
            )

        return self.collection.count()

    def search(self, query_embedding: list[float], top_k: int = 4):
        """쿼리 벡터로 Top-k 프레임 검색. similarity = 1 - cosine_distance."""
        result = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=["metadatas", "distances", "embeddings"],
        )
        hits = []
        for i in range(len(result["ids"][0])):
            dist = result["distances"][0][i]
            hits.append({
                "id": result["ids"][0][i],
                "similarity": 1.0 - dist,
                "metadata": result["metadatas"][0][i],
            })
        return hits

    def get_by_frame(self, frame: str):
        """프레임 ID로 단건 조회 (/embedding API용)."""
        frame_id = Path(frame).stem
        result = self.collection.get(ids=[frame_id], include=["metadatas", "embeddings"])
        if not result["ids"]:
            return None
        emb = result["embeddings"]
        embedding = emb[0] if emb is not None and len(emb) > 0 else None
        return {
            "id": result["ids"][0],
            "metadata": result["metadatas"][0],
            "embedding": embedding,
        }

    def count(self) -> int:
        return self.collection.count()
