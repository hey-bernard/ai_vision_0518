"""Conveyor Belt Visual RAG — SigLIP2 + ChromaDB + Qwen3-VL + Sensor 연동.

패키지 구성:
  config      — 경로·모델 ID 상수
  encoder     — SigLIP2 임베딩
  sensor      — 가상 sensor.csv
  store       — 이미지 ChromaDB
  metadata_link — 이미지·센서 메타 연계
  analysis_store — 분석 결과 ChromaDB
  analyzer    — Qwen3-VL + JSON 이력
  pipeline    — 전체 배치 파이프라인
"""
