"""Qwen3-VL 분석 결과를 ChromaDB 벡터 컬렉션에 저장·검색."""

from datetime import datetime, timezone

import chromadb

from conveyor_rag.config import ANALYSIS_COLLECTION_NAME, CHROMA_DIR
from conveyor_rag.encoder import SigLIP2Encoder


class AnalysisVectorStore:
    """분석 텍스트를 SigLIP2 텍스트 임베딩으로 저장하고 유사 질의로 검색."""

    def __init__(self, collection_name: str = ANALYSIS_COLLECTION_NAME):
        # 이미지 DB와 동일 chroma_db 경로, 컬렉션 이름만 분리
        self.client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection_name = collection_name
        self._collection = None

    @property
    def collection(self):
        if self._collection is None:
            self._collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"},
            )
        return self._collection

    def add_result(
        self,
        encoder: SigLIP2Encoder,
        query: str,
        analysis: str,
        frames: list[str],
        sensor_summary: str = "",
        record_id: int | None = None,
    ) -> dict:
        """분석 결과 1건을 벡터 DB에 저장."""
        doc_id = f"analysis_{record_id or self.collection.count() + 1:04d}"
        # 질의+분석을 합쳐 임베딩 — 의미 검색 시 둘 다 반영
        embed_text = f"{query}\n{analysis}"[:500]
        embedding = encoder.encode_texts([embed_text])[0].tolist()
        timestamp = datetime.now(timezone.utc).isoformat()

        metadata = {
            "query": query,
            "analysis": analysis[:2000],  # Chroma 메타 크기 제한 고려
            "frames": ", ".join(frames),
            "sensor_summary": sensor_summary[:500],
            "timestamp": timestamp,
        }
        self.collection.add(ids=[doc_id], embeddings=[embedding], metadatas=[metadata])
        return {"id": doc_id, **metadata}

    def search(self, encoder: SigLIP2Encoder, query: str, top_k: int = 5) -> list[dict]:
        """텍스트 쿼리로 과거 분석 결과 Top-k 검색."""
        if self.collection.count() == 0:
            return []
        query_emb = encoder.encode_texts([query])[0].tolist()
        result = self.collection.query(
            query_embeddings=[query_emb],
            n_results=min(top_k, self.collection.count()),
            include=["metadatas", "distances"],
        )
        hits = []
        for i in range(len(result["ids"][0])):
            hits.append({
                "id": result["ids"][0][i],
                "similarity": 1.0 - result["distances"][0][i],
                "metadata": result["metadatas"][0][i],
            })
        return hits

    def count(self) -> int:
        return self.collection.count()
