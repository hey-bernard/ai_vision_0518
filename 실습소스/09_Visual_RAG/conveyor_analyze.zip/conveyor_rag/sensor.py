"""가상 센서 CSV 생성·조회 — 프레임 번호와 1:1 매칭."""

import csv
import random
from pathlib import Path

import pandas as pd

from conveyor_rag.config import SENSOR_CSV

# 사용자 지정 시드 데이터 (frame0001~0004)
# 실습 시나리오: Normal → Warning → Fault 로 점진적 악화
SEED_ROWS = [
    {"frame": "frame0001.jpg", "machine": "M01", "temp": 38.2, "rpm": 1150, "vibration": 0.08, "current": 2.9, "speed": 0.95, "status": "Normal"},
    {"frame": "frame0002.jpg", "machine": "M01", "temp": 39.1, "rpm": 1170, "vibration": 0.10, "current": 3.0, "speed": 0.95, "status": "Normal"},
    {"frame": "frame0003.jpg", "machine": "M01", "temp": 45.3, "rpm": 1230, "vibration": 0.31, "current": 3.8, "speed": 0.96, "status": "Warning"},
    {"frame": "frame0004.jpg", "machine": "M01", "temp": 48.8, "rpm": 1260, "vibration": 0.45, "current": 4.1, "speed": 0.98, "status": "Fault"},
]

COLUMNS = ["frame", "machine", "temp", "rpm", "vibration", "current", "speed", "status"]


def _status_for_index(idx: int) -> tuple[float, int, float, float, float, str]:
    """5번째 프레임부터 점진적 이상 패턴 생성."""
    if idx < 4:
        row = SEED_ROWS[idx]
        return row["temp"], row["rpm"], row["vibration"], row["current"], row["speed"], row["status"]

    # frame0004(Fault) 기준으로 이후 프레임 수치를 랜덤하게 악화
    progress = min((idx - 3) / 12.0, 1.0)
    base = SEED_ROWS[3]
    temp = base["temp"] + progress * random.uniform(2, 8)
    rpm = int(base["rpm"] + progress * random.uniform(20, 80))
    vibration = base["vibration"] + progress * random.uniform(0.1, 0.4)
    current = base["current"] + progress * random.uniform(0.3, 1.2)
    speed = min(base["speed"] + progress * 0.02, 1.0)
    if progress < 0.3:
        status = "Fault"
    elif progress < 0.6:
        status = "Warning"
    else:
        status = random.choice(["Warning", "Fault"])
    return round(temp, 1), rpm, round(vibration, 2), round(current, 1), round(speed, 2), status


def generate_sensor_csv(frame_files: list[Path], output: Path = SENSOR_CSV) -> Path:
    """프레임 목록에 맞춰 가상 센서 CSV 자동 생성."""
    random.seed(42)  # 재현 가능한 가상 데이터
    rows = []
    for i, path in enumerate(sorted(frame_files)):
        frame_name = path.name
        if i < len(SEED_ROWS) and SEED_ROWS[i]["frame"] == frame_name:
            rows.append(SEED_ROWS[i])
        else:
            temp, rpm, vibration, current, speed, status = _status_for_index(i)
            rows.append({
                "frame": frame_name,
                "machine": "M01",
                "temp": temp,
                "rpm": rpm,
                "vibration": vibration,
                "current": current,
                "speed": speed,
                "status": status,
            })

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    return output


def load_sensor_df(csv_path: Path = SENSOR_CSV) -> pd.DataFrame:
    """sensor.csv를 DataFrame으로 로드. 없으면 빈 DF."""
    if not csv_path.exists():
        return pd.DataFrame(columns=COLUMNS)
    return pd.read_csv(csv_path)


def normalize_frame_name(frame: str) -> str:
    """'frame3', 'frame0003', 'frame0003.jpg' 등을 frame0003.jpg 로 통일."""
    name = frame.strip()
    if name.endswith(".jpg"):
        name = name[:-4]
    if not name.startswith("frame"):
        name = f"frame{name}"
    return f"{name}.jpg"


def get_sensor_by_frame(frame: str, csv_path: Path = SENSOR_CSV) -> dict | None:
    """단일 프레임에 해당하는 센서 행 반환 (Chroma 메타·API /sensor 공용)."""
    df = load_sensor_df(csv_path)
    if df.empty:
        return None
    name = normalize_frame_name(frame)
    row = df[df["frame"] == name]
    if row.empty:
        # 정확한 이름 매칭 실패 시 stem 부분 일치로 재시도
        row = df[df["frame"].str.contains(Path(name).stem)]
    if row.empty:
        return None
    return row.iloc[0].to_dict()


def get_all_sensors(csv_path: Path = SENSOR_CSV) -> list[dict]:
    """전체 센서 행을 dict 리스트로 반환."""
    df = load_sensor_df(csv_path)
    return df.to_dict(orient="records")
