"""Qwen3-VL 분석기 및 JSON 분석 이력 저장."""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

import torch
from PIL import Image
from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

from conveyor_rag.config import HISTORY_JSON, QWEN_MODEL_ID

logger = logging.getLogger(__name__)


class QwenAnalyzer:
    """검색된 프레임 + 센서 수치를 Qwen3-VL로 종합 분석."""

    def __init__(self, model_id: str = QWEN_MODEL_ID):
        self.model_id = model_id
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self._model = None
        self._processor = None

    def _load(self):
        """최초 호출 시에만 모델 로드 (lazy loading)."""
        if self._model is not None:
            return
        logger.info("Qwen3-VL 로딩: %s", self.model_id)
        dtype = torch.bfloat16 if self.device == "cuda" else torch.float32
        self._model = Qwen3VLForConditionalGeneration.from_pretrained(
            self.model_id,
            torch_dtype=dtype,
            device_map="auto" if self.device == "cuda" else None,
            attn_implementation="sdpa",
        )
        self._processor = AutoProcessor.from_pretrained(self.model_id)

    def run_vl(self, image_paths: list[str], prompt: str, max_new_tokens: int = 128) -> str:
        """이미지 1~2장 + 텍스트로 Qwen3-VL 추론 (VRAM 절약)."""
        self._load()
        # PIL Image 객체 전달 (Windows file:// URL 호환 이슈 회피)
        content = [{"type": "image", "image": Image.open(p).convert("RGB")} for p in image_paths]
        content.append({"type": "text", "text": prompt})
        messages = [{"role": "user", "content": content}]

        inputs = self._processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        )
        inputs = inputs.to(self._model.device)

        with torch.no_grad():
            generated_ids = self._model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                repetition_penalty=1.15,  # 반복 출력 억제
                do_sample=False,          # greedy — 결정적 출력
            )

        # 입력 토큰 제거 후 생성 부분만 디코딩
        trimmed = [
            out_ids[len(in_ids):]
            for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
        ]
        text = self._processor.batch_decode(trimmed, skip_special_tokens=True)[0].strip()
        del inputs, generated_ids
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        return text

    def analyze_with_sensor(
        self,
        image_paths: list[str],
        sensor_rows: list[dict],
        query: str = "컨베이어 벨트 이상 징후를 분석하세요.",
    ) -> str:
        """검색된 모든 프레임을 1장씩 분석 후 종합 (OOM 방지)."""
        per_frame = []
        pairs = list(zip(image_paths, sensor_rows))

        # 1단계: 프레임별 개별 분석 (한 번에 여러 장 넣지 않음)
        for i, (path, row) in enumerate(pairs, 1):
            prompt = (
                f"{query}\n\n"
                f"[센서] {row['frame']}: temp={row['temp']}°C, rpm={row['rpm']}, "
                f"vibration={row['vibration']}, current={row['current']}A, status={row['status']}\n\n"
                "이 한 장의 이미지와 센서 수치만 보고 이상 징후를 2~3문장 한국어로 설명하세요."
            )
            summary = self.run_vl([path], prompt, max_new_tokens=100)
            per_frame.append(f"이미지 {i} ({row['frame']}): {summary}")
            logger.info("프레임 %d/%d 분석 완료: %s", i, len(pairs), row["frame"])

        # 2단계: 가장 심각한(Fault) 프레임 1장 + 텍스트 요약으로 최종 종합
        status_rank = {"Normal": 0, "Warning": 1, "Fault": 2}
        worst_idx = max(
            range(len(sensor_rows)),
            key=lambda j: status_rank.get(sensor_rows[j].get("status", ""), 0),
        )
        summaries = "\n".join(per_frame)
        final_prompt = (
            f"{query}\n\n[프레임별 분석 — 총 {len(pairs)}장]\n{summaries}\n\n"
            "위 내용을 종합하여 이상 여부, 가능한 원인, 권장 조치를 4~6문장 한국어로 설명하세요."
        )
        return self.run_vl([image_paths[worst_idx]], final_prompt, max_new_tokens=200)


class HistoryStore:
    """Qwen 분석 결과를 JSON 파일에 순차 저장 (벡터 DB와 별도 원문 보관)."""

    def __init__(self, path: Path = HISTORY_JSON):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> list[dict]:
        if not self.path.exists():
            return []
        return json.loads(self.path.read_text(encoding="utf-8"))

    def add(self, record: dict) -> dict:
        records = self._load()
        record["id"] = len(records) + 1
        record["timestamp"] = datetime.now(timezone.utc).isoformat()
        records.append(record)
        self.path.write_text(json.dumps(records, indent=2, ensure_ascii=False), encoding="utf-8")
        return record

    def list(self, limit: int = 20) -> list[dict]:
        records = self._load()
        return list(reversed(records[-limit:]))

    def get(self, record_id: int) -> dict | None:
        for r in self._load():
            if r.get("id") == record_id:
                return r
        return None
