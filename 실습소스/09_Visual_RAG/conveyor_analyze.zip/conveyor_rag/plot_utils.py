"""matplotlib 한글 폰트 설정 (Windows / macOS / Linux·Colab)."""

import os
import platform
import subprocess

import matplotlib.font_manager as fm
import matplotlib.pyplot as plt


def setup_korean_matplotlib() -> str | None:
    """Windows / Colab / macOS matplotlib 한글 폰트 설정."""
    # matplotlib 기본 폰트(DejaVu Sans)는 한글 미지원 → 제목·축이 □□□ 로 깨짐
    system = platform.system()
    chosen = None

    def font_names() -> set[str]:
        return {f.name for f in fm.fontManager.ttflist}

    if system == "Windows":
        for name in ("Malgun Gothic", "맑은 고딕", "NanumGothic", "Gulim"):
            if name in font_names():
                chosen = name
                break
    elif system == "Darwin":
        for name in ("AppleGothic", "Apple SD Gothic Neo", "NanumGothic"):
            if name in font_names():
                chosen = name
                break
    else:
        nanum_paths = [
            "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
            "/usr/share/fonts/nanum/NanumGothic.ttf",
        ]
        if not any(os.path.exists(p) for p in nanum_paths):
            try:
                subprocess.run(
                    ["apt-get", "-qq", "install", "-y", "fonts-nanum"],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            except Exception:
                pass
        for path in nanum_paths:
            if os.path.exists(path):
                fm.fontManager.addfont(path)
                chosen = fm.FontProperties(fname=path).get_name()
                break
        if chosen is None:
            for name in ("NanumGothic", "NanumBarunGothic", "UnDotum"):
                if name in font_names():
                    chosen = name
                    break

    if chosen:
        plt.rcParams["font.family"] = chosen
    else:
        print("경고: 한글 폰트를 찾지 못했습니다.")
    plt.rcParams["axes.unicode_minus"] = False
    return chosen
