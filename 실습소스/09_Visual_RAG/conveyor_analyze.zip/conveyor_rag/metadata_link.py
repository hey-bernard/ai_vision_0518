"""이미지 프레임 ↔ sensor.csv ↔ ChromaDB 메타데이터 연계."""

from pathlib import Path

import pandas as pd

from conveyor_rag.config import FRAMES_DIR, SENSOR_CSV
from conveyor_rag.sensor import COLUMNS, get_sensor_by_frame, load_sensor_df

# ChromaDB·조인 테이블에서 공통으로 쓰는 센서 컬럼 목록
SENSOR_META_KEYS = ["frame", "machine", "temp", "rpm", "vibration", "current", "speed", "status"]


def build_chroma_metadata_for_frame(frame_path: Path, sensor_df: pd.DataFrame | None = None) -> dict:
    """ChromaDB 저장용 메타데이터 — 프레임 경로 + sensor.csv 행을 1:1 연계."""
    frame_name = frame_path.name
    if sensor_df is None:
        sensor_df = load_sensor_df()
    row = sensor_df[sensor_df["frame"] == frame_name]
    if row.empty:
        # CSV에 없는 프레임은 Unknown 기본값 (인덱싱은 계속 진행)
        return {
            "frame": frame_name,
            "local_path": str(frame_path.resolve()),
            "machine": "M01",
            "temp": 0.0,
            "rpm": 0,
            "vibration": 0.0,
            "current": 0.0,
            "speed": 0.0,
            "status": "Unknown",
        }
    r = row.iloc[0]
    return {
        "frame": frame_name,
        "local_path": str(frame_path.resolve()),  # Qwen3-VL·Streamlit 이미지 로드 경로
        "machine": str(r["machine"]),
        "temp": float(r["temp"]),
        "rpm": int(r["rpm"]),
        "vibration": float(r["vibration"]),
        "current": float(r["current"]),
        "speed": float(r["speed"]),
        "status": str(r["status"]),
    }


def build_frame_sensor_table(
    frames_dir: Path = FRAMES_DIR,
    sensor_csv: Path = SENSOR_CSV,
) -> pd.DataFrame:
    """프레임 파일 목록과 sensor.csv를 frame 키로 조인한 테이블."""
    rows = []
    for fp in sorted(frames_dir.glob("frame*.jpg")):
        sensor = get_sensor_by_frame(fp.name, sensor_csv) or {}
        rows.append({
            "frame": fp.name,
            "image_path": str(fp.resolve()),
            **{k: sensor.get(k) for k in COLUMNS if k != "frame"},
        })
    return pd.DataFrame(rows)


def verify_chroma_sensor_sync(collection, sensor_csv: Path = SENSOR_CSV) -> pd.DataFrame:
    """ChromaDB에 저장된 메타데이터가 sensor.csv와 일치하는지 검증."""
    sensor_df = load_sensor_df(sensor_csv)
    result = collection.get(include=["metadatas"])
    reports = []
    for meta in result.get("metadatas") or []:
        frame = meta.get("frame", "")
        csv_row = sensor_df[sensor_df["frame"] == frame]
        if csv_row.empty:
            reports.append({"frame": frame, "match": False, "mismatch_fields": "csv_missing"})
            continue
        r = csv_row.iloc[0]
        mismatches = []
        for col in ["temp", "rpm", "vibration", "current", "status"]:
            chroma_val = meta.get(col)
            csv_val = r[col]
            if col == "rpm":
                if int(chroma_val) != int(csv_val):
                    mismatches.append(col)
            elif col == "status":
                if str(chroma_val) != str(csv_val):
                    mismatches.append(col)
            elif float(chroma_val) != float(csv_val):
                mismatches.append(col)
        reports.append({
            "frame": frame,
            "match": len(mismatches) == 0,
            "mismatch_fields": ",".join(mismatches) if mismatches else "",
        })
    return pd.DataFrame(reports)


def enrich_hits_with_sensor(hits: list[dict], sensor_csv: Path = SENSOR_CSV) -> list[dict]:
    """검색 hit에 sensor.csv 최신값을 병합 (FastAPI /search 와 동일 패턴)."""
    enriched = []
    for hit in hits:
        item = dict(hit)
        frame = item.get("metadata", {}).get("frame", "")
        # Chroma 메타와 CSV를 이중으로 제공 — CSV가 최신 단일 진실 소스
        sensor = get_sensor_by_frame(frame, sensor_csv)
        if sensor:
            item["sensor"] = sensor
        enriched.append(item)
    return enriched


def filter_hits_by_status(hits: list[dict], status: str) -> list[dict]:
    """검색 결과에서 센서 status 로 필터 (Normal / Warning / Fault)."""
    status = status.strip()
    filtered = []
    for hit in hits:
        meta = hit.get("metadata", {})
        sensor = hit.get("sensor", meta)
        if str(sensor.get("status", "")).lower() == status.lower():
            filtered.append(hit)
    return filtered
