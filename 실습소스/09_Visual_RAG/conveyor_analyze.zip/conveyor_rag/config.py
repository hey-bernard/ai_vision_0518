"""프로젝트 전역 경로·모델 ID·하이퍼파라미터 상수."""

from pathlib import Path

# conveyor_analyze 패키지 루트 (이 파일 기준 parent.parent)
ROOT = Path(__file__).resolve().parent.parent
# 상위 = 09_Visual_RAG 프로젝트 루트 (노트북 02·03 실행 위치)
PROJECT_ROOT = ROOT.parent
_PROJECT_DATA = PROJECT_ROOT / "data" / "conveyor"
_LOCAL_DATA = ROOT / "data" / "conveyor"
# 02 노트북(프로젝트 루트) 데이터 우선 사용
# 노트북에서 만든 frames/ 가 있으면 API·스크립트도 동일 DB를 참조
DATA_DIR = _PROJECT_DATA if (_PROJECT_DATA / "frames").exists() else _LOCAL_DATA
FRAMES_DIR = DATA_DIR / "frames"          # OpenCV 추출 JPG 저장
VIDEO_DIR = DATA_DIR / "video"            # ZIP 해제·샘플 mp4
CHROMA_DIR = DATA_DIR / "chroma_db"       # ChromaDB PersistentClient 경로
SENSOR_CSV = DATA_DIR / "sensor.csv"      # 프레임별 가상 센서
HISTORY_JSON = DATA_DIR / "analysis_history.json"  # Qwen 분석 JSON 이력

# ZIP: 프로젝트 루트(09_Visual_RAG) 우선, 없으면 conveyor_analyze 폴더
ZIP_PATH = PROJECT_ROOT / "Conveyor_Belt_Sample.zip"
if not ZIP_PATH.exists():
    ZIP_PATH = ROOT / "Conveyor_Belt_Sample.zip"

# --- 모델·컬렉션 ---
SIGLIP2_MODEL_ID = "google/siglip2-so400m-patch14-384"  # 이미지·텍스트 공유 임베딩
# VRAM 8~12GB: 2B 권장 / 16GB+: 4B 가능
QWEN_MODEL_ID = "Qwen/Qwen3-VL-2B-Instruct"
COLLECTION_NAME = "conveyor_siglip2"              # 프레임 이미지 벡터
ANALYSIS_COLLECTION_NAME = "conveyor_analysis_results"  # Qwen 분석 텍스트 벡터
SIGLIP2_BATCH_SIZE = 8   # 인덱싱 배치 (OOM 시 4로 줄이기)
TOP_K_DEFAULT = 4        # 검색 기본 Top-k
API_BASE_URL_DEFAULT = "http://127.0.0.1:8000"  # Streamlit·노트북 API 호출 주소

# --- 프레임 추출 ---
FRAME_INTERVAL_SEC = 1.0       # 몇 초마다 1장 저장
NUM_FRAMES_DEFAULT = 20

# 데이터 디렉터리가 없으면 자동 생성 (최초 실행 시)
for d in [DATA_DIR, FRAMES_DIR, VIDEO_DIR, CHROMA_DIR]:
    d.mkdir(parents=True, exist_ok=True)
