"""FastAPI REST API — Conveyor Visual RAG."""

import bootstrap  # noqa: F401 — 프로젝트 루트를 sys.path에 등록

from contextlib import asynccontextmanager
from functools import lru_cache
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from api.schemas import AnalyzeRequest, EmbeddingRequest, SearchRequest, AnalysisSearchRequest
from conveyor_rag.analysis_store import AnalysisVectorStore
from conveyor_rag.analyzer import HistoryStore, QwenAnalyzer
from conveyor_rag.config import FRAMES_DIR, TOP_K_DEFAULT
from conveyor_rag.encoder import SigLIP2Encoder
from conveyor_rag.metadata_link import (
    build_frame_sensor_table,
    enrich_hits_with_sensor,
    verify_chroma_sensor_sync,
)
from conveyor_rag.sensor import get_all_sensors, get_sensor_by_frame
from conveyor_rag.store import ChromaStore


@lru_cache(maxsize=1)
def get_encoder() -> SigLIP2Encoder:
    """SigLIP2 싱글톤 — 첫 요청 시 로드, 이후 재사용."""
    return SigLIP2Encoder()


@lru_cache(maxsize=1)
def get_store() -> ChromaStore:
    return ChromaStore()


@lru_cache(maxsize=1)
def get_analyzer() -> QwenAnalyzer:
    return QwenAnalyzer()


@lru_cache(maxsize=1)
def get_analysis_store() -> AnalysisVectorStore:
    return AnalysisVectorStore()


history_store = HistoryStore()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """서버 기동 시 ChromaDB 인덱스 존재 여부 안내."""
    store = get_store()
    if store.count() == 0:
        print("[API] ChromaDB 비어 있음 — scripts/run_pipeline.py 먼저 실행하세요.")
    yield


app = FastAPI(
    title="Conveyor Visual RAG API",
    description="SigLIP2 + ChromaDB + Qwen3-VL + Sensor 연동 REST API",
    version="1.0.0",
    lifespan=lifespan,
)

# Streamlit 등 외부 클라이언트 CORS 허용
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    """서비스 상태·엔드포인트 목록·벡터 건수."""
    return {
        "service": "Conveyor Visual RAG API",
        "endpoints": [
            "/embedding", "/search", "/analyze", "/sensor", "/history",
            "/analysis/search", "/analysis/vectors",
            "/metadata/frames", "/metadata/verify",
        ],
        "vectors": get_store().count(),
        "analysis_vectors": get_analysis_store().count(),
    }


@app.post("/embedding")
def create_embedding(req: EmbeddingRequest):
    """프레임 이미지의 SigLIP2 임베딩 및 ChromaDB 메타데이터 조회."""
    frame = req.frame
    # frame0001 / frame1 등 다양한 입력 형식 정규화
    if not frame.endswith(".jpg"):
        frame = f"{frame}.jpg" if frame.startswith("frame") else f"frame{frame}.jpg"

    store = get_store()
    doc = store.get_by_frame(frame)
    if doc is None:
        # 인덱스에 없으면 온더플라이 임베딩 (저장은 하지 않음)
        path = FRAMES_DIR / frame
        if not path.exists():
            raise HTTPException(404, f"프레임 없음: {frame}")
        encoder = get_encoder()
        from PIL import Image
        emb = encoder.encode_images([Image.open(path).convert("RGB")])[0]
        sensor = get_sensor_by_frame(frame)
        return {
            "frame": frame,
            "embedding_dim": len(emb),
            "embedding_preview": emb[:8].tolist(),
            "metadata": sensor,
            "indexed": False,
        }

    return {
        "frame": frame,
        "embedding_dim": len(doc["embedding"]) if doc["embedding"] is not None else 0,
        "embedding_preview": list(doc["embedding"][:8]) if doc["embedding"] is not None else [],
        "metadata": doc["metadata"],
        "indexed": True,
    }


@app.post("/search")
def search_images(req: SearchRequest):
    """텍스트 쿼리 → SigLIP2 → ChromaDB Top-k 검색 (센서 메타데이터 포함)."""
    store = get_store()
    if store.count() == 0:
        raise HTTPException(503, "인덱스 없음. run_pipeline.py를 먼저 실행하세요.")

    encoder = get_encoder()
    query_emb = encoder.encode_texts([req.query])[0].tolist()
    hits = store.search(query_emb, top_k=req.top_k)
    hits = enrich_hits_with_sensor(hits)

    return {"query": req.query, "top_k": req.top_k, "results": hits}


@app.get("/search")
def search_images_get(
    query: str = Query(..., description="검색 쿼리"),
    top_k: int = Query(TOP_K_DEFAULT, ge=1, le=20),
):
    """GET 방식 검색 (브라우저·curl 테스트용)."""
    return search_images(SearchRequest(query=query, top_k=top_k))


def _release_encoder_gpu() -> None:
    """Qwen3-VL 로드 전 SigLIP2 GPU 메모리 해제."""
    encoder = get_encoder()
    encoder.unload()
    get_encoder.cache_clear()  # 다음 get_encoder() 호출 시 재로드


@app.post("/analyze")
def analyze_conveyor(req: AnalyzeRequest):
    """Visual RAG: 검색 → 센서 연계 → Qwen3-VL 분석."""
    search_result = search_images(SearchRequest(query=req.query, top_k=req.top_k))
    hits = search_result["results"]
    if not hits:
        raise HTTPException(404, "검색 결과 없음")

    image_paths = [h["metadata"]["local_path"] for h in hits]
    sensor_rows = [h.get("sensor") or h["metadata"] for h in hits]

    _release_encoder_gpu()
    analyzer = get_analyzer()
    analysis = analyzer.analyze_with_sensor(image_paths, sensor_rows, req.query)

    response = {
        "query": req.query,
        "retrieved_frames": [h["metadata"]["frame"] for h in hits],
        "sensor_data": sensor_rows,
        "analysis": analysis,
    }

    if req.save_history:
        saved = history_store.add({
            "query": req.query,
            "frames": response["retrieved_frames"],
            "analysis": analysis,
        })
        response["history_id"] = saved["id"]

        sensor_summary = "; ".join(
            f"{r.get('frame', '')}:{r.get('status', '')}" for r in sensor_rows
        )
        # 분석 텍스트를 별도 벡터 컬렉션에도 저장 (과거 분석 의미 검색용)
        vector_saved = get_analysis_store().add_result(
            get_encoder(),
            query=req.query,
            analysis=analysis,
            frames=response["retrieved_frames"],
            sensor_summary=sensor_summary,
            record_id=saved["id"],
        )
        response["analysis_vector_id"] = vector_saved["id"]

    return response


@app.get("/metadata/frames")
def get_linked_frame_metadata():
    """프레임 이미지 ↔ sensor.csv 조인 테이블."""
    df = build_frame_sensor_table()
    return {"count": len(df), "frames": df.to_dict(orient="records")}


@app.get("/metadata/verify")
def verify_metadata_sync():
    """ChromaDB 메타데이터와 sensor.csv 일치 여부 검증."""
    store = get_store()
    if store.count() == 0:
        raise HTTPException(503, "인덱스 없음. run_pipeline.py를 먼저 실행하세요.")
    report = verify_chroma_sensor_sync(store.collection)
    synced = bool(report["match"].all()) if len(report) else True
    return {
        "synced": synced,
        "total": len(report),
        "matched": int(report["match"].sum()) if len(report) else 0,
        "details": report.to_dict(orient="records"),
    }


@app.get("/sensor")
def get_sensor(
    frame: str | None = Query(None, description="frame0001.jpg"),
    status: str | None = Query(None, description="Normal/Warning/Fault 필터"),
):
    """센서 CSV 조회 — 프레임별 또는 상태 필터."""
    if frame:
        row = get_sensor_by_frame(frame)
        if row is None:
            raise HTTPException(404, f"센서 데이터 없음: {frame}")
        return row

    rows = get_all_sensors()
    if status:
        rows = [r for r in rows if r.get("status", "").lower() == status.lower()]
    return {"count": len(rows), "sensors": rows}


@app.get("/history")
def get_history(limit: int = Query(20, ge=1, le=100), record_id: int | None = None):
    """분석 이력 조회."""
    if record_id is not None:
        record = history_store.get(record_id)
        if record is None:
            raise HTTPException(404, f"이력 없음: id={record_id}")
        return record
    return {"count": len(history_store.list(limit)), "history": history_store.list(limit)}


@app.get("/analysis/vectors")
def analysis_vector_count():
    """분석 결과 벡터 DB 건수."""
    return {"collection": "conveyor_analysis_results", "count": get_analysis_store().count()}


@app.post("/analysis/search")
def search_analysis_results(req: AnalysisSearchRequest):
    """과거 분석 결과를 텍스트 쿼리로 벡터 검색."""
    store = get_analysis_store()
    if store.count() == 0:
        raise HTTPException(404, "저장된 분석 벡터 없음. /analyze를 먼저 실행하세요.")
    hits = store.search(get_encoder(), req.query, top_k=req.top_k)
    return {"query": req.query, "top_k": req.top_k, "results": hits}


@app.get("/analysis/search")
def search_analysis_results_get(
    query: str = Query(..., description="분석 이력 검색 쿼리"),
    top_k: int = Query(3, ge=1, le=20),
):
    return search_analysis_results(AnalysisSearchRequest(query=query, top_k=top_k))
