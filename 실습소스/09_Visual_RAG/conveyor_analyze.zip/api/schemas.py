"""FastAPI 요청/응답 Pydantic 스키마 — 입력 검증·기본값."""

from pydantic import BaseModel, Field


class SearchRequest(BaseModel):
    """POST /search 요청 본문."""
    query: str = Field(..., description="한글/영어 텍스트 검색 쿼리")
    top_k: int = Field(4, ge=1, le=20)


class AnalyzeRequest(BaseModel):
    """POST /analyze 요청 본문."""
    query: str = Field("컨베이어 벨트 이상 징후를 분석하세요.", description="분석 질문")
    top_k: int = Field(2, ge=1, le=4, description="분석 프레임 수 (VRAM 절약: 2 권장)")
    save_history: bool = True  # True면 JSON 이력 + 분석 벡터 DB 동시 저장


class EmbeddingRequest(BaseModel):
    """POST /embedding 요청 본문."""
    frame: str = Field(..., description="frame0001.jpg 또는 frame0001")


class SensorQuery(BaseModel):
    """센서 조회 쿼리 (확장용)."""
    frame: str | None = None
    status: str | None = None


class AnalysisSearchRequest(BaseModel):
    """POST /analysis/search 요청 본문."""
    query: str = Field(..., description="과거 분석 결과 검색 쿼리")
    top_k: int = Field(3, ge=1, le=20)
