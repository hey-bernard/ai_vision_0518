"""CLI 진입점: python -m image_story

별도 노트북 없이 Gradio UI만 실행할 때 사용한다.
"""

from image_story.gradio_app import launch

if __name__ == "__main__":
    launch()
