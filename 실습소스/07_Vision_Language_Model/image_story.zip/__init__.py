"""Industrial Image Story Generator — 교육용 PoC 패키지.

Qwen3-VL로 산업 이미지를 분석하고 OpenAI GPT로 다양한 스토리를 생성한다.

주요 공개 API:
  - StoryConfig: 전역 설정
  - ImageStoryPipeline: VLM 분석 + GPT 스토리 통합 파이프라인
  - StoryResult: 파이프라인 실행 결과
"""

from image_story.config import StoryConfig
from image_story.pipeline import ImageStoryPipeline, StoryResult

__all__ = ["StoryConfig", "ImageStoryPipeline", "StoryResult"]
