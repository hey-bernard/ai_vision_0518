"""Gradio UI — Industrial Image Story Generator.

좌측: 이미지 업로드 + Story Type 선택
우측: 이미지 표시 + 생성된 스토리 출력
"""

from __future__ import annotations

import gradio as gr
from PIL import Image

from image_story.config import STORY_TYPE_LABELS, StoryConfig
from image_story.pipeline import ImageStoryPipeline
from prompt_battle.dataset import build_image_choices
from prompt_battle.env_loader import load_env_file, openai_api_key_configured
from prompt_battle.vlm import Qwen3VLEngine, set_shared_engine

# 싱글톤 파이프라인 (모델 1회 로드)
# Gradio는 요청마다 함수가 호출되므로 전역 인스턴스로 VLM 중복 로드를 방지한다.
_PIPELINE: ImageStoryPipeline | None = None


def register_engine(engine: Qwen3VLEngine) -> None:
    """노트북에서 로드한 VLM 엔진을 Gradio와 공유."""
    set_shared_engine(engine)
    pipeline = get_pipeline()
    pipeline.attach_engine(engine)


def get_pipeline() -> ImageStoryPipeline:
    """싱글톤 ImageStoryPipeline 인스턴스 반환."""
    global _PIPELINE
    if _PIPELINE is None:
        load_env_file()
        # Gradio 전용 설정: 짧은 VLM 응답으로 UI 응답 속도 우선
        _PIPELINE = ImageStoryPipeline(StoryConfig.for_gradio())
        _PIPELINE.ensure_dataset()
    return _PIPELINE


def preload_model() -> str:
    """Gradio 시작 시 Qwen3-VL 모델 선로드.

    demo.load() 콜백에서 호출되어 앱 오픈 직후 모델을 GPU에 올린다.
    """
    load_env_file()
    pipeline = get_pipeline()
    try:
        pipeline.load_model()
        gpt_status = " · OpenAI API 준비됨" if openai_api_key_configured() else " · OpenAI API 키 없음"
        return f"✅ Qwen3-VL 준비 완료 — device: {pipeline.engine.device}{gpt_status}"
    except Exception as exc:
        return f"❌ 모델 로드 실패: {exc}"


def _story_type_choices() -> list[tuple[str, str]]:
    """Gradio Radio/Dropdown용 (표시명, 내부키) 목록."""
    return [(label, key) for key, label in STORY_TYPE_LABELS.items()]


def generate_story(
    uploaded_image,
    sample_label: str | None,
    story_type: str,
    path_map: dict[str, str],
) -> tuple:
    """이미지 업로드 또는 MVTec 샘플로 스토리 생성.

    Args:
        uploaded_image: Gradio Image(type=numpy) 업로드 배열 (우선 사용)
        sample_label: MVTec 드롭다운 표시 라벨
        story_type: STORY_TYPE_LABELS key
        path_map: 드롭다운 라벨 → 실제 파일 경로 매핑

    Returns:
        (PIL.Image, Markdown 문자열) 튜플
    """
    image = None
    image_path = None

    # 업로드 이미지 우선, 없으면 MVTec 샘플 사용
    if uploaded_image is not None:
        image = Image.fromarray(uploaded_image).convert("RGB")
    elif sample_label and sample_label in path_map:
        image_path = path_map[sample_label]
        image = Image.open(image_path).convert("RGB")
    else:
        return None, "⚠️ 이미지를 업로드하거나 MVTec 샘플을 선택하세요."

    if not openai_api_key_configured():
        return image, (
            "❌ **OpenAI API 키가 설정되지 않았습니다.**\n\n"
            "`C:\\env\\.env` 파일에 `OPENAI_API_KEY=...` 를 추가하세요."
        )

    pipeline = get_pipeline()
    try:
        result = pipeline.run(image, story_type, image_path=image_path)
        pipeline.save_result(result)
        return image, result.full_markdown()
    except Exception as exc:
        return image, f"❌ 스토리 생성 오류: {exc}"


def build_demo(shared_engine: Qwen3VLEngine | None = None) -> gr.Blocks:
    """Gradio Blocks UI 구성."""
    if shared_engine is not None and shared_engine.is_loaded:
        register_engine(shared_engine)

    pipeline = get_pipeline()
    # MVTec test 이미지 드롭다운 목록 (prompt_battle.dataset 재사용)
    sample_choices = build_image_choices(pipeline.data_root, pipeline.config.categories)
    path_map = {label: path for label, path in sample_choices}
    story_choices = _story_type_choices()
    default_story = story_choices[0][1]

    with gr.Blocks(title="Industrial Image Story Generator") as demo:
        gr.Markdown(
            "# Industrial Image Story Generator\n"
            "산업 이미지를 **Qwen3-VL**로 분석하고 **OpenAI GPT**로 "
            "생산 공정·결함·현장 상황 스토리를 생성하는 교육용 PoC\n\n"
            "> **흐름**: 이미지 업로드 → VLM 분석(제품·상태·특징) → GPT 스토리 생성"
        )

        status_box = gr.Markdown("⏳ 모델 로딩 중...")

        with gr.Row():
            # ── 좌측: 입력 ──
            with gr.Column(scale=1):
                gr.Markdown("### 입력")
                upload_image = gr.Image(
                    label="이미지 업로드",
                    type="numpy",   # numpy 배열로 받아 PIL 변환
                    height=280,
                )
                sample_dropdown = gr.Dropdown(
                    choices=[c[0] for c in sample_choices],
                    value=None,
                    label="MVTec AD 샘플 (선택)",
                    interactive=True,
                )
                story_type = gr.Radio(
                    choices=story_choices,
                    value=default_story,
                    label="Story Type",
                )
                generate_btn = gr.Button("스토리 생성", variant="primary")

            # ── 우측: 출력 ──
            with gr.Column(scale=2):
                gr.Markdown("### 결과")
                display_image = gr.Image(label="이미지", type="pil", height=360)
                story_output = gr.Markdown(label="생성된 스토리")

        def on_sample_select(label: str | None, current_upload):
            """MVTec 샘플 선택 시 우측 이미지 미리보기 (업로드 없을 때)."""
            # 사용자가 직접 업로드한 이미지가 있으면 샘플 선택보다 업로드를 우선 표시
            if current_upload is not None:
                return Image.fromarray(current_upload).convert("RGB")
            if label and label in path_map:
                return Image.open(path_map[label]).convert("RGB")
            return None

        def on_generate(uploaded, sample, stype):
            return generate_story(uploaded, sample, stype, path_map)

        sample_dropdown.change(
            on_sample_select,
            inputs=[sample_dropdown, upload_image],
            outputs=display_image,
        )
        upload_image.change(
            lambda img: Image.fromarray(img).convert("RGB") if img is not None else None,
            inputs=upload_image,
            outputs=display_image,
        )
        generate_btn.click(
            on_generate,
            inputs=[upload_image, sample_dropdown, story_type],
            outputs=[display_image, story_output],
        )

        def on_app_load():
            """앱 최초 로드 시 모델 선로드 + 상태 메시지 갱신."""
            status = preload_model()
            return status

        demo.load(on_app_load, outputs=status_box)

    return demo


def launch(shared_engine: Qwen3VLEngine | None = None, **kwargs):
    """Gradio 앱 실행.

    Args:
        shared_engine: 노트북에서 이미 로드한 Qwen3VLEngine (VRAM 절약)
        **kwargs: gr.Blocks.launch()에 전달 (share, server_port 등)
    """
    demo = build_demo(shared_engine=shared_engine)
    demo.launch(**kwargs)


if __name__ == "__main__":
    launch()
