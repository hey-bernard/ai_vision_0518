"""Industrial Image Story Generator — 통합 파이프라인.

이미지 입력 → Qwen3-VL 분석 → OpenAI GPT 스토리 생성 → 결과 저장
을 하나의 클래스(ImageStoryPipeline)로 묶는다.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image

from image_story.analyzer import ImageAnalysis, ImageAnalyzer
from image_story.config import STORY_TYPE_LABELS, StoryConfig
from image_story.storyteller import StoryGenerator
from prompt_battle.config import BattleConfig
from prompt_battle.dataset import (
    extract_mvtec_zip,
    find_project_root,
    ground_truth_defect,
    resolve_data_root,
)
from prompt_battle.vlm import Qwen3VLEngine, get_shared_engine, set_shared_engine


@dataclass
class StoryResult:
    """이미지 분석 + 스토리 생성 전체 결과.

    노트북·Gradio UI·JSON 저장에서 공통으로 사용하는 결과 컨테이너다.
    """

    image_path: str | None          # 입력 이미지 경로 (업로드만 한 경우 None)
    story_type: str                 # 내부 스토리 유형 key
    story_type_label: str           # UI 표시용 영문 라벨
    analysis: ImageAnalysis         # VLM 분석 결과
    story_text: str                 # GPT 생성 스토리 본문
    ground_truth_defect: str | None = None  # MVTec 경로에서 추출한 정답 결함 유형

    def full_markdown(self) -> str:
        """분석 + 스토리를 하나의 Markdown으로 반환."""
        from image_story.storyteller import StoryGenerator as _StoryGenerator

        generator = _StoryGenerator()
        story_md = generator.format_story_output(self.story_type, self.story_text)
        gt_line = ""
        # MVTec 샘플 이미지인 경우 폴더명 기반 ground truth를 참고 정보로 표시
        if self.ground_truth_defect:
            gt_line = f"\n\n> **MVTec Ground Truth**: `{self.ground_truth_defect}`"
        return f"{self.analysis.to_markdown()}\n\n---\n\n{story_md}{gt_line}"


class ImageStoryPipeline:
    """Qwen3-VL 분석 → OpenAI 스토리 생성 파이프라인."""

    def __init__(self, config: StoryConfig | None = None, root: Path | None = None):
        self.config = config or StoryConfig()
        # MVTec zip·데이터가 있는 프로젝트 루트 (prompt_battle.dataset 재사용)
        self.root = root or find_project_root()
        self.zip_path = self.root / self.config.zip_name
        self.data_root = resolve_data_root(
            self.root / self.config.data_dir_name,
            self.config.categories,
        )
        self.output_dir = (self.root / self.config.output_dir).resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # prompt_battle VLM 엔진 재사용 (노트북·Gradio 공유)
        # 노트북에서 이미 load()한 엔진이 있으면 VRAM 중복 로드를 방지한다.
        shared = get_shared_engine()
        if shared is not None and shared.is_loaded:
            self.engine = shared
        else:
            # StoryConfig → BattleConfig 변환 후 새 엔진 생성
            battle_cfg = BattleConfig(
                qwen_model_id=self.config.qwen_model_id,
                min_pixels=self.config.min_pixels,
                max_pixels=self.config.max_pixels,
                max_new_tokens=self.config.max_new_tokens,
                force_single_gpu=self.config.force_single_gpu,
            )
            self.engine = Qwen3VLEngine(battle_cfg)

        self.analyzer = ImageAnalyzer(self.engine, self.config)
        self.story_generator = StoryGenerator(self.config)

    def attach_engine(self, engine: Qwen3VLEngine) -> None:
        """외부에서 로드한 VLM 엔진을 파이프라인에 연결.

        노트북에서 engine.load() 후 pipeline.attach_engine(engine) 호출 시
        Gradio와 동일한 모델 인스턴스를 공유한다.
        """
        self.engine = engine
        self.analyzer = ImageAnalyzer(engine, self.config)
        set_shared_engine(engine)

    def load_model(self) -> None:
        """Qwen3-VL 모델 로드."""
        self.engine.load()

    def ensure_dataset(self) -> None:
        """MVTec zip 압축 해제 (이미 있으면 스킵)."""
        extract_mvtec_zip(
            self.zip_path,
            self.root / self.config.data_dir_name,
            self.config.categories,
        )
        # zip 중첩 구조(MVTec_screw_metal_nut/MVTec_screw_metal_nut/) 대응
        self.data_root = resolve_data_root(
            self.root / self.config.data_dir_name,
            self.config.categories,
        )

    def run(
        self,
        image: Image.Image,
        story_type: str,
        *,
        image_path: str | Path | None = None,
    ) -> StoryResult:
        """이미지 분석 후 선택한 유형의 스토리를 생성.

        파이프라인 단계:
          1) RGB 변환
          2) ImageAnalyzer.analyze() — Qwen3-VL
          3) StoryGenerator.generate() — OpenAI GPT
          4) StoryResult 패키징
        """
        if story_type not in STORY_TYPE_LABELS:
            raise ValueError(f"지원하지 않는 스토리 유형: {story_type}")

        if not self.engine.is_loaded:
            self.load_model()

        rgb_image = image.convert("RGB")
        analysis = self.analyzer.analyze(rgb_image)
        story_text = self.story_generator.generate(analysis, story_type)

        gt = None
        if image_path:
            # .../test/scratch_head/000.png → "scratch_head"
            gt = ground_truth_defect(Path(image_path))

        return StoryResult(
            image_path=str(image_path) if image_path else None,
            story_type=story_type,
            story_type_label=STORY_TYPE_LABELS[story_type],
            analysis=analysis,
            story_text=story_text,
            ground_truth_defect=gt,
        )

    def save_result(self, result: StoryResult) -> Path:
        """결과를 JSON 파일로 저장.

        outputs/image_story/story_{유형}_{타임스탬프}.json 형식으로 저장한다.
        """
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        filename = f"story_{result.story_type}_{timestamp}.json"
        out_path = self.output_dir / filename
        payload = {
            "image_path": result.image_path,
            "story_type": result.story_type,
            "story_type_label": result.story_type_label,
            "ground_truth_defect": result.ground_truth_defect,
            "analysis": self.analyzer.analysis_to_dict(result.analysis),
            "story_text": result.story_text,
            "saved_at": datetime.now(timezone.utc).isoformat(),
        }
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return out_path
