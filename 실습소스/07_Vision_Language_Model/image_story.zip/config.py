"""Industrial Image Story Generator — 전역 설정.

모델 ID, 토큰 한도, 데이터 경로, 스토리 유형 등
파이프라인 전반에서 공유하는 하이퍼파라미터를 한곳에서 관리한다.
"""

from dataclasses import dataclass, field
from pathlib import Path


# Gradio·노트북에서 선택 가능한 스토리 유형
# key: 내부 식별자 (코드에서 사용) / value: UI에 표시되는 영문 라벨
STORY_TYPE_LABELS: dict[str, str] = {
    "image_description": "Image Description",
    "manufacturing": "Manufacturing Story",
    "defect": "Defect Story",
    "incident": "Incident Story",
    "prevention": "Prevention Guide",
}


@dataclass
class StoryConfig:
    """스토리 생성 파이프라인 전역 설정."""

    # ── Qwen3-VL (Vision-Language Model) ─────────────────────────
    qwen_model_id: str = "Qwen/Qwen3-VL-4B-Instruct"  # Hugging Face 모델 ID
    # vision 토큰 수에 영향 — 이미지 리사이즈 하한/상한 (28×28 패치 기준)
    min_pixels: int = 256 * 28 * 28
    max_pixels: int = 768 * 28 * 28   # VRAM 절약을 위해 768 패치 상한
    max_new_tokens: int = 512         # VLM 일반 생성 최대 토큰
    analysis_max_new_tokens: int = 384  # 이미지 분석(JSON) 전용 — 스토리보다 짧게
    force_single_gpu: bool = True     # True면 CPU 오프로드 없이 단일 GPU에 적재

    # ── OpenAI GPT (LLM 스토리 생성) ─────────────────────────────
    gpt_model: str = "gpt-4o-mini"    # 비용·속도 균형이 좋은 교육용 모델
    gpt_max_tokens: int = 1024        # 생성 스토리 최대 길이
    gpt_temperature: float = 0.7      # 0에 가까울수록 결정적, 1에 가까울수록 창의적
    env_file: Path = field(default_factory=lambda: Path(r"C:\env\.env"))  # API 키 경로

    # ── MVTec AD 데이터셋 ────────────────────────────────────────
    categories: tuple[str, ...] = ("screw", "metal_nut")  # 사용 카테고리
    zip_name: str = "MVTec_screw_metal_nut.zip"           # 프로젝트 루트 zip 파일명
    data_dir_name: str = "MVTec_screw_metal_nut"          # 압축 해제 폴더명

    # ── 출력 ─────────────────────────────────────────────────────
    output_dir: Path = field(default_factory=lambda: Path("outputs") / "image_story")

    # 결함 유형 한글 라벨 (경로 ground truth 참고용)
    # MVTec test/ 하위 폴더명 → 한글 표시 (교육·리포트용)
    defect_labels_ko: dict[str, str] = field(
        default_factory=lambda: {
            "good": "정상",
            "manipulated_front": "전면 변형",
            "scratch_head": "나사 머리 스크래치",
            "scratch_neck": "나사 목 스크래치",
            "thread_side": "나사산 측면 결함",
            "thread_top": "나사산 상단 결함",
            "bent": "휨",
            "color": "색상 이상",
            "flip": "뒤집힘/방향 불량",
            "scratch": "스크래치",
        }
    )

    @classmethod
    def for_gradio(cls) -> "StoryConfig":
        """Gradio UI용 설정 (짧은 VLM 응답·단일 GPU)."""
        # 웹 UI는 응답 속도가 중요하므로 분석 토큰을 더 줄인다
        return cls(analysis_max_new_tokens=320, force_single_gpu=True)
