"""Qwen3-VL 기반 산업 이미지 분석 모듈.

제품 종류, 상태 설명, 특징 추출을 수행하여 LLM 스토리 생성의 입력 컨텍스트를 만든다.

흐름: PIL Image → Qwen3-VL(ANALYSIS_PROMPT) → JSON 파싱 → ImageAnalysis
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, asdict

from PIL import Image

from image_story.config import StoryConfig
from prompt_battle.vlm import Qwen3VLEngine

# VLM 분석용 구조화 프롬프트
# GPT 스토리 생성 전에 VLM이 이미지를 "구조화된 사실"로 요약하도록 유도한다.
# JSON 출력을 강제하여 후속 LLM 프롬프트에 안정적으로 삽입할 수 있다.
ANALYSIS_PROMPT = """당신은 제조업 품질 검사 전문가입니다.
이 산업용 제품 이미지를 분석하세요.

다음 항목을 한국어로 작성하세요:
1) 제품 종류 (예: screw, metal_nut 등)
2) 상태 설명 (정상/불량 여부, 시각적 상태)
3) 특징 추출 (형태, 표면, 색상, 결함 징후 등)

반드시 아래 JSON 형식만 출력하세요:
{
  "product_type": "제품 종류",
  "condition": "상태 설명",
  "features": ["특징1", "특징2", "특징3"],
  "defect_observed": "관찰된 결함 (없으면 정상)",
  "summary": "한 줄 요약"
}"""


@dataclass
class ImageAnalysis:
    """Qwen3-VL 이미지 분석 결과.

    VLM 원문 응답(raw_response)과 파싱된 필드를 함께 보관하여
    UI 표시·GPT 컨텍스트·JSON 저장에 재사용한다.
    """

    product_type: str       # 제품 종류 (screw, metal_nut 등)
    condition: str            # 정상/불량 및 시각적 상태 설명
    features: list[str]     # 형태·표면·색상 등 관찰 특징 목록
    defect_observed: str     # 관찰된 결함 (없으면 "정상")
    summary: str            # 한 줄 요약
    raw_response: str       # VLM 원문 (디버깅·교육용)
    analysis_time_sec: float  # 추론 소요 시간(초)

    def to_markdown(self) -> str:
        """분석 결과를 Markdown으로 포맷."""
        features_text = "\n".join(f"- {item}" for item in self.features) or "- (없음)"
        return (
            f"### Qwen3-VL 이미지 분석\n\n"
            f"| 항목 | 내용 |\n"
            f"|------|------|\n"
            f"| **제품 종류** | {self.product_type} |\n"
            f"| **상태 설명** | {self.condition} |\n"
            f"| **관찰 결함** | {self.defect_observed} |\n"
            f"| **요약** | {self.summary} |\n\n"
            f"**특징 추출**\n{features_text}\n\n"
            f"> 분석 소요: {self.analysis_time_sec:.1f}초"
        )

    def to_context_text(self) -> str:
        """GPT 스토리 생성용 텍스트 컨텍스트.

        VLM이 본 이미지 정보를 자연어 블록으로 변환하여
        StoryGenerator의 user 프롬프트 {context} 자리에 삽입한다.
        """
        features_text = ", ".join(self.features)
        return (
            f"제품 종류: {self.product_type}\n"
            f"상태 설명: {self.condition}\n"
            f"특징: {features_text}\n"
            f"관찰 결함: {self.defect_observed}\n"
            f"요약: {self.summary}"
        )


def _parse_analysis_json(text: str) -> dict:
    """VLM 응답에서 JSON 블록을 추출·파싱.

    VLM이 설명문과 JSON을 함께 출력할 수 있으므로
    정규식으로 첫 번째 { ... } 블록만 추출한다.
    """
    match = re.search(r"\{[\s\S]*\}", text)
    if not match:
        raise ValueError("VLM 응답에서 JSON을 찾을 수 없습니다.")
    return json.loads(match.group())


def _fallback_analysis(raw_response: str, elapsed: float) -> ImageAnalysis:
    """JSON 파싱 실패 시 원문을 그대로 활용하는 폴백 분석.

    VLM이 JSON 형식을 지키지 않아도 파이프라인이 중단되지 않도록
    원문 일부를 condition/summary에 넣어 후속 GPT 호출을 허용한다.
    """
    return ImageAnalysis(
        product_type="미확인",
        condition=raw_response[:300],
        features=[],
        defect_observed="미확인",
        summary=raw_response[:120],
        raw_response=raw_response,
        analysis_time_sec=round(elapsed, 2),
    )


class ImageAnalyzer:
    """Qwen3-VL을 이용한 산업 이미지 분석기."""

    def __init__(self, engine: Qwen3VLEngine, config: StoryConfig | None = None):
        """Args:
            engine: prompt_battle.vlm.Qwen3VLEngine (이미 load()된 인스턴스 권장)
            config: 토큰 한도 등 분석 설정
        """
        self.engine = engine
        self.config = config or StoryConfig()

    def analyze(self, image: Image.Image) -> ImageAnalysis:
        """이미지 1장을 분석하여 구조화된 ImageAnalysis를 반환.

        1) engine.ask()로 VLM 추론
        2) JSON 파싱 시도
        3) 실패 시 _fallback_analysis()로 폴백
        """
        response, elapsed = self.engine.ask(
            image,
            ANALYSIS_PROMPT,
            max_new_tokens=self.config.analysis_max_new_tokens,
        )
        try:
            data = _parse_analysis_json(response)
            features = data.get("features", [])
            # VLM이 features를 문자열 하나로 줄 경우 리스트로 정규화
            if isinstance(features, str):
                features = [features]
            return ImageAnalysis(
                product_type=str(data.get("product_type", "미확인")),
                condition=str(data.get("condition", "")),
                features=[str(f) for f in features],
                defect_observed=str(data.get("defect_observed", "미확인")),
                summary=str(data.get("summary", "")),
                raw_response=response,
                analysis_time_sec=round(elapsed, 2),
            )
        except (json.JSONDecodeError, ValueError):
            return _fallback_analysis(response, elapsed)

    def analysis_to_dict(self, analysis: ImageAnalysis) -> dict:
        """분석 결과를 JSON 저장용 dict로 변환."""
        return asdict(analysis)
