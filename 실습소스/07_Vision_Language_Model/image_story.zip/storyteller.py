"""OpenAI GPT 기반 산업 이미지 스토리 생성 모듈.

VLM 분석 결과(ImageAnalysis)를 컨텍스트로 받아
5가지 Story Type에 맞는 교육용 내러티브를 생성한다.

흐름: ImageAnalysis → system/user 프롬프트 조합 → OpenAI Chat API → 스토리 텍스트
"""

from __future__ import annotations

from image_story.analyzer import ImageAnalysis
from image_story.config import STORY_TYPE_LABELS, StoryConfig
from prompt_battle.env_loader import get_openai_api_key, load_env_file

# 스토리 유형별 GPT 시스템 프롬프트
# system 역할: GPT의 페르소나·작성 톤·전문 분야를 고정한다.
STORY_SYSTEM_PROMPTS: dict[str, str] = {
    "image_description": (
        "당신은 제조업 현장을 잘 아는 기술 문서 작성자입니다. "
        "이미지 분석 결과를 바탕으로 이미지 내용을 명확하고 객관적으로 설명하세요."
    ),
    "manufacturing": (
        "당신은 제조 공정 전문가입니다. "
        "이미지에 보이는 제품이 어떤 생산 공정(원자재, 가공, 열처리, 표면처리, 검사 등)을 "
        "거쳐 제조되었는지 교육용 내러티브로 설명하세요."
    ),
    "defect": (
        "당신은 품질 공학(QE) 전문가입니다. "
        "이미지 분석 결과를 바탕으로 결함이 어떻게 발생했는지 원인을 추론하여 "
        "공정·재료·취급 관점에서 설명하세요."
    ),
    "incident": (
        "당신은 스마트팩토리 현장 관리자입니다. "
        "이 제품/결함과 관련해 현장에서 발생했을 법한 짧은 사건 스토리를 "
        "3~5문단의 현실적인 이야기로 작성하세요."
    ),
    "prevention": (
        "당신은 제조 품질 개선 컨설턴트입니다. "
        "관찰된 상태를 바탕으로 예방 대책, 공정 개선, 검사 강화 방안을 "
        "실무에서 바로 참고할 수 있게 제안하세요."
    ),
}

# 스토리 유형별 사용자 프롬프트 템플릿
# user 역할: VLM 분석 컨텍스트({context})와 구체적 작성 지시를 전달한다.
STORY_USER_TEMPLATES: dict[str, str] = {
    "image_description": (
        "아래는 Vision-Language Model이 분석한 산업 이미지 정보입니다.\n\n"
        "{context}\n\n"
        "위 정보를 바탕으로 **Image Description**을 한국어로 작성하세요.\n"
        "- 이미지에 보이는 제품과 상태를 구체적으로 설명\n"
        "- 교육용이므로 전문적이되 이해하기 쉽게 작성\n"
        "- 3~5문단, 불릿 목록 사용 가능"
    ),
    "manufacturing": (
        "아래는 Vision-Language Model이 분석한 산업 이미지 정보입니다.\n\n"
        "{context}\n\n"
        "위 정보를 바탕으로 **Manufacturing Story**를 한국어로 작성하세요.\n"
        "- 이 제품이 거쳤을 법한 생산 공정 단계를 시간 순서로 서술\n"
        "- 각 공정에서 일어나는 작업을 교육용 예시로 설명\n"
        "- 4~6문단"
    ),
    "defect": (
        "아래는 Vision-Language Model이 분석한 산업 이미지 정보입니다.\n\n"
        "{context}\n\n"
        "위 정보를 바탕으로 **Defect Story**를 한국어로 작성하세요.\n"
        "- 결함이 발생한 것으로 추정되는 과정을 단계별로 추론\n"
        "- 가능한 원인(공정, 설비, 자재, 취급)을 포함\n"
        "- 정상 제품이면 '결함 없음'임을 명시하고 잠재 리스크만 언급\n"
        "- 3~5문단"
    ),
    "incident": (
        "아래는 Vision-Language Model이 분석한 산업 이미지 정보입니다.\n\n"
        "{context}\n\n"
        "위 정보를 바탕으로 **Incident Story**를 한국어로 작성하세요.\n"
        "- 현장 작업자·품질 검사원 관점의 짧은 이야기\n"
        "- CCTV/검사 라인/조립 공정 등 구체적 배경 설정\n"
        "- 3~4문단, 대화 1~2문장 포함 가능"
    ),
    "prevention": (
        "아래는 Vision-Language Model이 분석한 산업 이미지 정보입니다.\n\n"
        "{context}\n\n"
        "위 정보를 바탕으로 **Prevention Guide**를 한국어로 작성하세요.\n"
        "- 예방 대책 (공정·설비·작업 표준)\n"
        "- 검사/모니터링 개선 방안\n"
        "- 교육·훈련 제안\n"
        "- 불릿 목록 5~8개 + 마무리 한 문단"
    ),
}


class StoryGenerator:
    """OpenAI GPT를 이용한 스토리 생성기."""

    def __init__(self, config: StoryConfig | None = None):
        self.config = config or StoryConfig()

    def _get_client(self):
        """OpenAI 클라이언트 생성 (.env에서 API 키 로드).

        C:\\env\\.env 의 OPENAI_API_KEY를 prompt_battle.env_loader로 읽는다.
        키가 없으면 EnvironmentError를 발생시켜 조기 실패한다.
        """
        load_env_file(self.config.env_file)
        api_key = get_openai_api_key()
        if not api_key:
            raise EnvironmentError(
                "OPENAI_API_KEY가 설정되지 않았습니다. "
                f"{self.config.env_file} 파일을 확인하세요."
            )
        from openai import OpenAI

        return OpenAI(api_key=api_key)

    def generate(self, analysis: ImageAnalysis, story_type: str) -> str:
        """분석 결과와 스토리 유형을 받아 GPT 스토리를 생성.

        Args:
            analysis: Qwen3-VL이 추출한 ImageAnalysis
            story_type: STORY_TYPE_LABELS의 key (예: "defect", "manufacturing")

        Returns:
            생성된 스토리 본문(한국어 Markdown 호환 텍스트)
        """
        if story_type not in STORY_TYPE_LABELS:
            raise ValueError(f"지원하지 않는 스토리 유형: {story_type}")

        client = self._get_client()
        system_prompt = STORY_SYSTEM_PROMPTS[story_type]
        # VLM 분석을 자연어 블록으로 변환하여 user 프롬프트에 삽입
        user_prompt = STORY_USER_TEMPLATES[story_type].format(
            context=analysis.to_context_text()
        )

        response = client.chat.completions.create(
            model=self.config.gpt_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=self.config.gpt_temperature,
            max_tokens=self.config.gpt_max_tokens,
        )
        return (response.choices[0].message.content or "").strip()

    def format_story_output(self, story_type: str, story_text: str) -> str:
        """스토리 유형 제목과 본문을 Markdown으로 포맷."""
        label = STORY_TYPE_LABELS.get(story_type, story_type)
        return f"## {label}\n\n{story_text}"
