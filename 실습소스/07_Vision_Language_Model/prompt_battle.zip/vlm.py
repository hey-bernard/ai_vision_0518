"""Qwen3-VL 추론 엔진.

Hugging Face Transformers의 Qwen3VLForConditionalGeneration을 사용하여
단일 이미지 + 텍스트 프롬프트에 대한 VLM 응답을 생성한다.
"""

import time
from dataclasses import dataclass

import torch
from PIL import Image
from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

from prompt_battle.config import BattleConfig

# 노트북 등에서 이미 로드한 엔진을 Gradio와 공유
# → 동일 커널에서 모델 2중 로드로 인한 VRAM 낭비·CPU 오프로드 방지
_SHARED_ENGINE: "Qwen3VLEngine | None" = None


def set_shared_engine(engine: "Qwen3VLEngine") -> None:
    """외부에서 로드한 Qwen3-VL 엔진을 Gradio와 공유."""
    global _SHARED_ENGINE
    _SHARED_ENGINE = engine


def get_shared_engine() -> "Qwen3VLEngine | None":
    """공유 엔진 조회."""
    return _SHARED_ENGINE


@dataclass
class InferenceResult:
    """단일 프롬프트 VLM 추론 결과."""

    prompt_key: str           # 프롬프트 내부 키
    prompt_display_name: str  # UI 표시명
    prompt_text: str          # 실제 입력 프롬프트
    response: str             # VLM 생성 텍스트
    response_length: int      # 응답 문자 수
    response_time_sec: float  # 추론 소요 시간(초)


class Qwen3VLEngine:
    """Hugging Face Transformers 기반 Qwen3-VL 추론 클래스."""

    def __init__(self, config: BattleConfig | None = None):
        self.config = config or BattleConfig()
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        # CUDA bf16 지원 GPU면 bfloat16, 아니면 float16 사용
        self.dtype = torch.bfloat16 if self.device == "cuda" and torch.cuda.is_bf16_supported() else torch.float16
        self.processor: AutoProcessor | None = None
        self.model: Qwen3VLForConditionalGeneration | None = None

    def load(self) -> None:
        """Qwen3-VL 프로세서·모델을 GPU(가능 시)에 로드."""
        if self.is_loaded:
            return

        if self.device == "cuda":
            torch.cuda.empty_cache()  # 로드 전 VRAM 정리

        self.processor = AutoProcessor.from_pretrained(
            self.config.qwen_model_id,
            min_pixels=self.config.min_pixels,
            max_pixels=self.config.max_pixels,
            trust_remote_code=True,
        )

        # force_single_gpu: CPU 오프로드 없이 단일 GPU에 전체 적재
        if self.device == "cuda" and self.config.force_single_gpu:
            self.model = Qwen3VLForConditionalGeneration.from_pretrained(
                self.config.qwen_model_id,
                torch_dtype=self.dtype,
                trust_remote_code=True,
            )
            self.model = self.model.to(self.device)
        else:
            # accelerate device_map="auto" 폴백 (VRAM 부족 시 CPU 오프로드 가능)
            try:
                import accelerate  # noqa: F401

                has_accelerate = True
            except ImportError:
                has_accelerate = False

            load_kwargs: dict = {
                "torch_dtype": self.dtype,
                "trust_remote_code": True,
            }
            if has_accelerate and self.device == "cuda":
                load_kwargs["device_map"] = "auto"

            self.model = Qwen3VLForConditionalGeneration.from_pretrained(
                self.config.qwen_model_id,
                **load_kwargs,
            )
            if not (has_accelerate and self.device == "cuda"):
                self.model = self.model.to(self.device)

        self.model.eval()  # 추론 모드 고정

    @property
    def is_loaded(self) -> bool:
        """모델 로드 여부."""
        return self.model is not None and self.processor is not None

    def _move_inputs(self, inputs: dict) -> dict:
        """입력 텐서를 모델 디바이스·dtype에 맞게 이동."""
        assert self.model is not None
        model_device = next(self.model.parameters()).device
        moved: dict = {}
        for key, value in inputs.items():
            if not hasattr(value, "to"):
                moved[key] = value
            elif key == "pixel_values":
                # 이미지 텐서는 모델 dtype(bf16/fp16)에 맞춤
                moved[key] = value.to(model_device, dtype=self.dtype)
            else:
                moved[key] = value.to(model_device)
        return moved

    def _decode(self, inputs: dict, output_ids: torch.Tensor) -> str:
        """생성 토큰에서 assistant 응답만 디코딩.

        input_ids 길이만큼 잘라내어 프롬프트 토큰을 제외한 생성분만 디코딩한다.
        """
        assert self.processor is not None
        trimmed = [out[len(inp) :] for inp, out in zip(inputs["input_ids"], output_ids)]
        return self.processor.batch_decode(
            trimmed,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        )[0].strip()

    def ask(self, image: Image.Image, question: str, *, max_new_tokens: int | None = None) -> tuple[str, float]:
        """단일 이미지·질문에 대해 VLM 응답과 소요 시간(초) 반환."""
        if not self.is_loaded:
            raise RuntimeError("모델이 로드되지 않았습니다. load()를 먼저 호출하세요.")

        assert self.processor is not None
        assert self.model is not None

        # Qwen3-VL 멀티모달 대화 형식: 이미지 + 텍스트
        content = [
            {"type": "image", "image": image.convert("RGB")},
            {"type": "text", "text": question},
        ]
        conversation = [{"role": "user", "content": content}]
        inputs = self.processor.apply_chat_template(
            conversation,
            add_generation_prompt=True,
            tokenize=True,
            return_dict=True,
            return_tensors="pt",
        )
        inputs = self._move_inputs(inputs)

        tokens = max_new_tokens or self.config.max_new_tokens
        start = time.perf_counter()
        with torch.no_grad():
            output_ids = self.model.generate(**inputs, max_new_tokens=tokens, do_sample=False)
        elapsed = time.perf_counter() - start
        return self._decode(inputs, output_ids), elapsed

    def run_prompt(
        self,
        image: Image.Image,
        prompt_key: str,
        prompt_display_name: str,
        prompt_text: str,
    ) -> InferenceResult:
        """단일 프롬프트 템플릿을 이미지에 적용."""
        response, elapsed = self.ask(image, prompt_text)
        return InferenceResult(
            prompt_key=prompt_key,
            prompt_display_name=prompt_display_name,
            prompt_text=prompt_text,
            response=response,
            response_length=len(response),
            response_time_sec=round(elapsed, 2),
        )
