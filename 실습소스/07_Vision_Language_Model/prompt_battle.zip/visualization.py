"""matplotlib 기반 평가 점수 시각화.

프롬프트 유형별 GPT/휴리스틱 평가 점수를 막대그래프로 표시한다.
최고 점수 프롬프트는 강조 색상으로 표시한다.
"""

from pathlib import Path

import matplotlib.font_manager as fm
import matplotlib.pyplot as plt

from prompt_battle.evaluation import EvaluationReport


def setup_korean_font() -> str:
    """matplotlib 한글 폰트 설정 (Windows/Mac/Linux 순서로 탐색)."""
    for font in ("Malgun Gothic", "AppleGothic", "NanumGothic", "Noto Sans KR"):
        if font in {f.name for f in fm.fontManager.ttflist}:
            plt.rcParams["font.family"] = font
            plt.rcParams["font.sans-serif"] = [font, "DejaVu Sans"]
            plt.rcParams["axes.unicode_minus"] = False  # 마이너스 기호 깨짐 방지
            return font
    plt.rcParams["axes.unicode_minus"] = False
    return "sans-serif"


def plot_evaluation_scores(
    report: EvaluationReport,
    *,
    title: str = "Prompt Battle — Evaluation Score",
    save_path: Path | None = None,
    figsize: tuple[float, float] = (10, 5),
) -> plt.Figure:
    """프롬프트 유형별 평가 점수 막대그래프 생성.

    Args:
        report: EvaluationReport (scores, best_prompt 포함).
        title: 차트 제목.
        save_path: 지정 시 PNG 파일로 저장.
        figsize: Figure 크기 (inch).

    Returns:
        matplotlib Figure 객체 (Gradio gr.Plot 또는 plt.show()용).
    """
    setup_korean_font()

    labels = [s.prompt_type for s in report.scores]
    values = [s.score for s in report.scores]
    # Best Prompt는 주황색, 나머지는 파란색
    colors = ["#4C72B0" if lbl != report.best_prompt else "#DD8452" for lbl in labels]

    fig, ax = plt.subplots(figsize=figsize, dpi=120)
    bars = ax.bar(labels, values, color=colors, edgecolor="white", linewidth=0.8)
    ax.set_xlabel("Prompt Type", fontsize=12)
    ax.set_ylabel("Evaluation Score", fontsize=12)
    ax.set_title(title, fontsize=14, pad=12)
    ax.set_ylim(0, 10.5)  # 1~10점 척도
    ax.axhline(5, color="gray", linestyle="--", linewidth=0.8, alpha=0.5)  # 중간 기준선
    ax.grid(axis="y", alpha=0.3)

    # 막대 위에 점수 숫자 표시
    for bar, val in zip(bars, values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.15,
            f"{val:.0f}",
            ha="center",
            va="bottom",
            fontsize=11,
            fontweight="bold",
        )

    plt.xticks(rotation=15, ha="right")
    plt.tight_layout()

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, bbox_inches="tight")

    return fig
