"""python -m prompt_battle 실행 진입점.

터미널에서 `python -m prompt_battle` 명령으로 Gradio 웹 UI를 바로 실행한다.
노트북 없이 독립 실행할 때 사용한다.
"""

from prompt_battle.gradio_app import launch

if __name__ == "__main__":
    launch()
