"""VLM 응답 파싱 및 비교 테이블 생성.

5가지 프롬프트의 VLM 응답에서 결함·결론을 휴리스틱으로 추출하고,
Prompt Type / Response Length / Response Time / Detected Defect / Final Conclusion
비교 테이블을 생성한다.
"""

import json
import re
from dataclasses import dataclass, asdict

from prompt_battle.vlm import InferenceResult


@dataclass
class ComparisonRow:
    """프롬프트별 비교 테이블 한 행."""

    prompt_type: str       # 프롬프트 표시명
    response_length: int   # 응답 문자 수
    response_time: float   # 추론 소요 시간(초)
    detected_defect: str   # 추출된 결함 정보
    final_conclusion: str  # 추출된 최종 결론
    full_response: str     # VLM 원문 응답 (JSON 저장용)


def _extract_json_field(response: str, field: str) -> str:
    """JSON 응답에서 특정 필드 값 추출.

    VLM이 JSON 외 텍스트를 함께 출력할 수 있어 정규식으로 { ... } 블록만 추출한다.
    """
    try:
        match = re.search(r"\{[\s\S]*\}", response)
        if match:
            data = json.loads(match.group())
            value = data.get(field, "")
            return str(value).strip() if value else ""
    except (json.JSONDecodeError, TypeError):
        pass
    return ""


def extract_detected_defect(response: str, prompt_key: str) -> str:
    """응답 텍스트에서 결함 여부/유형을 휴리스틱으로 추출.

    JSON 프롬프트는 defect 필드 우선, 그 외는 정규식 패턴·키워드 폴백.
    """
    if prompt_key == "json":
        defect = _extract_json_field(response, "defect")
        if defect:
            return defect

    # 한국어·영어 결함 관련 패턴 매칭
    patterns = [
        r"결함\s*(?:유형)?\s*[:：]\s*(.+)",
        r"defect\s*[:：]\s*(.+)",
        r"이상\s*여부\s*[:：]\s*(.+)",
        r"결함\s*여부\s*[:：]\s*(.+)",
        r"3\.\s*결함\s*여부\s*판단\s*[:：]?\s*(.+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, response, re.IGNORECASE)
        if match:
            return match.group(1).strip()[:80]

    # 키워드 기반 폴백
    lower = response.lower()
    if any(kw in lower for kw in ("결함 없", "이상 없", "정상", "no defect", "good")):
        return "정상/결함 없음"
    if any(kw in lower for kw in ("결함", "불량", "defect", "scratch", "bent", "scratch")):
        return "결함 감지됨"
    return "미확인"


def extract_final_conclusion(response: str, prompt_key: str) -> str:
    """응답 텍스트에서 최종 결론을 휴리스틱으로 추출."""
    if prompt_key == "json":
        # JSON 프롬프트: product / defect / severity 조합
        parts = [
            _extract_json_field(response, "product"),
            _extract_json_field(response, "defect"),
            _extract_json_field(response, "severity"),
        ]
        joined = " / ".join(p for p in parts if p)
        if joined:
            return joined[:120]

    patterns = [
        r"최종\s*결론\s*[:：]\s*(.+)",
        r"5\.\s*최종\s*결론\s*[:：]?\s*(.+)",
        r"출하\s*가능\s*여부\s*[:：]\s*(.+)",
        r"권장\s*조치\s*[:：]\s*(.+)",
        r"conclusion\s*[:：]\s*(.+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, response, re.IGNORECASE)
        if match:
            return match.group(1).strip()[:120]

    # 마지막 문장 사용
    sentences = [s.strip() for s in re.split(r"[.!?。\n]", response) if s.strip()]
    return sentences[-1][:120] if sentences else response[:120]


def build_comparison_rows(results: list[InferenceResult]) -> list[ComparisonRow]:
    """추론 결과 목록을 비교 테이블 행으로 변환."""
    rows: list[ComparisonRow] = []
    for result in results:
        rows.append(
            ComparisonRow(
                prompt_type=result.prompt_display_name,
                response_length=result.response_length,
                response_time=result.response_time_sec,
                detected_defect=extract_detected_defect(result.response, result.prompt_key),
                final_conclusion=extract_final_conclusion(result.response, result.prompt_key),
                full_response=result.response,
            )
        )
    return rows


def rows_to_markdown_table(rows: list[ComparisonRow]) -> str:
    """비교 행을 Markdown 표로 변환 (노트북·리포트 출력용)."""
    header = "| Prompt Type | Response Length | Response Time (s) | Detected Defect | Final Conclusion |\n"
    sep = "|---|---:|---:|---|---|\n"
    body = ""
    for row in rows:
        defect = row.detected_defect.replace("|", "/")  # Markdown 파이프 문자 이스케이프
        conclusion = row.final_conclusion.replace("|", "/")
        body += (
            f"| {row.prompt_type} | {row.response_length} | {row.response_time:.2f} "
            f"| {defect} | {conclusion} |\n"
        )
    return header + sep + body


def rows_to_dicts(rows: list[ComparisonRow]) -> list[dict]:
    """Gradio Dataframe용 dict 목록."""
    return [
        {
            "Prompt Type": r.prompt_type,
            "Response Length": r.response_length,
            "Response Time": r.response_time,
            "Detected Defect": r.detected_defect,
            "Final Conclusion": r.final_conclusion,
        }
        for r in rows
    ]


def rows_to_serializable(rows: list[ComparisonRow]) -> list[dict]:
    """JSON 저장용 직렬화."""
    return [asdict(r) for r in rows]
