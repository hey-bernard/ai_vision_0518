"""MVTec AD 데이터셋 로드 및 이미지 선택.

MVTec_screw_metal_nut.zip 압축 해제, test 이미지 목록 조회,
Gradio 드롭다운용 라벨 생성 등 데이터 관련 유틸리티를 제공한다.
"""

import shutil
import zipfile
from pathlib import Path


def find_project_root(start: Path | None = None) -> Path:
    """MVTec zip 또는 데이터 폴더가 있는 프로젝트 루트를 탐색.

    노트북·Gradio·CLI 실행 위치(cwd)가 달라도 데이터를 찾을 수 있도록
    현재 디렉터리와 상위 디렉터리를 순회한다.
    """
    root = start or Path.cwd()
    for candidate in [root, *root.parents]:
        if (candidate / "MVTec_screw_metal_nut.zip").exists():
            return candidate
        if (candidate / "MVTec_screw_metal_nut").exists():
            return candidate
    return root


def resolve_data_root(data_root: Path, categories: tuple[str, ...]) -> Path:
    """screw/metal_nut이 실제로 있는 데이터 루트 반환 (zip 중첩 구조 대응).

    zip 압축 해제 시 MVTec_screw_metal_nut/MVTec_screw_metal_nut/screw/... 처럼
    한 단계 중첩되는 경우가 있어, test/good 폴더가 있는 실제 경로를 찾는다.
    """
    if not data_root.exists():
        return data_root
    if mvtec_is_ready(data_root, categories):
        return data_root
    # zip 압축 해제 시 MVTec_screw_metal_nut/MVTec_screw_metal_nut/ 형태 대응
    nested = data_root / "MVTec_screw_metal_nut"
    if nested.is_dir() and mvtec_is_ready(nested, categories):
        return nested
    # 그 외 하위 폴더 중 준비된 경로 탐색
    for child in data_root.iterdir():
        if child.is_dir() and mvtec_is_ready(child, categories):
            return child
    return data_root


def mvtec_is_ready(data_root: Path, categories: tuple[str, ...]) -> bool:
    """압축 해제가 완료되었는지 screw/metal_nut test/good 폴더로 확인."""
    return all((data_root / cat / "test" / "good").is_dir() for cat in categories)


def extract_mvtec_zip(zip_path: Path, extract_to: Path, categories: tuple[str, ...], *, force: bool = False) -> None:
    """MVTec_screw_metal_nut.zip 압축 해제 (이미 있으면 스킵).

    Args:
        zip_path: zip 파일 경로.
        extract_to: 압축 해제 대상 폴더.
        categories: 준비 여부 확인용 카테고리 목록.
        force: True면 기존 폴더 삭제 후 재압축 해제.
    """
    if not zip_path.exists():
        raise FileNotFoundError(f"압축 파일을 찾을 수 없습니다: {zip_path}")
    # 폴더가 이미 있을 때만 준비 여부 확인 (없으면 바로 압축 해제)
    if extract_to.exists() and not force:
        effective = resolve_data_root(extract_to, categories)
        if mvtec_is_ready(effective, categories):
            return
    if extract_to.exists() and force:
        shutil.rmtree(extract_to)
    extract_to.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(extract_to)


def list_test_images(data_root: Path, category: str, defect_type: str | None = None) -> list[Path]:
    """test/ 하위 이미지 경로 목록 반환. defect_type 지정 시 해당 유형만.

    MVTec AD test 구조: {category}/test/{defect_type}/*.png
    defect_type=None이면 모든 결함 유형 이미지를 합쳐 반환한다.
    """
    root = resolve_data_root(data_root, ("screw", "metal_nut"))
    test_dir = root / category / "test"
    if not test_dir.exists():
        return []
    if defect_type:
        return sorted((test_dir / defect_type).glob("*.png"))
    images: list[Path] = []
    for sub in sorted(test_dir.iterdir()):
        if sub.is_dir():
            images.extend(sorted(sub.glob("*.png")))
    return images


def dataset_summary(data_root: Path, categories: tuple[str, ...]) -> dict[str, dict[str, int]]:
    """카테고리별 결함 유형·이미지 수 집계.

    Returns:
        {"screw": {"good": 41, "scratch_head": 24, ...}, "metal_nut": {...}}
    """
    root = resolve_data_root(data_root, categories)
    summary: dict[str, dict[str, int]] = {}
    for cat in categories:
        test_dir = root / cat / "test"
        summary[cat] = {}
        if not test_dir.exists():
            continue
        for sub in sorted(test_dir.iterdir()):
            if sub.is_dir():
                summary[cat][sub.name] = len(list(sub.glob("*.png")))
    return summary


def ground_truth_defect(image_path: Path) -> str:
    """이미지 경로에서 MVTec 결함 유형(폴더명)을 추출.

    예: .../test/scratch/000.png → "scratch"
    GPT 평가 시 정답 레이블(ground truth)로 활용한다.
    """
    return image_path.parent.name


def build_image_choices(data_root: Path, categories: tuple[str, ...]) -> list[tuple[str, str]]:
    """Gradio Dropdown용 (표시 라벨, 파일 경로) 목록 생성.

    Returns:
        [("[screw] good / 000.png", "C:\\...\\000.png"), ...]
    """
    choices: list[tuple[str, str]] = []
    for cat in categories:
        for img_path in list_test_images(data_root, cat):
            defect = ground_truth_defect(img_path)
            label = f"[{cat}] {defect} / {img_path.name}"
            choices.append((label, str(img_path.resolve())))
    return choices


def format_choice_label(image_path: str | Path) -> str:
    """이미지 경로를 사람이 읽기 쉬운 라벨로 변환."""
    path = Path(image_path)
    category = path.parts[-4] if len(path.parts) >= 4 else "unknown"
    defect = path.parent.name
    return f"[{category}] {defect} / {path.name}"
