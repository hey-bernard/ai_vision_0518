"""Gradio UI — Prompt Battle for VLM.

좌측: MVTec 이미지 선택 + 실행 버튼
우측: VLM 응답 / 비교 테이블 / 평가 점수 / 차트 / 교육용 분석

프롬프트별 스트리밍 yield로 중간 결과를 실시간 표시한다.
"""

from __future__ import annotations

from collections.abc import Generator

import gradio as gr
from PIL import Image

from prompt_battle.battle import PromptBattle
from prompt_battle.comparison import build_comparison_rows, rows_to_dicts
from prompt_battle.config import BattleConfig
from prompt_battle.dataset import build_image_choices, find_project_root, resolve_data_root
from prompt_battle.env_loader import load_env_file, openai_api_key_configured
from prompt_battle.prompts import ALL_PROMPTS
from prompt_battle.visualization import plot_evaluation_scores
from prompt_battle.vlm import Qwen3VLEngine, set_shared_engine

# 전역 인스턴스 (모델 1회 로드)
_BATTLE: PromptBattle | None = None


def register_engine(engine: Qwen3VLEngine) -> None:
    """노트북 §3에서 로드한 엔진을 Gradio와 공유 (중복 로드·VRAM 낭비 방지)."""
    set_shared_engine(engine)
    battle = get_battle()
    battle.attach_engine(engine)


def get_battle() -> PromptBattle:
    """싱글톤 PromptBattle 인스턴스 반환."""
    global _BATTLE
    if _BATTLE is None:
        load_env_file()
        root = find_project_root()
        # Gradio 전용 설정: 짧은 토큰·단일 GPU
        _BATTLE = PromptBattle(BattleConfig.for_gradio(), root=root)
        _BATTLE.ensure_dataset()
        _BATTLE.data_root = resolve_data_root(_BATTLE.data_root, _BATTLE.config.categories)
    return _BATTLE


def preload_model() -> str:
    """Gradio 시작 시 모델을 미리 로드."""
    load_env_file()
    battle = get_battle()
    try:
        battle.load_model()
        device = battle.engine.device
        shared = " (노트북 엔진 공유)" if battle.engine.is_loaded else ""
        gpt_status = " · OpenAI API 준비됨" if openai_api_key_configured() else " · OpenAI API 키 없음"
        return f"✅ Qwen3-VL 준비 완료 — device: {device}{shared}{gpt_status}"
    except Exception as exc:
        return f"❌ 모델 로드 실패: {exc}"


def _empty_outputs():
    """빈 Gradio 출력 튜플."""
    return None, "_대기 중_", [], "_대기 중_", "_대기 중_", None, ""


def run_prompt_battle_stream(
    image_path: str,
    run_gpt: bool,
    progress: gr.Progress = gr.Progress(),
) -> Generator[tuple, None, None]:
    """프롬프트별로 결과를 점진 반환 (Gradio 스트리밍).

    각 프롬프트 완료 시 yield하여 UI가 processing 상태에서 벗어나도록 한다.
    최종 yield에서 GPT 평가·차트·교육용 분석을 포함한다.
    """
    if not image_path:
        yield _empty_outputs()
        return

    battle = get_battle()
    inference_results = []
    preview = None
    gt_defect = ""
    resolved_path = image_path

    try:
        progress(0, desc="모델 준비 중...")
        total_steps = len(ALL_PROMPTS) + (1 if run_gpt else 0) + 1

        # 5가지 프롬프트 순차 추론 — 완료마다 중간 결과 yield
        for index, total, result, image, gt, path in battle.iter_prompt_inferences(image_path):
            inference_results.append(result)
            preview = image
            gt_defect = gt
            resolved_path = path

            step = index + 1
            progress(step / total_steps, desc=f"[{step}/{total}] {result.prompt_display_name} 완료 ({result.response_time_sec}s)")

            rows = build_comparison_rows(inference_results)
            prompt_md = battle.format_inference_results(inference_results)
            status = f"**진행 중** — {step}/{total} 프롬프트 완료 (마지막: {result.prompt_display_name}, {result.response_time_sec}s)"

            yield (
                preview,
                prompt_md,
                rows_to_dicts(rows),
                "_평가 대기 중_",
                status,
                None,
                status,
            )

        # VLM 추론 완료 후 평가·차트·저장
        progress((len(ALL_PROMPTS) + 1) / total_steps, desc="평가·차트 생성 중...")
        report = battle.finalize_battle(
            resolved_path,
            gt_defect,
            inference_results,
            run_gpt_eval=run_gpt,
        )

        fig = plot_evaluation_scores(report.evaluation) if report.evaluation else None
        done_msg = (
            f"✅ 완료 — VLM {len(inference_results)}회 추론"
            + (f", 최고 프롬프트: **{report.evaluation.best_prompt}** ({report.evaluation.best_score:.0f}점)" if report.evaluation else "")
        )

        progress(1.0, desc="완료")
        yield (
            preview,
            battle.format_prompt_outputs(report),
            report.comparison_dataframe(),
            report.score_markdown(),
            report.education_markdown(),
            fig,
            done_msg,
        )

    except Exception as exc:
        msg = f"❌ 실행 오류: {exc}"
        yield None, msg, [], msg, msg, None, msg


def build_demo(shared_engine: Qwen3VLEngine | None = None) -> gr.Blocks:
    """Gradio Blocks UI 구성."""
    if shared_engine is not None and shared_engine.is_loaded:
        register_engine(shared_engine)

    battle = get_battle()
    choices = build_image_choices(battle.data_root, battle.config.categories)
    default_choice = choices[0][1] if choices else None
    # 드롭다운 표시 라벨 → 실제 파일 경로 매핑
    path_map = {label: path for label, path in choices}

    with gr.Blocks(title="Prompt Battle for VLM") as demo:
        gr.Markdown(
            "# Prompt Battle for VLM\n"
            "동일 MVTec AD 이미지에 5가지 프롬프트 기법을 적용하고 "
            "Qwen3-VL 응답 품질을 비교·평가하는 교육용 실습 시스템\n\n"
            "> **예상 소요**: GPU 정상 시 약 3~5분 · 프롬프트마다 결과가 순차 표시됩니다."
        )

        status_box = gr.Markdown("⏳ 모델 로딩 중...")

        with gr.Row():
            # ── 좌측: 이미지 선택 + 실행 ──
            with gr.Column(scale=1):
                gr.Markdown("### 이미지 선택")
                image_dropdown = gr.Dropdown(
                    choices=[c[0] for c in choices],
                    value=choices[0][0] if choices else None,
                    label="MVTec AD 이미지",
                    interactive=True,
                )
                image_preview = gr.Image(label="선택 이미지", type="pil", height=300)
                run_gpt = gr.Checkbox(
                    value=openai_api_key_configured(),
                    label="OpenAI GPT 평가 실행 (C:\\env\\.env)",
                )
                run_btn = gr.Button("Prompt Battle 실행", variant="primary")

            # ── 우측: 결과 탭 ──
            with gr.Column(scale=2):
                gr.Markdown("### 프롬프트 결과")
                with gr.Tabs():
                    with gr.Tab("VLM 응답"):
                        prompt_outputs = gr.Markdown()
                    with gr.Tab("비교 테이블"):
                        comparison_table = gr.Dataframe(
                            headers=[
                                "Prompt Type",
                                "Response Length",
                                "Response Time",
                                "Detected Defect",
                                "Final Conclusion",
                            ],
                            interactive=False,
                        )
                    with gr.Tab("평가 점수"):
                        score_table = gr.Markdown()
                    with gr.Tab("평가 차트"):
                        eval_chart = gr.Plot(label="Evaluation Score")
                education_box = gr.Markdown(label="교육용 분석")

        def on_select(label: str):
            """드롭다운 선택 시 이미지 미리보기."""
            if not label or label not in path_map:
                return None
            return Image.open(path_map[label]).convert("RGB")

        def on_run(label: str, gpt: bool, progress=gr.Progress()):
            """실행 버튼 — 라벨→경로 변환 후 스트리밍 배틀 실행."""
            path = path_map.get(label, "")
            yield from run_prompt_battle_stream(path, gpt, progress)

        image_dropdown.change(on_select, inputs=image_dropdown, outputs=image_preview)
        run_btn.click(
            on_run,
            inputs=[image_dropdown, run_gpt],
            outputs=[
                image_preview,
                prompt_outputs,
                comparison_table,
                score_table,
                education_box,
                eval_chart,
                status_box,
            ],
        )

        def on_app_load():
            """앱 시작 시 모델 선로드 + 기본 이미지 미리보기."""
            status = preload_model()
            img = Image.open(default_choice).convert("RGB") if default_choice else None
            return status, img

        demo.load(on_app_load, outputs=[status_box, image_preview])

    return demo


def launch(shared_engine: Qwen3VLEngine | None = None, **kwargs):
    """Gradio 앱 실행."""
    demo = build_demo(shared_engine=shared_engine)
    demo.launch(**kwargs)


if __name__ == "__main__":
    launch()
