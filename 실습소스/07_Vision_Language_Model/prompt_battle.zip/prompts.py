"""5가지 프롬프트 기법 템플릿 정의.

동일 이미지에 적용할 프롬프트 엔지니어링 기법 5종:
    Basic / Role / JSON / Chain-of-Thought / Risk Assessment
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class PromptTemplate:
    """프롬프트 유형과 본문.

    frozen=True: 실습 중 프롬프트 텍스트가 의도치 않게 변경되지 않도록 불변 객체로 정의.
    """

    key: str           # 내부 식별자 (basic, role, json, cot, risk)
    display_name: str  # UI·리포트 표시명 (Basic, Role, ...)
    text: str          # Qwen3-VL에 전달할 실제 프롬프트 본문


# ── 1. Basic Prompt ──
# 최소한의 지시만 포함 — VLM 기본 응답 품질의 기준선(baseline)
BASIC_PROMPT = PromptTemplate(
    key="basic",
    display_name="Basic",
    text="이미지를 분석하라.",
)

# ── 2. Role Prompt ──
# 도메인 역할(품질관리 엔지니어) 부여로 맥락·전문성 강화
ROLE_PROMPT = PromptTemplate(
    key="role",
    display_name="Role",
    text=(
        "당신은 제조업 품질관리 엔지니어이다.\n"
        "제품 종류와 결함 여부를 분석하라."
    ),
)

# ── 3. Structured Output (JSON) Prompt ──
# 구조화 출력 요구 — 파싱·자동화 파이프라인에 유리
JSON_PROMPT = PromptTemplate(
    key="json",
    display_name="JSON",
    text=(
        "이미지를 분석하고 JSON 형식으로 출력하라.\n\n"
        "{\n"
        '  "product":"",\n'
        '  "defect":"",\n'
        '  "location":"",\n'
        '  "severity":""\n'
        "}"
    ),
)

# ── 4. Chain of Thought Prompt ──
# 단계별 추론 유도 — 설명력·추론 깊이 극대화
COT_PROMPT = PromptTemplate(
    key="cot",
    display_name="CoT",
    text=(
        "이미지를 분석하라.\n\n"
        "1. 제품 종류 식별\n"
        "2. 특징 분석\n"
        "3. 결함 여부 판단\n"
        "4. 결함 근거 설명\n"
        "5. 최종 결론 작성"
    ),
)

# ── 5. Risk Assessment Prompt ──
# 실무 QA 관점(위험도·출하·조치) 평가 유도
RISK_PROMPT = PromptTemplate(
    key="risk",
    display_name="Risk Assessment",
    text=(
        "당신은 품질보증 책임자이다.\n\n"
        "1. 결함 유형\n"
        "2. 위험도\n"
        "3. 출하 가능 여부\n"
        "4. 권장 조치\n\n"
        "를 작성하라."
    ),
)

# 전체 프롬프트 목록 (실행 순서)
ALL_PROMPTS: tuple[PromptTemplate, ...] = (
    BASIC_PROMPT,
    ROLE_PROMPT,
    JSON_PROMPT,
    COT_PROMPT,
    RISK_PROMPT,
)


def get_prompt_by_key(key: str) -> PromptTemplate:
    """키로 프롬프트 템플릿 조회."""
    for prompt in ALL_PROMPTS:
        if prompt.key == key:
            return prompt
    raise KeyError(f"알 수 없는 프롬프트 키: {key}")
