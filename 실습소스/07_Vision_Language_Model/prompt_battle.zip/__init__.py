"""Prompt Battle for VLM — 멀티모달 프롬프트 엔지니어링 실습 패키지.

이 패키지는 동일 MVTec AD 이미지에 5가지 프롬프트 기법을 적용하고,
Qwen3-VL 응답을 OpenAI GPT로 비교·평가하는 교육용 실습 시스템의 진입점이다.

주요 공개 API:
    - PromptBattle  : 전체 워크플로 오케스트레이터
    - BattleReport  : 실행 결과 리포트 데이터 클래스
    - BattleConfig  : 모델·데이터·API 설정
    - Qwen3VLEngine : Hugging Face Qwen3-VL 추론 엔진
"""

from prompt_battle.env_loader import load_env_file

# 패키지 import 시 C:\env\.env 자동 로드
# → 노트북·Gradio·CLI 어디서든 OpenAI API 키를 별도 설정 없이 사용 가능
load_env_file()

from prompt_battle.battle import PromptBattle, BattleReport
from prompt_battle.config import BattleConfig
from prompt_battle.env_loader import get_openai_api_key, openai_api_key_configured
from prompt_battle.vlm import Qwen3VLEngine, set_shared_engine

# 외부에서 `from prompt_battle import ...` 로 가져올 수 있는 심볼 목록
__all__ = [
    "PromptBattle",
    "BattleReport",
    "BattleConfig",
    "Qwen3VLEngine",
    "set_shared_engine",
    "get_openai_api_key",
    "openai_api_key_configured",
]
