"""교육용 자동 설명 생성.

GPT/휴리스틱 평가 결과를 바탕으로 학습자에게 프롬프트 기법별 특성을
설명하는 문장을 자동 생성한다.
"""

from prompt_battle.evaluation import EvaluationReport, PromptScore


def _score_of(report: EvaluationReport, *names: str) -> PromptScore | None:
    """표시 이름으로 점수 객체 조회 (대소문자 무시)."""
    lowered = {n.lower() for n in names}
    for item in report.scores:
        if item.prompt_type.lower() in lowered:
            return item
    return None


def generate_educational_insights(report: EvaluationReport) -> list[str]:
    """프롬프트 비교 결과를 바탕으로 교육용 설명 문장 생성.

    점수 비교 규칙에 따라 Role>Basic, JSON 구조화, CoT 추론, Risk 실무성 등
    학습 포인트 문장을 조건부로 추가한다.
    """
    insights: list[str] = []

    basic = _score_of(report, "Basic")
    role = _score_of(report, "Role")
    json_p = _score_of(report, "JSON")
    cot = _score_of(report, "CoT", "Chain of Thought")
    risk = _score_of(report, "Risk Assessment")

    if basic and role and role.score > basic.score:
        insights.append(
            "Role Prompt는 기본 프롬프트보다 더 상세한 품질 분석 결과를 생성하였다."
        )

    if json_p and json_p.score >= 7:
        insights.append(
            "Structured Output(JSON) Prompt는 구조화 수준이 높아 자동화 파이프라인에 적합하다."
        )

    if cot:
        cot_score = cot.score
        others = [s.score for s in report.scores if s.prompt_type != cot.prompt_type]
        if cot_score >= max(others, default=0):
            insights.append(
                "Chain of Thought Prompt는 가장 높은 추론 성능을 보였다."
            )

    if risk and risk.score >= 7:
        insights.append(
            "Risk Assessment Prompt는 출하 판정·권장 조치 등 실무 QA 관점의 정보를 제공한다."
        )

    # 항상 포함: 이번 배틀 최고 점수 프롬프트
    insights.append(
        f"이번 Prompt Battle에서 최고 점수를 받은 프롬프트는 **{report.best_prompt}** "
        f"(점수 {report.best_score:.0f}/10)이다."
    )

    if not report.used_gpt:
        insights.append(
            "※ OpenAI GPT 평가를 사용하지 못해 규칙 기반 휴리스틱 평가가 적용되었습니다. "
            r"C:\env\.env 파일에 OPENAI_API_KEY가 설정되어 있는지 확인하세요."
        )

    return insights


def insights_to_markdown(insights: list[str]) -> str:
    """교육용 설명을 Markdown 목록으로 변환."""
    lines = ["### 교육용 분석", ""]
    for text in insights:
        lines.append(f"- {text}")
    return "\n".join(lines)
