"""Prompt Battle 통합 오케스트레이터.

데이터 준비 → Qwen3-VL 5종 프롬프트 추론 → 비교 테이블 → GPT 평가 →
차트 저장 → JSON 리포트 저장까지 전체 워크플로를 관리한다.
"""

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image

from prompt_battle.comparison import (
    ComparisonRow,
    build_comparison_rows,
    rows_to_dicts,
    rows_to_markdown_table,
    rows_to_serializable,
)
from prompt_battle.config import BattleConfig
from prompt_battle.dataset import (
    extract_mvtec_zip,
    find_project_root,
    ground_truth_defect,
    resolve_data_root,
)
from prompt_battle.education import generate_educational_insights, insights_to_markdown
from prompt_battle.env_loader import get_openai_api_key, load_env_file
from prompt_battle.evaluation import EvaluationReport, evaluate_prompts, evaluation_to_serializable
from prompt_battle.prompts import ALL_PROMPTS
from prompt_battle.visualization import plot_evaluation_scores
from prompt_battle.vlm import InferenceResult, Qwen3VLEngine, get_shared_engine


@dataclass
class BattleReport:
    """Prompt Battle 전체 실행 결과."""

    image_path: str
    ground_truth_defect: str
    inference_results: list[InferenceResult] = field(default_factory=list)
    comparison_rows: list[ComparisonRow] = field(default_factory=list)
    evaluation: EvaluationReport | None = None
    educational_insights: list[str] = field(default_factory=list)
    chart_path: str | None = None

    def comparison_markdown(self) -> str:
        """비교 테이블 Markdown."""
        return rows_to_markdown_table(self.comparison_rows)

    def comparison_dataframe(self) -> list[dict]:
        """Gradio Dataframe용 데이터."""
        return rows_to_dicts(self.comparison_rows)

    def score_markdown(self) -> str:
        """점수 요약 Markdown."""
        if self.evaluation is None:
            return "평가가 아직 실행되지 않았습니다."
        return self.evaluation.score_table_markdown()

    def education_markdown(self) -> str:
        """교육용 설명 Markdown."""
        return insights_to_markdown(self.educational_insights)

    def to_dict(self) -> dict:
        """JSON 직렬화 (outputs/prompt_battle/*.json 저장용)."""
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "image_path": self.image_path,
            "ground_truth_defect": self.ground_truth_defect,
            "inference_results": [
                {
                    "prompt_key": r.prompt_key,
                    "prompt_display_name": r.prompt_display_name,
                    "response_length": r.response_length,
                    "response_time_sec": r.response_time_sec,
                    "response": r.response,
                }
                for r in self.inference_results
            ],
            "comparison_rows": rows_to_serializable(self.comparison_rows),
            "evaluation": evaluation_to_serializable(self.evaluation) if self.evaluation else None,
            "educational_insights": self.educational_insights,
            "chart_path": self.chart_path,
        }


class PromptBattle:
    """Prompt Battle for VLM 메인 클래스."""

    def __init__(self, config: BattleConfig | None = None, root: Path | None = None):
        self.config = config or BattleConfig()
        self.root = root or find_project_root()
        self.data_root = resolve_data_root(self.root / "MVTec_screw_metal_nut", self.config.categories)
        self.zip_path = self.root / "MVTec_screw_metal_nut.zip"
        self.output_dir = self.root / self.config.output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        load_env_file(self.config.env_file)  # OpenAI API 키 로드
        self.engine = Qwen3VLEngine(self.config)
        self._model_loaded = False

    def ensure_dataset(self) -> None:
        """MVTec AD 데이터셋 압축 해제."""
        extract_mvtec_zip(self.zip_path, self.data_root, self.config.categories)

    def load_model(self) -> None:
        """Qwen3-VL 모델 로드 (공유 엔진이 있으면 재사용)."""
        shared = get_shared_engine()
        if shared is not None and shared.is_loaded:
            # 노트북에서 이미 로드한 엔진 재사용 → VRAM 절약
            self.engine = shared
            self._model_loaded = True
            return
        if not self._model_loaded:
            self.engine.load()
            self._model_loaded = True

    def attach_engine(self, engine: Qwen3VLEngine) -> None:
        """노트북 등에서 이미 로드한 엔진을 연결."""
        if engine.is_loaded:
            self.engine = engine
            self._model_loaded = True

    def format_inference_results(self, results: list[InferenceResult]) -> str:
        """추론 결과 목록을 Markdown으로 포맷 (Gradio 스트리밍 중간 출력용)."""
        sections = []
        for result in results:
            sections.append(
                f"## {result.prompt_display_name}\n\n"
                f"**응답 길이**: {result.response_length} | "
                f"**소요 시간**: {result.response_time_sec:.2f}s\n\n"
                f"{result.response}"
            )
        return "\n\n---\n\n".join(sections) if sections else "_추론 대기 중..._"

    def iter_prompt_inferences(
        self,
        image_path: str | Path,
    ):
        """프롬프트별 VLM 추론을 하나씩 yield (Gradio 스트리밍용).

        Yields:
            (index, total, InferenceResult, image, gt_defect, resolved_path)
        """
        path = Path(image_path)
        if not path.exists():
            raise FileNotFoundError(f"이미지를 찾을 수 없습니다: {path}")

        self.ensure_dataset()
        self.load_model()

        image = Image.open(path).convert("RGB")
        gt_defect = ground_truth_defect(path)
        total = len(ALL_PROMPTS)

        for index, prompt in enumerate(ALL_PROMPTS):
            result = self.engine.run_prompt(
                image,
                prompt.key,
                prompt.display_name,
                prompt.text,
            )
            yield index, total, result, image, gt_defect, str(path.resolve())

    def finalize_battle(
        self,
        image_path: str,
        gt_defect: str,
        inference_results: list[InferenceResult],
        *,
        run_gpt_eval: bool = True,
        api_key: str | None = None,
        save_chart: bool = True,
    ) -> BattleReport:
        """추론 완료 후 비교·평가·저장.

        VLM 추론이 끝난 뒤 호출한다. Gradio는 5개 프롬프트 스트리밍 후 이 메서드를 호출한다.
        """
        path = Path(image_path)
        comparison_rows = build_comparison_rows(inference_results)

        evaluation = None
        if run_gpt_eval:
            evaluation = evaluate_prompts(
                inference_results,
                comparison_rows,
                ground_truth_defect=gt_defect,
                model=self.config.gpt_model,
                api_key=api_key or get_openai_api_key(),
            )

        insights: list[str] = []
        if evaluation:
            insights = generate_educational_insights(evaluation)

        chart_path = None
        if evaluation and save_chart:
            chart_file = self.output_dir / f"battle_{path.stem}.png"
            plot_evaluation_scores(evaluation, save_path=chart_file)
            chart_path = str(chart_file.resolve())

        report = BattleReport(
            image_path=image_path,
            ground_truth_defect=gt_defect,
            inference_results=inference_results,
            comparison_rows=comparison_rows,
            evaluation=evaluation,
            educational_insights=insights,
            chart_path=chart_path,
        )

        json_path = self.output_dir / f"battle_{path.stem}.json"
        json_path.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        return report

    def run_battle(
        self,
        image_path: str | Path,
        *,
        run_gpt_eval: bool = True,
        api_key: str | None = None,
        save_chart: bool = True,
    ) -> BattleReport:
        """단일 이미지에 5가지 프롬프트를 적용하고 비교·평가 (일괄 실행)."""
        path = Path(image_path)
        if not path.exists():
            raise FileNotFoundError(f"이미지를 찾을 수 없습니다: {path}")

        self.ensure_dataset()
        self.load_model()

        image = Image.open(path).convert("RGB")
        gt_defect = ground_truth_defect(path)

        inference_results: list[InferenceResult] = []
        for prompt in ALL_PROMPTS:
            result = self.engine.run_prompt(
                image,
                prompt.key,
                prompt.display_name,
                prompt.text,
            )
            inference_results.append(result)

        return self.finalize_battle(
            str(path.resolve()),
            gt_defect,
            inference_results,
            run_gpt_eval=run_gpt_eval,
            api_key=api_key,
            save_chart=save_chart,
        )

    def format_prompt_outputs(self, report: BattleReport) -> str:
        """각 프롬프트 결과를 하나의 Markdown 문자열로 포맷."""
        return self.format_inference_results(report.inference_results)
