"""OpenAI GPT 기반 프롬프트 결과 자동 평가.

5가지 VLM 프롬프트 응답을 GPT(gpt-4o-mini)로 1~10점 평가하거나,
API 키·호출 실패 시 규칙 기반 휴리스틱 평가로 폴백한다.
"""

import json
import re
from dataclasses import dataclass, asdict

from prompt_battle.comparison import ComparisonRow
from prompt_battle.env_loader import get_openai_api_key, load_env_file
from prompt_battle.vlm import InferenceResult

# GPT 평가 5가지 기준 (각 1~10점)
EVAL_CRITERIA = (
    "정보량",
    "정확성",
    "구조화 수준",
    "추론 수준",
    "실무 활용성",
)


@dataclass
class PromptScore:
    """단일 프롬프트 GPT 평가 점수."""

    prompt_type: str
    score: float                      # 최종 점수 (5개 기준 평균)
    criteria_scores: dict[str, float]  # 기준별 세부 점수
    rationale: str                    # 평가 근거 한 줄 요약


@dataclass
class EvaluationReport:
    """전체 프롬프트 평가 리포트."""

    scores: list[PromptScore]
    best_prompt: str   # 최고 점수 프롬프트명
    best_score: float  # 최고 점수
    used_gpt: bool     # True=OpenAI API, False=휴리스틱

    def score_table_markdown(self) -> str:
        """점수 요약 Markdown 표."""
        lines = [
            "----------------------------------------------------",
            "Prompt Type      Score",
            "----------------------------------------------------",
        ]
        for item in self.scores:
            lines.append(f"{item.prompt_type:<18} {item.score:.0f}")
        lines.append("----------------------------------------------------")
        lines.append(f"Best Prompt : {self.best_prompt}")
        lines.append("----------------------------------------------------")
        return "\n".join(lines)


def _build_gpt_evaluation_prompt(
    results: list[InferenceResult],
    comparison_rows: list[ComparisonRow],
    ground_truth_defect: str | None,
) -> str:
    """GPT 평가용 시스템 프롬프트 구성.

    5개 프롬프트의 입력·응답·추출 결함/결론을 묶어 GPT에 전달한다.
    ground_truth_defect가 있으면 정확성 평가 참고 정보로 포함한다.
    """
    gt_line = f"\nGround Truth 결함 유형: {ground_truth_defect}" if ground_truth_defect else ""
    blocks = []
    for result, row in zip(results, comparison_rows):
        blocks.append(
            f"### {result.prompt_display_name}\n"
            f"프롬프트:\n{result.prompt_text}\n\n"
            f"VLM 응답:\n{result.response}\n\n"
            f"추출 결함: {row.detected_defect}\n"
            f"추출 결론: {row.final_conclusion}"
        )
    responses_text = "\n\n".join(blocks)
    return (
        "당신은 멀티모달 프롬프트 엔지니어링 전문가이다.\n"
        "동일 이미지에 적용된 5가지 VLM 프롬프트 결과를 비교 평가하라.\n\n"
        f"평가 기준 (각 1~10점): {', '.join(EVAL_CRITERIA)}\n"
        "각 프롬프트의 최종 점수는 5개 기준의 평균(소수 첫째 반올림)이다."
        f"{gt_line}\n\n"
        f"{responses_text}\n\n"
        "반드시 아래 JSON만 출력하라:\n"
        "{\n"
        '  "evaluations": [\n'
        "    {\n"
        '      "prompt_type": "Basic",\n'
        '      "criteria_scores": {"정보량": 5, "정확성": 6, "구조화 수준": 4, "추론 수준": 5, "실무 활용성": 5},\n'
        '      "score": 5,\n'
        '      "rationale": "간단한 평가 근거"\n'
        "    }\n"
        "  ],\n"
        '  "best_prompt": "Chain of Thought",\n'
        '  "best_score": 9\n'
        "}"
    )


def _parse_gpt_json(text: str) -> dict:
    """GPT 응답에서 JSON 블록 파싱."""
    match = re.search(r"\{[\s\S]*\}", text)
    if not match:
        raise ValueError("GPT 응답에서 JSON을 찾을 수 없습니다.")
    return json.loads(match.group())


def evaluate_with_gpt(
    results: list[InferenceResult],
    comparison_rows: list[ComparisonRow],
    *,
    ground_truth_defect: str | None = None,
    model: str = "gpt-4o-mini",
    api_key: str | None = None,
) -> EvaluationReport:
    """OpenAI GPT로 각 프롬프트 결과를 1~10점 평가."""
    load_env_file()
    key = api_key or get_openai_api_key()
    if not key:
        raise EnvironmentError("OPENAI_API_KEY가 설정되지 않았습니다.")

    from openai import OpenAI

    client = OpenAI(api_key=key)
    user_prompt = _build_gpt_evaluation_prompt(results, comparison_rows, ground_truth_defect)
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "You are a VLM prompt engineering evaluator. Reply in JSON only."},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.2,  # 평가 일관성을 위해 낮은 temperature
    )
    raw = response.choices[0].message.content or ""
    data = _parse_gpt_json(raw)

    scores: list[PromptScore] = []
    for item in data.get("evaluations", []):
        criteria = {k: float(v) for k, v in item.get("criteria_scores", {}).items()}
        scores.append(
            PromptScore(
                prompt_type=item.get("prompt_type", "Unknown"),
                score=float(item.get("score", 0)),
                criteria_scores=criteria,
                rationale=item.get("rationale", ""),
            )
        )

    best_prompt = data.get("best_prompt", scores[0].prompt_type if scores else "N/A")
    best_score = float(data.get("best_score", max((s.score for s in scores), default=0)))

    return EvaluationReport(
        scores=scores,
        best_prompt=best_prompt,
        best_score=best_score,
        used_gpt=True,
    )


def _heuristic_score(result: InferenceResult, row: ComparisonRow) -> PromptScore:
    """API 키 없을 때 규칙 기반 평가 (교육용 데모).

    프롬프트 유형별 기본 점수 + 응답 길이·결함 추출 성공 여부로 가산점 부여.
    """
    key = result.prompt_key
    length = result.response_length

    # 기준별 기본 점수
    info = min(10, 3 + length / 80)
    accuracy = 6.0
    structure = 4.0
    reasoning = 5.0
    practical = 5.0

    # 프롬프트 유형별 특성 반영 기본 점수
    if key == "basic":
        info, structure, reasoning, practical = 5.0, 3.0, 4.0, 4.0
    elif key == "role":
        info, structure, reasoning, practical = 7.0, 6.0, 6.0, 7.0
    elif key == "json":
        info, structure, reasoning, practical = 7.0, 9.0, 6.0, 8.0
    elif key == "cot":
        info, structure, reasoning, practical = 8.0, 7.0, 9.0, 8.0
    elif key == "risk":
        info, structure, reasoning, practical = 7.0, 7.0, 7.0, 9.0

    # 결론·결함 추출 성공 시 가산
    if row.detected_defect != "미확인":
        accuracy += 1.0
    if len(row.final_conclusion) > 20:
        practical += 0.5

    criteria = {
        "정보량": min(10, info),
        "정확성": min(10, accuracy),
        "구조화 수준": min(10, structure),
        "추론 수준": min(10, reasoning),
        "실무 활용성": min(10, practical),
    }
    avg = round(sum(criteria.values()) / len(criteria))
    rationales = {
        "basic": "기본 프롬프트로 최소한의 분석만 제공합니다.",
        "role": "역할 부여로 품질 분석 맥락이 강화되었습니다.",
        "json": "구조화된 JSON 출력으로 파싱·자동화에 유리합니다.",
        "cot": "단계별 추론으로 가장 상세한 분석을 제공합니다.",
        "risk": "실무 QA 관점의 위험도·출하 판정이 포함됩니다.",
    }
    return PromptScore(
        prompt_type=result.prompt_display_name,
        score=float(avg),
        criteria_scores=criteria,
        rationale=rationales.get(key, ""),
    )


def evaluate_prompts(
    results: list[InferenceResult],
    comparison_rows: list[ComparisonRow],
    *,
    ground_truth_defect: str | None = None,
    model: str = "gpt-4o-mini",
    api_key: str | None = None,
    use_heuristic_fallback: bool = True,
) -> EvaluationReport:
    """GPT 평가 시도, 실패 시 휴리스틱 평가로 폴백."""
    load_env_file()
    key = api_key or get_openai_api_key()
    if key:
        try:
            return evaluate_with_gpt(
                results,
                comparison_rows,
                ground_truth_defect=ground_truth_defect,
                model=model,
                api_key=key,
            )
        except Exception as exc:
            if not use_heuristic_fallback:
                raise
            print(f"GPT 평가 실패 — 휴리스틱 평가로 전환: {exc}")

    # API 키 없음 또는 GPT 호출 실패 시 규칙 기반 평가
    scores = [_heuristic_score(r, c) for r, c in zip(results, comparison_rows)]
    best = max(scores, key=lambda s: s.score)
    return EvaluationReport(
        scores=scores,
        best_prompt=best.prompt_type,
        best_score=best.score,
        used_gpt=False,
    )


def evaluation_to_serializable(report: EvaluationReport) -> dict:
    """JSON 저장용 직렬화."""
    return {
        "scores": [asdict(s) for s in report.scores],
        "best_prompt": report.best_prompt,
        "best_score": report.best_score,
        "used_gpt": report.used_gpt,
    }
