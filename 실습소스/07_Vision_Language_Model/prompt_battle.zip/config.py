"""Prompt Battle for VLM — 전역 설정.

BattleConfig 데이터클래스 하나로 VLM 모델, MVTec 데이터, OpenAI 평가,
출력 경로 등 실습 시스템 전반의 하이퍼파라미터를 관리한다.
"""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class BattleConfig:
    """실습 시스템 전역 설정."""

    # ── Qwen3-VL 모델 ──────────────────────────────────────────
    qwen_model_id: str = "Qwen/Qwen3-VL-4B-Instruct"  # Hugging Face 모델 ID
    min_pixels: int = 256 * 28 * 28   # 이미지 최소 픽셀 (프로세서 리사이즈 하한)
    max_pixels: int = 1280 * 28 * 28  # 이미지 최대 픽셀 (VRAM·속도 균형)
    max_new_tokens: int = 512         # VLM 생성 최대 토큰 수 (노트북·일반 실행)

    # Gradio UI용 (추론 속도·VRAM 최적화)
    gradio_max_new_tokens: int = 256  # UI에서는 짧은 응답으로 속도 우선
    force_single_gpu: bool = True  # device_map=auto CPU 오프로드 방지

    # ── OpenAI GPT 평가 ────────────────────────────────────────
    gpt_model: str = "gpt-4o-mini"  # 프롬프트 품질 비교 평가에 사용할 GPT 모델
    env_file: Path = field(default_factory=lambda: Path(r"C:\env\.env"))  # API 키 .env 경로

    @classmethod
    def for_gradio(cls) -> "BattleConfig":
        """Gradio UI 전용 설정 (짧은 응답·단일 GPU)."""
        return cls(max_new_tokens=256, force_single_gpu=True)

    # MVTec AD 카테고리
    categories: tuple[str, ...] = ("screw", "metal_nut")

    # 출력 디렉터리
    output_dir: Path = field(default_factory=lambda: Path("outputs") / "prompt_battle")

    # 결함 유형 한글 라벨 (MVTec test/ 하위 폴더명 → 한글 표시)
    defect_labels_ko: dict[str, str] = field(
        default_factory=lambda: {
            "good": "정상",
            "manipulated_front": "전면 변형",
            "scratch_head": "나사 머리 스크래치",
            "thread_side": "나사산 측면 결함",
            "thread_top": "나사산 상단 결함",
            "bent": "휨",
            "scratch": "스크래치",
            "flip": "뒤집힘",
            "color": "색상 이상",
        }
    )

    # 프롬프트 유형 표시 이름
    prompt_display_names: dict[str, str] = field(
        default_factory=lambda: {
            "basic": "Basic",
            "role": "Role",
            "json": "JSON",
            "cot": "CoT",
            "risk": "Risk Assessment",
        }
    )
