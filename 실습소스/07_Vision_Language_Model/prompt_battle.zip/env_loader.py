"""C:\\env\\.env 에서 OpenAI API 키 등 환경 변수 로드.

python-dotenv 없이 표준 라이브러리만으로 .env 파일을 파싱한다.
OPENAI_API_KEY를 os.environ에 주입하여 evaluation·Gradio 모듈이 사용한다.
"""

import os
from pathlib import Path

# 프로젝트 공통 .env 경로
DEFAULT_ENV_FILE = Path(r"C:\env\.env")

# 중복 로드 방지 플래그 (한 세션에서 .env 파일을 여러 번 읽지 않도록)
_LOADED = False


def load_env_file(env_path: Path | str | None = None, *, override: bool = False) -> bool:
    """.env 파일 내용을 os.environ에 로드한다.

    Args:
        env_path: .env 파일 경로. None이면 DEFAULT_ENV_FILE 사용.
        override: True면 기존 환경 변수도 덮어씀.

    Returns:
        파일을 읽어 적용했으면 True, 파일이 없으면 False.
    """
    global _LOADED
    path = Path(env_path) if env_path else DEFAULT_ENV_FILE
    if not path.is_file():
        return False

    # KEY=VALUE 형식 한 줄씩 파싱
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):  # 빈 줄·주석 스킵
            continue
        if line.startswith("export "):  # shell export 문법 지원
            line = line[7:].strip()
        if "=" not in line:
            continue

        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        # 따옴표로 감싼 값 처리 ("sk-..." 또는 'sk-...')
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]

        if not key:
            continue
        # override=False이면 이미 설정된 환경 변수는 유지
        if override or not os.environ.get(key):
            os.environ[key] = value

    _LOADED = True
    return True


def get_openai_api_key() -> str | None:
    """OPENAI_API_KEY를 반환한다 (.env 자동 로드)."""
    if not _LOADED:
        load_env_file()
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    return key or None


def openai_api_key_configured() -> bool:
    """OpenAI API 키 사용 가능 여부."""
    return get_openai_api_key() is not None
